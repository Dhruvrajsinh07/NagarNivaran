<?php
require_once __DIR__ . "/includes/config.php";

/*
|--------------------------------------------------------------------------
| NagarNivaran Identity Gate
|--------------------------------------------------------------------------
| Required database columns:
| admins.identity_code
| officers.identity_code
|--------------------------------------------------------------------------
*/

$role = $_GET["role"] ?? "";
$error = "";

$roles = [
    "admin" => [
        "label" => "Administrator",
        "table" => "admins",
        "session_id" => "admin_id",
        "destination" => "pages/admin/login.php"
    ],
    "officer" => [
        "label" => "Department Officer",
        "table" => "officers",
        "session_id" => "officer_id",
        "destination" => "pages/officer/login.php"
    ]
];

// Validate the requested role
if (!isset($roles[$role])) {
    header("Location: index.php");
    exit;
}

$currentRole = $roles[$role];

// Process identity code submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $submittedCode = $_POST["identity_code"] ?? "";

    if (!is_string($submittedCode) || trim($submittedCode) === "") {
        $error = "Please enter your identity code.";
    } else {
        try {
            $sql = "SELECT id, identity_code
                    FROM `{$currentRole['table']}`
                    WHERE identity_code IS NOT NULL
                    AND identity_code <> ''";

            $stmt = $conn->query($sql);
            $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $verifiedRecord = null;

            foreach ($records as $record) {
                if (
                    is_string($record["identity_code"]) &&
                    hash_equals(
                        $record["identity_code"],
                        $submittedCode
                    )
                ) {
                    $verifiedRecord = $record;
                    break;
                }
            }

            if ($verifiedRecord !== null) {
                session_regenerate_id(true);

                $_SESSION["identity_verified"] = true;
                $_SESSION["verified_role"] = $role;
                $_SESSION["identity_verified_at"] = time();

                // Associate the verified identity with its database record
                $_SESSION[$currentRole["session_id"]] =
                    $verifiedRecord["id"];

                header("Location: " . $currentRole["destination"]);
                exit;
            }

            $error = "Invalid identity code. Returning to the landing page.";

        } catch (PDOException $e) {
            // Keep database details out of the browser
            error_log("NagarNivaran identity gate database error.");

            $error = "Verification is temporarily unavailable. Returning to the landing page.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>NagarNivaran | Identity Verification</title>

    <link rel="icon" type="image/x-icon" href="<?= urlof('assets/imgs/nn-final.png')?>">

    <meta
        name="theme-color"
        content="#202124"
    >

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        :root {
            --orange: #ff8c00;
            --tomato: #ff6347;
            --obsidian: #202124;
            --surface: #292b30;
            --muted: #a6a8ad;
            --white: #ffffff;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            font-family: Arial, Helvetica, sans-serif;
            color: var(--white);
            background:
                radial-gradient(
                    circle at top left,
                    rgba(255, 140, 0, 0.16),
                    transparent 35%
                ),
                radial-gradient(
                    circle at bottom right,
                    rgba(255, 99, 71, 0.13),
                    transparent 35%
                ),
                var(--obsidian);
        }

        .gate-card {
            width: 100%;
            max-width: 440px;
            padding: 38px 30px;
            text-align: center;
            background: rgba(41, 43, 48, 0.94);
            border: 1px solid rgba(255, 255, 255, 0.09);
            border-radius: 24px;
            box-shadow: 0 24px 80px rgba(0, 0, 0, 0.38);
        }

        .brand-icon {
            width: 76px;
            height: 76px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 22px;
            color: var(--orange);
            background: rgba(255, 140, 0, 0.12);
            border: 1px solid rgba(255, 140, 0, 0.3);
            border-radius: 22px;
        }

        .brand-icon svg {
            width: 36px;
            height: 36px;
        }

        .brand {
            margin-bottom: 10px;
            font-size: 13px;
            font-weight: 800;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: var(--orange);
        }

        h1 {
            margin-bottom: 12px;
            font-size: clamp(24px, 5vw, 30px);
            font-weight: 800;
        }

        .description {
            margin-bottom: 26px;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.7;
        }

        .role-label {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 9px 14px;
            margin-bottom: 25px;
            color: #ffd0a0;
            background: rgba(255, 140, 0, 0.1);
            border: 1px solid rgba(255, 140, 0, 0.22);
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
        }

        .role-label svg {
            width: 15px;
            height: 15px;
        }

        .open-gate {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 15px 18px;
            color: var(--white);
            background: linear-gradient(
                135deg,
                var(--orange),
                var(--tomato)
            );
            border: none;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 800;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .open-gate:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 28px rgba(255, 99, 71, 0.24);
        }

        .open-gate svg {
            width: 18px;
            height: 18px;
        }

        .security-note {
            margin-top: 22px;
            color: #85878d;
            font-size: 11px;
            line-height: 1.6;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #d5d5d8;
            font-size: 13px;
            text-decoration: none;
        }

        .back-link:hover {
            color: var(--orange);
        }

        /* SweetAlert2 theme */
        .swal2-popup {
            background: #292b30 !important;
            color: #ffffff !important;
            border: 1px solid rgba(255, 140, 0, 0.25);
            border-radius: 20px !important;
        }

        .swal2-title {
            color: #ffffff !important;
        }

        .swal2-html-container {
            color: #b8bac0 !important;
        }

        .swal2-input {
            width: 82% !important;
            height: 48px !important;
            margin: 18px auto !important;
            color: #ffffff !important;
            background: #202124 !important;
            border: 1px solid #505158 !important;
            border-radius: 10px !important;
            box-shadow: none !important;
            font-size: 14px !important;
        }

        .swal2-input:focus {
            border-color: var(--orange) !important;
            box-shadow: 0 0 0 3px rgba(255, 140, 0, 0.13) !important;
        }

        .swal2-confirm {
            background: linear-gradient(
                135deg,
                var(--orange),
                var(--tomato)
            ) !important;
            border-radius: 9px !important;
            font-weight: 700 !important;
        }

        .swal2-cancel {
            background: #45474e !important;
            border-radius: 9px !important;
        }

        .swal2-validation-message {
            background: #3a3030 !important;
            color: #ffb6a8 !important;
        }

        @media (max-width: 480px) {
            .gate-card {
                padding: 30px 20px;
            }
        }
    </style>
</head>

<body>

    <main class="gate-card">

        <div class="brand-icon">
            <i data-lucide="shield-check"></i>
        </div>

        <p class="brand">NagarNivaran</p>

        <h1>Identity Verification</h1>

        <p class="description">
            Verify your authorized identity before accessing
            the protected <?= htmlspecialchars($currentRole["label"], ENT_QUOTES, "UTF-8") ?>
            area.
        </p>

        <div class="role-label">
            <i data-lucide="user-round-check"></i>
            <?= htmlspecialchars($currentRole["label"], ENT_QUOTES, "UTF-8") ?> Access
        </div>

        <button
            type="button"
            class="open-gate"
            id="verifyButton"
        >
            <i data-lucide="lock-keyhole"></i>
            Verify Identity
        </button>

        <p class="security-note">
            Authorized access only. Please keep your identity code private.
        </p>

        <a class="back-link" href="index.php">
            ← Return to Home
        </a>

    </main>

    <form
        id="identityForm"
        method="POST"
        action="identity_gate.php?role=<?= htmlspecialchars($role, ENT_QUOTES, "UTF-8") ?>"
        hidden
    >
        <input
            type="password"
            name="identity_code"
            id="identityCode"
            autocomplete="off"
        >
    </form>

    <script>
        lucide.createIcons();

        const verificationError = <?= json_encode(
            $error,
            JSON_HEX_TAG |
            JSON_HEX_APOS |
            JSON_HEX_QUOT |
            JSON_HEX_AMP
        ) ?>;

        const roleLabel = <?= json_encode(
            $currentRole["label"],
            JSON_HEX_TAG |
            JSON_HEX_APOS |
            JSON_HEX_QUOT |
            JSON_HEX_AMP
        ) ?>;

        const identityForm = document.getElementById("identityForm");
        const identityCode = document.getElementById("identityCode");
        const verifyButton = document.getElementById("verifyButton");

        async function showIdentityPrompt() {
            const result = await Swal.fire({
                title: "Confirm Your Identity",
                text: "Enter the identity code assigned to your account.",
                input: "password",
                inputPlaceholder: "Enter identity code",
                inputAttributes: {
                    autocapitalize: "off",
                    autocorrect: "off",
                    autocomplete: "off",
                    spellcheck: "false"
                },
                showCancelButton: true,
                confirmButtonText: "Verify & Continue",
                cancelButtonText: "Cancel",
                reverseButtons: true,
                allowOutsideClick: false,
                allowEscapeKey: false,
                inputValidator: (value) => {
                    if (!value || !value.trim()) {
                        return "Please enter your identity code.";
                    }
                }
            });

            if (result.isConfirmed) {
                identityCode.value = result.value;
                identityForm.submit();
            } else {
                window.location.href = "index.php";
            }
        }

        verifyButton.addEventListener("click", showIdentityPrompt);

        if (verificationError) {
            Swal.fire({
                icon: "error",
                title: "Verification Failed",
                text: verificationError,
                confirmButtonText: "Return to Home",
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then(() => {
                window.location.href = "index.php";
            });
        } else {
            // Show the identity prompt immediately when the page opens.
            showIdentityPrompt();
        }
    </script>

</body>
</html>
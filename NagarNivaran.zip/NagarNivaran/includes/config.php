<?php

$host = "localhost";
$dbname = "nagarnivaran";
$username = "root";
$password = "";

try {

    $conn = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password
    );

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    define("BASE_DIR", $_SERVER['DOCUMENT_ROOT'] . "/NagarNivaran/");
    define("BASE_URL", "/NagarNivaran/");

    function pathof($path){
        return BASE_DIR . ltrim($path, "/");
    }

    function urlof($path){
        return BASE_URL . ltrim($path, "/");
    }

    session_start();

} catch (PDOException $e) {

    die("Database connection failed: " . $e->getMessage());

}
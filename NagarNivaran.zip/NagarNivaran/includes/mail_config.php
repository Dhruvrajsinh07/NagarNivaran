<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';


function sendComplaintStatusEmail(
    string $citizenEmail,
    string $citizenName,
    int $caseId,
    string $issueTitle,
    string $newStatus,
    string $officerName
): bool {

    $mail = new PHPMailer(true);

    try {

        // SMTP configuration
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;

        // ==========================================
        // YOUR GMAIL ACCOUNT
        // ==========================================
        $mail->Username   = 'nagarnivaran2082@gmail.com';
        $mail->Password   = 'yqpb lhds sgpn gany';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Sender
        $mail->setFrom(
            'nagarnivaran2082@gmail.com',
            'NagarNivaran'
        );

        // Citizen
        $mail->addAddress(
            $citizenEmail,
            $citizenName
        );

        // ==========================================
        // NAGARNIVARAN LOGO
        // ==========================================

        $logoPath = realpath(
            __DIR__ . '/../assets/imgs/nn-final.png'
        );

        if ($logoPath && file_exists($logoPath)) {

            $mail->addEmbeddedImage(
                $logoPath,
                'nagarnivaran_logo',
                'nn-final.png',
                'base64',
                'image/png'
            );
        }

        // Email format
        $mail->isHTML(true);

        $mail->Subject =
            "NagarNivaran : Complaint Status Updated #NN-{$caseId}";

        // Load email template
        $templatePath =
            __DIR__ . '/../templates/Email.php';

        $emailBody = file_get_contents($templatePath);

        if ($emailBody === false) {
            return false;
        }

        // Secure values before inserting into HTML
        $replacements = [

            '{citizen_name}' =>
                htmlspecialchars(
                    $citizenName,
                    ENT_QUOTES,
                    'UTF-8'
                ),

            '{case_id}' =>
                htmlspecialchars(
                    (string)$caseId,
                    ENT_QUOTES,
                    'UTF-8'
                ),

            '{issue_title}' =>
                htmlspecialchars(
                    $issueTitle,
                    ENT_QUOTES,
                    'UTF-8'
                ),

            '{new_status}' =>
                htmlspecialchars(
                    $newStatus,
                    ENT_QUOTES,
                    'UTF-8'
                ),

            '{officer_name}' =>
                htmlspecialchars(
                    $officerName,
                    ENT_QUOTES,
                    'UTF-8'
                )
        ];

        $emailBody = strtr(
            $emailBody,
            $replacements
        );

        $mail->Body = $emailBody;

        // Plain-text fallback
        $mail->AltBody =
            "Dear {$citizenName},\n\n" .
            "Your NagarNivaran complaint #JMC-{$caseId} " .
            "has been updated.\n\n" .
            "Issue: {$issueTitle}\n" .
            "Current Status: {$newStatus}\n" .
            "Updated By: {$officerName}\n\n" .
            "Please log in to NagarNivaran to view the complete details.";

        $mail->send();

        return true;

    } catch (Exception $e) {

        echo "<pre>";
    echo "PHPMailer Error:\n";
    echo $mail->ErrorInfo;
    echo "\n\nException:\n";
    echo $e->getMessage();
    echo "</pre>";

        return false;
    }
}
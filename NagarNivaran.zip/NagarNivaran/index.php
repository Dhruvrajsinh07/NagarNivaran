<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once("./includes/config.php");

// Check if user is logged in
$isLoggedIn = isset($_SESSION["user_id"]);
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NagarNivaran (નગરનિવારણ) | Jamnagar Smart Civic OS</title>
    
    <link rel="icon" type="image/x-icon" href="<?= urlof('assets/imgs/nn-final.png')?>">

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Vadodara:wght@500;600;700&family=Outfit:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'saffron': '#FF9933',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                        'civic-canvas': '#F4F7F9',
                        'obsidian': '#0B1121',
                    },
                    fontFamily: {
                        heading: ['"Outfit"', 'sans-serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        gujarati: ['"Hind Vadodara"', 'sans-serif']
                    },
                    boxShadow: {
                        'soft-glass': '0 8px 32px 0 rgba(11, 17, 33, 0.04)',
                        'hover-glass': '0 12px 48px 0 rgba(255, 122, 0, 0.12)',
                        'glow-primary': '0 10px 40px -10px rgba(255, 122, 0, 0.4)',
                    }
                }
            }
        }
    </script>
    <style>
        /* --- CHANGED: Orange Scrollbar --- */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #F4F7F9; }
        ::-webkit-scrollbar-thumb { background: #FF9933; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #FF7A00; }
        
        /* Smooth Infinite Marquee */
        @keyframes marquee {
            0% { transform: translateX(0%); }
            100% { transform: translateX(-50%); }
        }
        .animate-marquee { display: flex; width: 200%; animation: marquee 35s linear infinite; }
        .animate-marquee:hover { animation-play-state: paused; }

        /* Gentle Float Animation */
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-6px); }
        }
        .animate-float { animation: float 6s ease-in-out infinite; }
        
        /* Orange Cross Pattern Background */
        .bg-cross-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }

        /* Glass Flash Button Animation */
        .glass-btn {
            position: relative;
            overflow: hidden;
        }
        .glass-btn::after {
            content: '';
            position: absolute;
            top: 0;
            left: -150%;
            width: 50%;
            height: 100%;
            background: linear-gradient(to right, transparent, rgba(255, 255, 255, 0.5), transparent);
            transform: skewX(-25deg);
            transition: none;
        }
        .glass-btn:hover::after {
            animation: glass-flash 0.65s ease-out forwards;
        }
        @keyframes glass-flash {
            0% { left: -150%; }
            100% { left: 200%; }
        }

        /* --- CHANGED: Pill Flash Animation --- */
        @keyframes pill-flash {
            0% { left: -100%; opacity: 0; }
            20% { opacity: 1; }
            100% { left: 200%; opacity: 0; }
        }
        .pill-flash-anim::after {
            content: '';
            position: absolute;
            top: 0; left: -100%;
            width: 50%; height: 100%;
            background: linear-gradient(to right, transparent, rgba(255, 255, 255, 0.9), transparent);
            transform: skewX(-25deg);
            animation: pill-flash 0.6s ease-out forwards;
        }
    </style>
</head>
<body class="bg-civic-canvas text-slate-800 font-sans antialiased selection:bg-saffron selection:text-white relative min-h-screen overflow-x-hidden">

    <div class="fixed inset-0 -z-20 bg-cross-pattern pointer-events-none"></div>
    <div class="fixed top-[-10%] left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-gradient-to-b from-orange-100/60 via-orange-50/20 to-transparent rounded-full blur-3xl pointer-events-none -z-10"></div>

    <header class="pt-8 sm:pt-12 pb-4 sm:pb-6 flex flex-col items-center justify-center relative z-40 text-center px-4">
        <div class="w-[110px] h-[110px] sm:w-[150px] sm:h-[150px] rounded-full bg-white shadow-lg border-4 border-orange-glow flex items-center justify-center overflow-hidden mb-4 sm:mb-5 relative group z-10 animate-float">
            <img src="<?= urlof('assets/imgs/nn-final.png')?>" alt="NagarNivaran Logo" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
        </div>
        <h1 class="font-heading text-4xl sm:text-6xl font-black tracking-tight text-slate-900">
            Nagar<span class="bg-gradient-to-r from-orange-glow to-tomato bg-clip-text text-transparent">Nivaran</span>
        </h1>
        <p class="font-gujarati text-slate-600 text-base sm:text-lg mt-1 sm:mt-2 font-medium">નગરનિવારણ • જામનગર મહાનગરપાલિકા*</p>
    </header>

    <div class="sticky top-4 sm:top-6 z-50 max-w-5xl mx-auto px-4 transition-all duration-300" id="sticky-dock">
        <nav class="bg-white/60 saturate-150 backdrop-blur-2xl border border-orange-50 rounded-full p-2 sm:p-2.5 shadow-lg hover:bg-white/80 transition-all duration-500 flex items-center justify-between mx-auto relative">
            
            <div id="nav-pill-group" class="hidden md:flex items-center relative bg-orange-400 p-1.5 rounded-full border border-orange-200 shadow-inner">
                
                <div id="pill-indicator" class="absolute h-[calc(100%-12px)] top-[6px] bg-orange-100 rounded-full transition-all duration-300 ease-out z-0 shadow-sm pointer-events-none overflow-hidden"></div>
                
                <a href="#" class="nav-item relative z-10 px-5 py-2 rounded-full font-bold text-sm transition-colors text-slate-900 active-link">Home</a>
                <a href="#how-it-works" class="nav-item relative z-10 px-5 py-2 rounded-full font-bold text-sm transition-colors text-white hover:text-slate-900">How it Works</a>
                <a href="#issues" class="nav-item relative z-10 px-5 py-2 rounded-full font-bold text-sm transition-colors text-white hover:text-slate-900">Issue Directory</a>
                <a href="#impact" class="nav-item relative z-10 px-5 py-2 rounded-full font-bold text-sm transition-colors text-white hover:text-slate-900">Impact</a>
                <a href="<?= urlof('templates/about.php')?>" class="nav-item relative z-10 px-5 py-2 rounded-full font-bold text-sm transition-colors text-white hover:text-slate-900">About Platform</a>
            </div>

            <button id="mobile-menu-btn" class="md:hidden flex items-center justify-center w-10 h-10 ml-1 rounded-full text-slate-900 hover:bg-orange-100 transition-colors focus:outline-none">
                <i class="fa-solid fa-bars text-lg"></i>
            </button>

            <div class="flex items-center gap-2 sm:gap-3 pr-1 sm:pr-1">
                <!-- <a href="<?= urlof('pages/user/login.php')?>" class="hidden sm:inline-flex glass-btn px-6 py-2.5 rounded-full bg-slate-800 text-white text-sm font-bold shadow-md hover:bg-orange-glow active:scale-95 transition-all duration-300">
                    Login
                </a>
                <a href="<?= urlof('pages/user/register.php')?>" class="glass-btn px-4 py-2 sm:px-6 sm:py-2.5 rounded-full bg-slate-800 text-white text-xs sm:text-sm font-bold shadow-md hover:bg-orange-glow active:scale-95 transition-all duration-300 flex items-center gap-2">
                    <span class="hidden sm:inline">Register</span>
                    <span class="sm:hidden">Register</span>
                    <i class="fa-solid fa-arrow-right text-[10px] sm:text-xs"></i>
                </a> -->
                <?php if ($isLoggedIn): ?>
                    <a href="<?= urlof('pages/user/dashboard.php') ?>" class="hidden sm:inline-flex glass-btn px-6 py-2.5 rounded-full bg-emerald-600 text-white text-sm font-bold shadow-md hover:bg-emerald-500 active:scale-95 transition-all duration-300">
                        Go to Dashboard
                    </a>
                    <a href="<?= urlof('api/user/logout.php') ?>" class="glass-btn px-4 py-2 sm:px-6 sm:py-2.5 rounded-full bg-slate-800 text-white text-xs sm:text-sm font-bold shadow-md hover:bg-red-500 active:scale-95 transition-all duration-300 flex items-center gap-2">
                        <span>Logout</span>
                    <i class="fa-solid fa-power-off text-[10px] sm:text-xs"></i>
                    </a>
                <?php else: ?>
                    <a href="<?= urlof('pages/user/login.php')?>" class="hidden sm:inline-flex glass-btn px-6 py-2.5 rounded-full bg-slate-800 text-white text-sm font-bold shadow-md hover:bg-orange-glow active:scale-95 transition-all duration-300">
                        Login
                    </a>
                    <a href="<?= urlof('pages/user/register.php')?>" class="glass-btn px-4 py-2 sm:px-6 sm:py-2.5 rounded-full bg-slate-800 text-white text-xs sm:text-sm font-bold shadow-md hover:bg-orange-glow active:scale-95 transition-all duration-300 flex items-center gap-2">
                    <span class="hidden sm:inline">Register</span>
                    <span class="sm:hidden">Register</span>
                    <i class="fa-solid fa-arrow-right text-[10px] sm:text-xs"></i>
                    </a>
                <?php endif; ?>
            </div>

            <div id="mobile-dropdown" class="absolute top-full left-0 right-0 mt-3 bg-white/95 backdrop-blur-xl border border-orange-100 rounded-3xl p-4 shadow-[0_20px_40px_rgba(0,0,0,0.1)] hidden flex-col gap-2 transition-all duration-300 transform origin-top md:hidden">
                <a href="#" class="px-4 py-3 rounded-xl font-bold text-sm text-slate-900 bg-orange-50 hover:bg-orange-100 transition-colors">Home</a>
                <a href="#how-it-works" class="px-4 py-3 rounded-xl font-bold text-sm text-slate-600 hover:bg-orange-50 hover:text-slate-900 transition-colors">How it Works</a>
                <a href="#issues" class="px-4 py-3 rounded-xl font-bold text-sm text-slate-600 hover:bg-orange-50 hover:text-slate-900 transition-colors">Issue Directory</a>
                <a href="#impact" class="px-4 py-3 rounded-xl font-bold text-sm text-slate-600 hover:bg-orange-50 hover:text-slate-900 transition-colors">Impact</a>
                <a href="<?= urlof('templates/about.php')?>" class="px-4 py-3 rounded-xl font-bold text-sm text-slate-600 hover:bg-orange-50 hover:text-slate-900 transition-colors">About Platform</a>
                <div class="h-px w-full bg-orange-100/50 my-1"></div>
                <!-- <a href="<?= urlof('pages/user/login.php')?>" class="px-4 py-3 rounded-xl font-bold text-sm text-white bg-slate-800 hover:bg-orange-glow text-center transition-colors shadow-md">Login to Dashboard</a> -->
                <?php if ($isLoggedIn): ?>
                    <a href="<?= urlof('pages/user/dashboard.php')?>" class="px-4 py-3 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 text-center transition-colors shadow-md">Open Dashboard</a>
                    <a href="<?= urlof('api/user/logout.php')?>" class="px-4 py-3 rounded-xl font-bold text-sm text-white bg-slate-800 hover:bg-red-500 text-center transition-colors shadow-md mt-2">Logout</a>
                <?php else: ?>
                    <a href="<?= urlof('pages/user/login.php')?>" class="px-4 py-3 rounded-xl font-bold text-sm text-white bg-slate-800 hover:bg-orange-glow text-center transition-colors shadow-md">Login to Dashboard</a>
                <?php endif; ?>
            </div>

        </nav>
    </div>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-20 sm:pb-24 space-y-20 sm:space-y-32">

        <section class="text-center space-y-8 sm:space-y-10 max-w-5xl mx-auto">
            <div class="inline-flex items-center bg-white border border-orange-200 p-1 sm:p-1.5 rounded-full shadow-sm max-w-[95%] sm:max-w-full overflow-hidden">
                <span class="bg-orange-100 text-orange-glow font-bold px-3 py-1 sm:px-4 sm:py-1.5 rounded-full text-[10px] sm:text-xs tracking-wider uppercase shrink-0 flex items-center gap-1.5 sm:gap-2">
                    <span class="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-tomato animate-pulse"></span> Live Update
                </span>
                <div class="overflow-hidden w-full select-none ml-2 relative mask-image: linear-gradient(to right, transparent, black 10%, black 90%, transparent);">
                    <div class="animate-marquee whitespace-nowrap text-[11px] sm:text-xs font-medium text-slate-600 flex gap-6 sm:gap-8">
                        <span>⚡ PGVCL: Streetlight repairs ongoing in Ward 4 &bull;</span>
                        <span>🚜 JMC: Monsoon pothole patching initiated in Ranjit Nagar &bull;</span>
                        <span>💧 GWSSB: Aji Dam water pressure normalized &bull;</span>
                        <span>⚡ PGVCL: Streetlight repairs ongoing in Ward 4 &bull;</span>
                    </div>
                </div>
            </div>

            <div class="space-y-4 sm:space-y-6 relative px-2">
                <h2 class="font-heading text-4xl sm:text-5xl md:text-7xl font-black text-slate-900 tracking-tight leading-[1.1] sm:leading-[1.05]">
                    Build a Better Jamnagar, <br class="hidden sm:block">
                    <span class="relative inline-block mt-1 sm:mt-2">
                        <span class="relative z-10 bg-gradient-to-r from-saffron via-orange-glow to-tomato bg-clip-text text-transparent">Together.</span>
                        <svg class="absolute w-full h-3 sm:h-4 -bottom-1 left-0 text-orange-200 -z-10" viewBox="0 0 100 10" preserveAspectRatio="none"><path d="M0 5 Q 50 15 100 5" stroke="currentColor" stroke-width="4" fill="transparent"/></svg>
                    </span>
                </h2>
                
                <p class="text-slate-500 text-base sm:text-lg md:text-xl max-w-2xl mx-auto font-medium leading-relaxed">
                    The official smart civic OS for Jamnagar. Report neighborhood issues in under 60 seconds and track real-time resolution directly from the municipal engineers.
                </p>
            </div>

            <div class="mt-12 sm:mt-16 grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 max-w-5xl mx-auto">
                <div class="bg-orange-50 border-2 border-orange-500 rounded-[20px] p-6 sm:p-8 shadow-[0_15px_40px_-10px_rgba(255,122,0,0.35)] relative overflow-hidden group">
                    <div class="absolute -top-10 -right-10 w-32 h-32 bg-white/50 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700 pointer-events-none"></div>
                    <div class="font-heading font-black text-3xl sm:text-4xl text-slate-900 relative z-10">16</div>
                    <div class="text-[10px] sm:text-xs text-orange-600 font-bold uppercase tracking-widest mt-1 sm:mt-2 relative z-10">City Wards</div>
                </div>
                
                <div class="bg-orange-50 border-2 border-orange-500 rounded-[20px] p-6 sm:p-8 shadow-[0_15px_40px_-10px_rgba(255,122,0,0.35)] relative overflow-hidden group">
                    <div class="absolute -top-10 -right-10 w-32 h-32 bg-white/50 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700 pointer-events-none"></div>
                    <div class="font-heading font-black text-3xl sm:text-4xl text-slate-900 relative z-10">24/7</div>
                    <div class="text-[10px] sm:text-xs text-orange-600 font-bold uppercase tracking-widest mt-1 sm:mt-2 relative z-10">Monitoring</div>
                </div>
                
                <div class="bg-orange-50 border-2 border-orange-500 rounded-[20px] p-6 sm:p-8 shadow-[0_15px_40px_-10px_rgba(255,122,0,0.35)] relative overflow-hidden group">
                    <div class="absolute -top-10 -right-10 w-32 h-32 bg-white/50 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700 pointer-events-none"></div>
                    <div class="font-heading font-black text-3xl sm:text-4xl text-slate-900 relative z-10">4.2h</div>
                    <div class="text-[10px] sm:text-xs text-orange-600 font-bold uppercase tracking-widest mt-1 sm:mt-2 relative z-10">Avg. Resolution</div>
                </div>
                
                <div class="bg-orange-50 border-2 border-orange-500 rounded-[20px] p-6 sm:p-8 shadow-[0_15px_40px_-10px_rgba(255,122,0,0.35)] relative overflow-hidden group">
                    <div class="absolute -top-10 -right-10 w-32 h-32 bg-white/50 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700 pointer-events-none"></div>
                    <div class="font-heading font-black text-3xl sm:text-4xl text-slate-900 relative z-10">100%</div>
                    <div class="text-[10px] sm:text-xs text-orange-600 font-bold uppercase tracking-widest mt-1 sm:mt-2 relative z-10">GPS Tagged</div>
                </div>
            </div>
        </section>

        <section id="how-it-works" class="max-w-6xl mx-auto">
            <div class="text-center mb-12 sm:mb-16">
                <h2 class="font-heading text-3xl sm:text-4xl font-black text-slate-900">Civic Action in 3 Steps</h2>
                <p class="text-slate-500 mt-3 sm:mt-4 text-sm sm:text-base px-4">We've eliminated the red tape. Resolving issues is now completely digital.</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 relative">
                <div class="hidden md:block absolute top-1/2 left-10 right-10 h-0.5 bg-gradient-to-r from-orange-200 via-orange-300 to-orange-200 -z-10 -translate-y-1/2"></div>

                <div class="bg-white rounded-3xl p-6 sm:p-8 border border-orange-100 shadow-soft-glass hover:shadow-hover-glass transition-all duration-300 relative animate-float" style="animation-delay: 0s;">
                    <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-orange-100 border-4 border-white shadow-sm flex items-center justify-center text-orange-glow font-black text-lg sm:text-xl absolute -top-5 sm:-top-6 left-6 sm:left-8">1</div>
                    <div class="text-orange-glow text-2xl sm:text-3xl mb-4 sm:mb-6 mt-2"><i class="fa-solid fa-camera-retro"></i></div>
                    <h3 class="font-heading font-bold text-lg sm:text-xl text-slate-900 mb-2">Snap & Locate</h3>
                    <p class="text-xs sm:text-sm text-slate-500 leading-relaxed">See a broken pipe or pothole? Just take a photo. Our system automatically grabs the exact GPS coordinates.</p>
                </div>

                <div class="bg-white rounded-3xl p-6 sm:p-8 border border-orange-100 shadow-soft-glass hover:shadow-hover-glass transition-all duration-300 relative animate-float" style="animation-delay: 1s;">
                    <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-orange-100 border-4 border-white shadow-sm flex items-center justify-center text-orange-glow font-black text-lg sm:text-xl absolute -top-5 sm:-top-6 left-6 sm:left-8">2</div>
                    <div class="text-saffron text-2xl sm:text-3xl mb-4 sm:mb-6 mt-2"><i class="fa-solid fa-file-signature"></i></div>
                    <h3 class="font-heading font-bold text-lg sm:text-xl text-slate-900 mb-2">Select Category</h3>
                    <p class="text-xs sm:text-sm text-slate-500 leading-relaxed">Choose from our standardized issue directory. This routes your complaint directly to the correct municipal department.</p>
                </div>

                <div class="bg-white rounded-3xl p-6 sm:p-8 border border-orange-100 shadow-soft-glass hover:shadow-hover-glass transition-all duration-300 relative animate-float" style="animation-delay: 2s;">
                    <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-orange-100 border-4 border-white shadow-sm flex items-center justify-center text-orange-glow font-black text-lg sm:text-xl absolute -top-5 sm:-top-6 left-6 sm:left-8">3</div>
                    <div class="text-emerald-500 text-2xl sm:text-3xl mb-4 sm:mb-6 mt-2"><i class="fa-solid fa-list-check"></i></div>
                    <h3 class="font-heading font-bold text-lg sm:text-xl text-slate-900 mb-2">Track Progress</h3>
                    <p class="text-xs sm:text-sm text-slate-500 leading-relaxed">Get real-time updates on your dashboard as officers assign, review, and fix the issue on the ground.</p>
                </div>
            </div>
        </section>

        <section id="issues" class="space-y-8 sm:space-y-12 max-w-7xl mx-auto">
            <div class="flex flex-col md:flex-row md:items-end justify-between border-b border-orange-200 pb-4 sm:pb-6">
                <div>
                    <span class="text-[10px] sm:text-xs font-bold text-orange-glow uppercase tracking-widest bg-white border border-orange-200 shadow-sm px-3 sm:px-4 py-1.5 rounded-full">Standardized Taxonomy</span>
                    <h2 class="font-heading text-3xl sm:text-4xl font-black text-slate-900 tracking-tight mt-3 sm:mt-4">Civic Issue Directory</h2>
                </div>
                <p class="font-gujarati text-slate-500 text-xs sm:text-sm max-w-sm mt-3 md:mt-0 font-medium leading-relaxed">
                    આ વિભાગમાં દર્શાવેલ શ્રેણીઓ મુજબ મહાનગરપાલિકા દ્વારા ત્વરિત પગલાં લેવામાં આવશે.
                </p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 text-left">
                
                <div class="bg-white p-5 sm:p-6 rounded-[24px] border border-slate-200 shadow-soft-glass hover:shadow-hover-glass hover:border-orange-300 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between">
                    <div>
                        <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-slate-50 text-slate-700 flex items-center justify-center mb-4 sm:mb-5 border border-slate-100">
                            <i class="fa-solid fa-road text-lg sm:text-xl"></i>
                        </div>
                        <h3 class="font-heading font-bold text-slate-900 text-base sm:text-lg mb-1 sm:mb-2">Road Potholes</h3>
                        <p class="text-xs sm:text-sm text-slate-500 font-normal leading-relaxed">Deep asphalt potholes, monsoon surface erosion, or sunken transit trenches.</p>
                    </div>
                    <div class="pt-3 sm:pt-4 mt-5 border-t border-slate-100 flex items-center text-[11px] sm:text-xs font-bold text-slate-400">
                        <i class="fa-solid fa-clock mr-2 text-orange-400"></i> SLA: 48 Hours
                    </div>
                </div>

                <div class="bg-white p-5 sm:p-6 rounded-[24px] border border-slate-200 shadow-soft-glass hover:shadow-hover-glass hover:border-orange-300 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between">
                    <div>
                        <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4 sm:mb-5 border border-amber-100">
                            <i class="fa-solid fa-trash-can text-lg sm:text-xl"></i>
                        </div>
                        <h3 class="font-heading font-bold text-slate-900 text-base sm:text-lg mb-1 sm:mb-2">Garbage Overflow</h3>
                        <p class="text-xs sm:text-sm text-slate-500 font-normal leading-relaxed">Uncollected community dumpsters, market rot, or factory scrap piles.</p>
                    </div>
                    <div class="pt-3 sm:pt-4 mt-5 border-t border-slate-100 flex items-center text-[11px] sm:text-xs font-bold text-slate-400">
                        <i class="fa-solid fa-clock mr-2 text-orange-400"></i> SLA: 24 Hours
                    </div>
                </div>

                <div class="bg-white p-5 sm:p-6 rounded-[24px] border border-slate-200 shadow-soft-glass hover:shadow-hover-glass hover:border-orange-300 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between">
                    <div>
                        <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4 sm:mb-5 border border-blue-100">
                            <i class="fa-solid fa-faucet-drip text-lg sm:text-xl"></i>
                        </div>
                        <h3 class="font-heading font-bold text-slate-900 text-base sm:text-lg mb-1 sm:mb-2">Water Leakage</h3>
                        <p class="text-xs sm:text-sm text-slate-500 font-normal leading-relaxed">Ruptured feeder lines, contaminated drinking tap output, or low pressure.</p>
                    </div>
                    <div class="pt-3 sm:pt-4 mt-5 border-t border-slate-100 flex items-center text-[11px] sm:text-xs font-bold text-slate-400">
                        <i class="fa-solid fa-clock mr-2 text-orange-400"></i> SLA: 12 Hours
                    </div>
                </div>

                <div class="bg-white p-5 sm:p-6 rounded-[24px] border border-slate-200 shadow-soft-glass hover:shadow-hover-glass hover:border-orange-300 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between">
                    <div>
                        <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-yellow-50 text-yellow-500 flex items-center justify-center mb-4 sm:mb-5 border border-yellow-100">
                            <i class="fa-solid fa-lightbulb text-lg sm:text-xl"></i>
                        </div>
                        <h3 class="font-heading font-bold text-slate-900 text-base sm:text-lg mb-1 sm:mb-2">Street Lights</h3>
                        <p class="text-xs sm:text-sm text-slate-500 font-normal leading-relaxed">Dead PGVCL street lamps, flickering LEDs, or dark highway junctions.</p>
                    </div>
                    <div class="pt-3 sm:pt-4 mt-5 border-t border-slate-100 flex items-center text-[11px] sm:text-xs font-bold text-slate-400">
                        <i class="fa-solid fa-clock mr-2 text-orange-400"></i> SLA: 36 Hours
                    </div>
                </div>

                <div class="bg-white p-5 sm:p-6 rounded-[24px] border border-slate-200 shadow-soft-glass hover:shadow-hover-glass hover:border-orange-300 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between">
                    <div>
                        <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center mb-4 sm:mb-5 border border-cyan-100">
                            <i class="fa-solid fa-water text-lg sm:text-xl"></i>
                        </div>
                        <h3 class="font-heading font-bold text-slate-900 text-base sm:text-lg mb-1 sm:mb-2">Drainage Faults</h3>
                        <p class="text-xs sm:text-sm text-slate-500 font-normal leading-relaxed">Choked storm gutters, monsoon backflow, or damaged sewage lids.</p>
                    </div>
                    <div class="pt-3 sm:pt-4 mt-5 border-t border-slate-100 flex items-center text-[11px] sm:text-xs font-bold text-slate-400">
                        <i class="fa-solid fa-clock mr-2 text-orange-400"></i> SLA: 24 Hours
                    </div>
                </div>

                <div class="bg-white p-5 sm:p-6 rounded-[24px] border border-slate-200 shadow-soft-glass hover:shadow-hover-glass hover:border-orange-300 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between">
                    <div>
                        <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 sm:mb-5 border border-emerald-100">
                            <i class="fa-solid fa-tree text-lg sm:text-xl"></i>
                        </div>
                        <h3 class="font-heading font-bold text-slate-900 text-base sm:text-lg mb-1 sm:mb-2">Public Parks</h3>
                        <p class="text-xs sm:text-sm text-slate-500 font-normal leading-relaxed">Fallen storm trees over walking tracks or damaged outdoor gym equipment.</p>
                    </div>
                    <div class="pt-3 sm:pt-4 mt-5 border-t border-slate-100 flex items-center text-[11px] sm:text-xs font-bold text-slate-400">
                        <i class="fa-solid fa-clock mr-2 text-orange-400"></i> SLA: 72 Hours
                    </div>
                </div>

                <div class="bg-white p-5 sm:p-6 rounded-[24px] border border-slate-200 shadow-soft-glass hover:shadow-hover-glass hover:border-orange-300 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between">
                    <div>
                        <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-4 sm:mb-5 border border-purple-100">
                            <i class="fa-solid fa-dumpster text-lg sm:text-xl"></i>
                        </div>
                        <h3 class="font-heading font-bold text-slate-900 text-base sm:text-lg mb-1 sm:mb-2">Illegal Dumping</h3>
                        <p class="text-xs sm:text-sm text-slate-500 font-normal leading-relaxed">Unauthorized chemical containers or malba rubble dropped near bypass limits.</p>
                    </div>
                    <div class="pt-3 sm:pt-4 mt-5 border-t border-slate-100 flex items-center text-[11px] sm:text-xs font-bold text-slate-400">
                        <i class="fa-solid fa-clock mr-2 text-orange-400"></i> SLA: 48 Hours
                    </div>
                </div>

                <div class="bg-red-50 p-5 sm:p-6 rounded-[24px] border border-red-200 shadow-soft-glass flex flex-col justify-between relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-20 h-20 sm:w-24 sm:h-24 bg-red-100 rounded-bl-full -z-10"></div>
                    <div>
                        <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-tomato text-white flex items-center justify-center mb-4 sm:mb-5 shadow-md shadow-tomato/30">
                            <i class="fa-solid fa-triangle-exclamation text-lg sm:text-xl"></i>
                        </div>
                        <h3 class="font-heading font-bold text-slate-900 text-base sm:text-lg mb-1 sm:mb-2">Critical Safety</h3>
                        <p class="text-xs sm:text-sm text-slate-700 font-normal leading-relaxed">Missing sewer covers, open electrical boxes, or structural collapse risks.</p>
                    </div>
                    <div class="pt-3 sm:pt-4 mt-5 border-t border-red-200/60 flex items-center text-[11px] sm:text-xs font-black text-tomato">
                        <i class="fa-solid fa-bolt mr-2"></i> CRITICAL: 2 Hour SLA
                    </div>
                </div>

            </div>
        </section>

        <section id="impact" class="bg-obsidian rounded-[32px] sm:rounded-[40px] p-8 sm:p-20 text-white relative overflow-hidden max-w-7xl mx-auto shadow-2xl">
            <div class="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-gradient-to-b from-orange-500/20 to-transparent pointer-events-none"></div>

            <div class="text-center max-w-2xl mx-auto mb-10 sm:mb-16 relative z-10">
                <span class="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-orange-glow bg-orange-500/10 px-3 sm:px-4 py-1.5 rounded-full border border-orange-500/20">System Telemetry</span>
                <h2 class="font-heading text-2xl sm:text-4xl md:text-5xl font-black mt-3 sm:mt-4">Real-Time Platform Impact</h2>
            </div>

            <div class="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 relative z-10 divide-x divide-slate-700">
                <div class="text-center px-2 sm:px-4">
                    <div class="text-3xl sm:text-5xl font-heading font-black mb-1 sm:mb-2 stat-number text-white" data-target="5200" data-suffix="+">0</div>
                    <div class="text-[10px] sm:text-sm font-medium text-slate-400">Issues Reported</div>
                </div>
                <div class="text-center px-2 sm:px-4">
                    <div class="text-3xl sm:text-5xl font-heading font-black mb-1 sm:mb-2 stat-number text-white" data-target="4850" data-suffix="+">0</div>
                    <div class="text-[10px] sm:text-sm font-medium text-slate-400">Resolved</div>
                </div>
                <div class="text-center px-2 sm:px-4 border-t border-slate-700 lg:border-t-0 pt-6 lg:pt-0 lg:border-l">
                    <div class="text-3xl sm:text-5xl font-heading font-black mb-1 sm:mb-2 stat-number text-white" data-target="1200" data-suffix="+">0</div>
                    <div class="text-[10px] sm:text-sm font-medium text-slate-400">Active Citizens</div>
                </div>
                <div class="text-center px-2 sm:px-4 border-t border-slate-700 lg:border-t-0 pt-6 lg:pt-0">
                    <div class="text-3xl sm:text-5xl font-heading font-black mb-1 sm:mb-2 stat-number text-orange-glow" data-target="93" data-suffix="%">0</div>
                    <div class="text-[10px] sm:text-sm font-medium text-slate-400">SLA Success</div>
                </div>
            </div>
        </section>
        
        <section id="jan-bhagidari">
            <div class="bg-white border border-slate-200 rounded-[32px] sm:rounded-[36px] p-8 sm:p-16 text-center shadow-soft-glass relative overflow-hidden">
                <div class="absolute inset-0 bg-cross-pattern opacity-10 pointer-events-none"></div>
                <span class="font-gujarati font-bold text-orange-glow text-sm sm:text-lg inline-block bg-orange-50 px-4 sm:px-5 py-1 sm:py-1.5 rounded-full border border-orange-100 mb-3 sm:mb-4 shadow-sm">જનભાગીદારી થી જામનગરનો વિકાસ</span>
                <h2 class="font-heading text-2xl sm:text-4xl md:text-5xl font-black text-slate-900 tracking-tight">Be a Part of the Change</h2>
                <p class="text-slate-500 text-sm sm:text-lg max-w-2xl mx-auto mt-3 sm:mt-4 font-normal leading-relaxed">
                    Join thousands of active citizens monitoring the city's infrastructure. Every verified report contributes directly to the smart allocation of municipal resources and the betterment of Jamnagar.
                </p>
                <div class="pt-6 sm:pt-8">
                    <a href="<?= urlof('pages/user/register.php') ?>" class="glass-btn inline-flex items-center justify-center px-8 sm:px-10 py-3 sm:py-4 rounded-full bg-slate-800 text-white font-heading font-bold text-xs sm:text-sm tracking-wide shadow-xl hover:bg-orange-glow active:scale-95 transition-all duration-300">
                        Join Citizen Network &rarr;
                    </a>
                </div>
            </div>
        </section>

    </main>

    <footer class="bg-zinc-900 text-slate-400 pt-12 sm:pt-16 pb-6 sm:pb-8 border-t border-zinc-800">
        <div class="max-w-7xl mx-auto px-6 lg:px-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 sm:gap-12 pb-10 sm:pb-12 border-b border-zinc-800">
            
            <div class="lg:col-span-1 space-y-4">
                <div class="flex items-center gap-2">
                    <span class="font-heading font-black text-xl sm:text-2xl text-white tracking-tight">Nagar<span class="text-orange-glow">Nivaran</span></span>
                </div>
                <p class="text-xs sm:text-sm leading-relaxed text-slate-400 pr-4">
                    Official digital grievance and telemetry portal for Jamnagar Municipal Corporation (JMC) * (Proposed) .
                </p>
                <div class="flex gap-4 pt-1 sm:pt-2">
                    <a href="#" class="text-slate-500 hover:text-white transition-colors"><i class="fa-brands fa-twitter text-base sm:text-lg"></i></a>
                    <a href="#" class="text-slate-500 hover:text-white transition-colors"><i class="fa-brands fa-facebook text-base sm:text-lg"></i></a>
                    <a href="#" class="text-slate-500 hover:text-white transition-colors"><i class="fa-brands fa-instagram text-base sm:text-lg"></i></a>
                </div>
            </div>

            <div class="space-y-3 sm:space-y-4">
                <h4 class="text-white font-bold text-xs sm:text-sm">Platform</h4>
                <a href="<?= urlof('pages/user/dashboard.php')?>" class="block text-xs sm:text-sm hover:text-white transition-colors">Citizen Dashboard</a>
                <a href="<?= urlof('templates/about.php')?>" class="block text-xs sm:text-sm hover:text-white transition-colors">About Platform</a>
                <a href="#" class="block text-xs sm:text-sm hover:text-white transition-colors">JMC Ward Map</a>
                <a href="#" class="block text-xs sm:text-sm hover:text-white transition-colors">Data API</a>
            </div>

            <div class="space-y-3 sm:space-y-4">
                <h4 class="text-white font-bold text-xs sm:text-sm">Resources</h4>
                <a href="<?= urlof('templates/user_manual.php')?>" class="block text-xs sm:text-sm hover:text-white transition-colors">User Manual</a>
                <a href="<?= urlof('templates/sla_charter.php')?>" class="block text-xs sm:text-sm hover:text-white transition-colors">SLA Charter</a>
                <a href="<?= urlof('templates/privacy.php')?>" class="block text-xs sm:text-sm hover:text-white transition-colors">Privacy Policy</a>
                <a href="<?= urlof('templates/T&C.php')?>" class="block text-xs sm:text-sm hover:text-white transition-colors">Terms of Service</a>
            </div>

            <div class="space-y-3 sm:space-y-4">
                <h4 class="text-white font-bold text-xs sm:text-sm">Contact JMC Control Room</h4>
                <p class="text-xs sm:text-sm flex items-center gap-2 text-slate-300"><i class="fa-solid fa-phone text-orange-glow"></i> 1800-2xx-xxxx</p>
                <p class="text-xs sm:text-sm flex items-center gap-2 text-slate-300"><i class="fa-solid fa-envelope text-orange-glow"></i> info@jamnagarsmartcity.gov</p>
                <p class="text-xs sm:text-sm flex items-start gap-2 mt-2 text-slate-400 pr-4">
                    <i class="fa-solid fa-location-dot mt-1 text-orange-glow"></i>
                    Integrated Command & Control Center (ICCC), Ranjit Nagar, Jamnagar
                </p>
            </div>

        </div>

        <div class="max-w-7xl mx-auto px-6 lg:px-8 pt-6 sm:pt-8 flex flex-col md:flex-row justify-between items-center text-[10px] sm:text-xs text-center md:text-left gap-2 sm:gap-0">
            <p>&copy; 2026 Jamnagar Municipal Corporation*. All rights reserved.</p>
            <p class="mt-1 md:mt-0">Built under National Smart Cities Mission.</p>
        </div>

        <!-- Disclaimer -->
        <div class="max-w-7xl mx-auto px-6 lg:px-8">
            <div class="border-t border-slate-200 mt-4 pt-4 pb-6 text-center">
                <p class="text-[9px] sm:text-[12px] leading-relaxed text-slate-400">
                    <span class="font-semibold text-slate-500">*Disclaimer:</span>
                    NagarNivaran is developed solely as an academic/practice project for demonstration purposes
                    and is not affiliated with or officially endorsed by Jamnagar Municipal Corporation (JMC).
                </p>
            </div>
        </div>
    </footer>

    <script>
        /* Mobile Menu Toggle Logic */
        const mobileMenuBtn = document.getElementById('mobile-menu-btn');
        const mobileDropdown = document.getElementById('mobile-dropdown');

        if (mobileMenuBtn && mobileDropdown) {
            mobileMenuBtn.addEventListener('click', () => {
                mobileDropdown.classList.toggle('hidden');
                mobileDropdown.classList.toggle('flex');
            });

            // Close menu when clicking a link
            mobileDropdown.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    mobileDropdown.classList.add('hidden');
                    mobileDropdown.classList.remove('flex');
                });
            });
        }

        /* --- Navbar Shifting Pill Logic (Now with Flash!) --- */
        const navItems = document.querySelectorAll('#nav-pill-group .nav-item');
        const pillIndicator = document.getElementById('pill-indicator');
        const navContainer = document.getElementById('nav-pill-group');

        function movePill(element) {
            if (!element || !pillIndicator) return;
            pillIndicator.style.width = `${element.offsetWidth}px`;
            pillIndicator.style.left = `${element.offsetLeft}px`;
            
            // Trigger the Flash Animation
            pillIndicator.classList.remove('pill-flash-anim');
            void pillIndicator.offsetWidth; // Force a DOM reflow to restart animation
            pillIndicator.classList.add('pill-flash-anim');
        }
        
        // Initial setup
        window.addEventListener('DOMContentLoaded', () => {
            if (navItems.length > 0) {
                movePill(document.querySelector('.active-link') || navItems[0]);
            }
        });

        navItems.forEach(item => {
            item.addEventListener('mouseenter', (e) => {
                movePill(e.target);
                navItems.forEach(nav => {
                    nav.classList.remove('text-slate-900');
                    nav.classList.add('text-white');
                });
                e.target.classList.remove('text-white');
                e.target.classList.add('text-slate-900');
            });
        });

        if (navContainer) {
            navContainer.addEventListener('mouseleave', () => {
                const active = document.querySelector('.active-link') || navItems[0];
                movePill(active);
                navItems.forEach(nav => {
                    nav.classList.remove('text-slate-900');
                    nav.classList.add('text-white');
                });
                active.classList.remove('text-white');
                active.classList.add('text-slate-900');
            });
        }

        /* Animated Statistics Counters */
        const statsSection = document.getElementById('impact');
        const counters = document.querySelectorAll('.stat-number');
        let triggered = false;

        const runCounters = () => {
            counters.forEach(c => {
                const target = +c.getAttribute('data-target');
                const suffix = c.getAttribute('data-suffix') || '';
                let val = 0;
                const inc = target / 50; 

                const update = () => {
                    val += inc;
                    if (val < target) {
                        c.innerText = Math.ceil(val).toLocaleString() + suffix;
                        requestAnimationFrame(update);
                    } else {
                        c.innerText = target.toLocaleString() + suffix;
                    }
                };
                update();
            });
        };

        const observer = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting && !triggered) {
                runCounters();
                triggered = true;
            }
        }, { threshold: 0.5 });

        if (statsSection) observer.observe(statsSection);
    </script>
</body>
</html>
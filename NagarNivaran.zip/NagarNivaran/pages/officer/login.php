<?php
require_once("../../includes/config.php");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// If officer is already logged in, don't show login again
if (isset($_SESSION["officer_id"])) {
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Officer Command Login | NagarNivaran</title>

    <!-- Tailwind -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    >

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Courier+Prime:wght@400;700&family=Hind+Vadodara:wght@500;600;700&family=IBM+Plex+Serif:wght@600;700&family=Outfit:wght@500;600;700;800;900&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap"
        rel="stylesheet"
    >

    <!-- SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'saffron': '#FF9933',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                        'civic-bg': '#F1F5F9',
                        'paper': '#FFFFFF',
                        'ink': '#0F172A',
                    },

                    fontFamily: {
                        heading: ['"Outfit"', 'sans-serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        gujarati: ['"Hind Vadodara"', 'sans-serif'],
                        typewriter: ['"Courier Prime"', 'monospace'],
                        official: ['"IBM Plex Serif"', 'serif'],
                    }
                }
            }
        }
    </script>

    <style>

        /* Orange Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #F1F5F9;
        }

        ::-webkit-scrollbar-thumb {
            background: #FF7A00;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #FF6347;
        }

        .paper-input {
            background: transparent !important;
            border-top: 0 !important;
            border-left: 0 !important;
            border-right: 0 !important;
            border-bottom: 2px solid #0F172A !important;
            border-radius: 0 !important;
            box-shadow: none !important;
        }

        .paper-input:focus {
            outline: none !important;
            border-bottom-color: #FF7A00 !important;
        }

        .paper-input.error {
            border-bottom-color: #FF6347 !important;
        }

        .paper-input.success {
            border-bottom-color: #10B981 !important;
        }

        .loader {
            width: 18px;
            height: 18px;
            border: 2px solid rgba(255,255,255,.35);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin .7s linear infinite;
            display: inline-block;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* Cross Pattern Background */
        .bg-cross-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }

        /* Glass Flash Button Animation */
        .glass-flash {
            position: relative;
            overflow: hidden;
        }
        .glass-flash::after {
            content: '';
            position: absolute;
            top: 0;
            left: -150%;
            width: 50%;
            height: 100%;
            background: linear-gradient(to right, transparent, rgba(255, 255, 255, 0.5), transparent);
            transform: skewX(-25deg);
            transition: none;
        }
        .glass-flash:hover::after {
            animation: glass-flash-anim 0.65s ease-out forwards;
        }
        @keyframes glass-flash-anim {
            0% { left: -150%; }
            100% { left: 200%; }
        }

    </style>

</head>


<body
    class="bg-civic-bg text-slate-800 font-sans min-h-screen flex items-center justify-center p-4 relative overflow-x-hidden overflow-y-auto"
>

    <!-- Backgrounds (Cross Overlay Only) -->
    <div class="fixed inset-0 -z-20 bg-cross-pattern pointer-events-none"></div>

    <!-- Decorative circles -->
    <div
        class="fixed -top-32 -right-32 w-96 h-96 rounded-full border-[40px] border-orange-100 opacity-40 pointer-events-none"
    ></div>

    <div
        class="fixed -bottom-40 -left-40 w-[500px] h-[500px] rounded-full border-[50px] border-slate-200 opacity-40 pointer-events-none"
    ></div>


    <!-- Main Login Card Wrapper -->
    <div class="w-full max-w-5xl">

        <!-- Top Government Bar -->
        <div
            class="flex flex-col sm:flex-row justify-between items-center gap-2 mb-4 px-2 text-[10px] font-mono font-bold tracking-widest text-slate-500 uppercase"
        >

            <span>
                <i class="fa-solid fa-building-columns text-orange-glow mr-1"></i>
                Jamnagar Municipal Corporation
            </span>

            <span class="text-tomato">
                [ OFFICIAL OFFICER ACCESS ]
            </span>

        </div>


        <!-- Card -->
        <div
            class="bg-white rounded-2xl border border-slate-200 shadow-[0_25px_70px_rgba(15,23,42,0.15)] overflow-hidden flex flex-col md:flex-row"
        >


            <!-- LEFT SIDE -->
            <div
                class="w-full md:w-[42%] bg-slate-900 text-white p-8 sm:p-12 flex flex-col justify-between relative overflow-hidden"
            >

                <!-- Decorative -->
                <div
                    class="absolute -right-24 -top-24 w-64 h-64 rounded-full border-[30px] border-orange-glow/10"
                ></div>

                <div
                    class="absolute -left-20 -bottom-20 w-56 h-56 rounded-full border-[25px] border-tomato/10"
                ></div>


                <div class="relative z-10">

                    <!-- Logo (Tighter Circle Space & Hover Zoom) -->
                    <div class="flex justify-center mb-8">
                        <div
                            class="w-[130px] h-[130px] rounded-full overflow-hidden border-2 border-white/20 bg-white p-0 shadow-xl cursor-pointer group/logo"
                        >
                            <img
                                src="../../assets/imgs/nn-final.png"
                                alt="NagarNivaran Logo"
                                onerror="this.src='https://placehold.co/130x130/FF7A00/FFFFFF?text=NN'"
                                class="w-full h-full object-cover transition-transform duration-500 group-hover/logo:scale-110"
                            >
                        </div>
                    </div>

                    <div class="text-center">

                        <h1
                            class="font-heading font-black text-3xl tracking-tight"
                        >
                            Nagar<span class="text-orange-glow">Nivaran</span>
                        </h1>

                        <p
                            class="font-gujarati font-bold text-sm text-tomato mt-1"
                        >
                            જામનગર મહાનગરપાલિકા
                        </p>

                        <div
                            class="mt-5 inline-flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-2 rounded-lg"
                        >

                            <span
                                class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"
                            ></span>

                            <span
                                class="font-mono text-[10px] tracking-widest text-slate-300 uppercase"
                            >
                                Command Network Online
                            </span>

                        </div>

                    </div>


                    <!-- Description -->
                    <div class="mt-10 space-y-5">

                        <div class="flex gap-4">

                            <div
                                class="w-10 h-10 shrink-0 rounded-lg bg-orange-glow/10 border border-orange-glow/20 flex items-center justify-center text-orange-glow"
                            >
                                <i class="fa-solid fa-shield-halved"></i>
                            </div>

                            <div>

                                <h3
                                    class="font-heading font-bold text-sm"
                                >
                                    Authorized Personnel Only
                                </h3>

                                <p
                                    class="text-xs text-slate-400 mt-1 leading-relaxed"
                                >
                                    This command desk is restricted to verified municipal officers.
                                </p>

                            </div>

                        </div>


                        <div class="flex gap-4">

                            <div
                                class="w-10 h-10 shrink-0 rounded-lg bg-orange-glow/10 border border-orange-glow/20 flex items-center justify-center text-orange-glow"
                            >
                                <i class="fa-solid fa-database"></i>
                            </div>

                            <div>

                                <h3
                                    class="font-heading font-bold text-sm"
                                >
                                    Live Civic Dispatch
                                </h3>

                                <p
                                    class="text-xs text-slate-400 mt-1 leading-relaxed"
                                >
                                    Review and process citizen complaints assigned to your department.
                                </p>

                            </div>

                        </div>


                        <div class="flex gap-4">

                            <div
                                class="w-10 h-10 shrink-0 rounded-lg bg-orange-glow/10 border border-orange-glow/20 flex items-center justify-center text-orange-glow"
                            >
                                <i class="fa-solid fa-location-dot"></i>
                            </div>

                            <div>

                                <h3
                                    class="font-heading font-bold text-sm"
                                >
                                    Ward Operations
                                </h3>

                                <p
                                    class="text-xs text-slate-400 mt-1 leading-relaxed"
                                >
                                    Monitor infrastructure grievances across your assigned municipal division.
                                </p>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- Footer -->
                <div
                    class="relative z-10 mt-10 pt-5 border-t border-white/10 text-center"
                >
                    <p
                        class="text-[9px] font-mono text-slate-500 uppercase tracking-widest"
                    >
                        NagarNivaran Officer Command System
                    </p>
                </div>

            </div>


            <!-- RIGHT SIDE -->
            <div
                class="w-full md:w-[58%] p-8 sm:p-12 lg:p-16 bg-white relative"
            >

                <div class="max-w-md mx-auto relative z-10">

                    <!-- Header -->
                    <div class="mb-10">

                        <div
                            class="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-orange-50 border border-orange-100 text-orange-glow font-mono text-[10px] font-bold uppercase tracking-widest mb-4"
                        >
                            <i class="fa-solid fa-key"></i>
                            Secure Authentication
                        </div>

                        <h2
                            class="font-heading font-black text-3xl text-slate-900 tracking-tight"
                        >
                            Officer Command Login
                        </h2>

                        <p
                            class="text-sm text-slate-500 mt-2 leading-relaxed"
                        >
                            Enter your official badge credentials to access the municipal command dashboard.
                        </p>

                    </div>


                    <!-- Login Form -->
                    <form id="officerLoginForm" class="space-y-7">

                        <!-- Badge Number -->
                        <div>

                            <label
                                for="badge_number"
                                class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2"
                            >
                                Badge Number
                                <span class="text-tomato">*</span>
                            </label>

                            <div class="relative">

                                <input
                                    type="text"
                                    id="badge_number"
                                    name="badge_number"
                                    autocomplete="username"
                                    required
                                    maxlength="50"
                                    placeholder="e.g. JMC-OF-001"
                                    class="paper-input w-full py-3 pr-10 font-mono font-bold text-sm text-slate-900 uppercase placeholder-slate-300"
                                >

                                <i
                                    class="fa-solid fa-id-badge absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
                                ></i>

                            </div>

                            <span
                                id="badgeError"
                                class="block text-xs text-tomato font-medium mt-1"
                            ></span>

                        </div>


                        <!-- Password -->
                        <div>

                            <div class="flex justify-between items-center mb-2">

                                <label
                                    for="password"
                                    class="block text-xs font-bold uppercase tracking-wider text-slate-700"
                                >
                                    Command Password
                                    <span class="text-tomato">*</span>
                                </label>

                            </div>

                            <div class="relative">

                                <input
                                    type="password"
                                    id="password"
                                    name="password"
                                    autocomplete="current-password"
                                    required
                                    placeholder="Enter command password"
                                    class="paper-input w-full py-3 pr-20 font-mono font-bold text-sm text-slate-900 placeholder-slate-300"
                                >

                                <!-- Eye icon BEFORE lock icon, Perfectly Centered -->
                                <button
                                    type="button"
                                    id="togglePassword"
                                    class="absolute right-10 top-1/2 -translate-y-1/2 text-slate-400 hover:text-orange-glow transition-colors z-10"
                                    tabindex="-1"
                                >
                                    <i
                                        id="passwordIcon"
                                        class="fa-solid fa-eye"
                                    ></i>
                                </button>

                                <i
                                    class="fa-solid fa-lock absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
                                ></i>

                            </div>

                            <span
                                id="passwordError"
                                class="block text-xs text-tomato font-medium mt-1"
                            ></span>

                        </div>


                        <!-- Security Notice -->
                        <div
                            class="bg-slate-50 border border-slate-200 rounded-xl p-4 flex gap-3"
                        >
                            <div
                                class="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-100 flex items-center justify-center shrink-0"
                            >
                                <i class="fa-solid fa-lock text-xs"></i>
                            </div>

                            <div>
                                <p
                                    class="text-[10px] font-bold uppercase tracking-wider text-slate-700"
                                >
                                    Protected Command Channel
                                </p>

                                <p
                                    class="text-[10px] text-slate-400 mt-1 leading-relaxed"
                                >
                                    Authentication requests are verified against the official JMC officer database.
                                </p>
                            </div>
                        </div>

                        <!-- Login Button (With glass-flash class) -->
                        <button
                            type="submit"
                            id="btnOfficerLogin"
                            class="glass-flash w-full py-4 rounded-xl bg-slate-900 hover:bg-orange-glow text-white font-heading font-bold text-sm uppercase tracking-widest shadow-[4px_4px_0px_#FF6347] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 transition-all flex items-center justify-center gap-3"
                        >

                            <i
                                id="loginIcon"
                                class="fa-solid fa-right-to-bracket relative z-10"
                            ></i>

                            <span id="loginText" class="relative z-10">
                                Authenticate Officer
                            </span>

                        </button>

                    </form>


                    <!-- Bottom -->
                    <div
                        class="mt-10 pt-6 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-3"
                    >

                        <span
                            class="text-[9px] font-mono text-slate-400 uppercase tracking-wider"
                        >
                            JMC AUTH NODE: ONLINE
                        </span>

                        <a
                            href="../../index.php"
                            class="text-xs font-bold text-slate-500 hover:text-orange-glow transition-colors"
                        >

                            <i class="fa-solid fa-arrow-left mr-1"></i>

                            Return to Portal

                        </a>

                    </div>

                </div>

            </div>

        </div>

        <!-- Page Footer -->
        <div
            class="text-center mt-5 text-[9px] font-mono text-slate-400 uppercase tracking-widest"
        >
            JAMNAGAR MUNICIPAL CORPORATION
            &bull;
            NAGARNIVARAN
            &bull;
            OFFICER COMMAND DESK
        </div>

    </div>


    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <script>

        $(document).ready(function () {

            // ==========================================
            // Toggle Password Visibility
            // ==========================================
            $("#togglePassword").on("click", function () {
                const passwordInput = $("#password");
                const icon = $("#passwordIcon");

                if (passwordInput.attr("type") === "password") {
                    passwordInput.attr("type", "text");
                    icon
                        .removeClass("fa-eye")
                        .addClass("fa-eye-slash");
                } else {
                    passwordInput.attr("type", "password");
                    icon
                        .removeClass("fa-eye-slash")
                        .addClass("fa-eye");
                }
            });

            // ==========================================
            // Badge Number Validation
            // ==========================================
            $("#badge_number").on("input", function () {
                let value = $(this).val().trim();
                $(this).val(value.toUpperCase());

                if (value === "") {
                    $("#badgeError").text("Badge Number is required.");
                    $(this)
                        .removeClass("success")
                        .addClass("error");
                } else {
                    $("#badgeError").text("");
                    $(this)
                        .removeClass("error")
                        .addClass("success");
                }
            });

            // ==========================================
            // Password Validation
            // ==========================================
            $("#password").on("input", function () {
                let value = $(this).val();

                if (value === "") {
                    $("#passwordError").text("Password is required.");
                    $(this)
                        .removeClass("success")
                        .addClass("error");
                } else {
                    $("#passwordError").text("");
                    $(this)
                        .removeClass("error")
                        .addClass("success");
                }
            });

            // ==========================================
            // Officer Login
            // ==========================================
            $("#officerLoginForm").on("submit", function (e) {
                e.preventDefault();

                let badge_number = $("#badge_number").val().trim();
                let password = $("#password").val();

                // Reset errors
                $("#badgeError").text("");
                $("#passwordError").text("");

                $("#badge_number")
                    .removeClass("error");

                $("#password")
                    .removeClass("error");

                // ======================================
                // Frontend Validation
                // ======================================
                if (badge_number === "") {
                    $("#badgeError").text(
                        "Please enter your Badge Number."
                    );
                    $("#badge_number")
                        .addClass("error")
                        .focus();
                    return;
                }

                if (password === "") {
                    $("#passwordError").text(
                        "Please enter your command password."
                    );
                    $("#password")
                        .addClass("error")
                        .focus();
                    return;
                }

                // ======================================
                // Loading State
                // ======================================
                const button = $("#btnOfficerLogin");

                button.prop("disabled", true);

                $("#loginIcon")
                    .removeClass("fa-right-to-bracket")
                    .addClass("loader");

                $("#loginText").text("Authenticating...");

                // ======================================
                // AJAX Request
                // ======================================
                $.ajax({
                    url: "../../api/officer/login.php",
                    type: "POST",
                    data: {
                        badge_number: badge_number,
                        password: password
                    },
                    dataType: "json",

                    // ==================================
                    // SUCCESS
                    // ==================================
                    success: function (response) {
                        console.log(
                            "OFFICER LOGIN RESPONSE:",
                            response
                        );

                        if (response.success) {
                            Swal.fire({
                                icon: "success",
                                title: "Access Granted",
                                text: response.message,
                                confirmButtonText: "Enter Command Desk",
                                confirmButtonColor: "#FF7A00",
                                allowOutsideClick: false
                            }).then(function () {
                                let redirectUrl =
                                    response.redirect ||
                                    "../../pages/officer/dashboard.php";

                                window.location.href =
                                    redirectUrl;
                            });

                        } else {
                            // Restore button
                            button.prop("disabled", false);

                            $("#loginIcon")
                                .removeClass("loader")
                                .addClass("fa-right-to-bracket");

                            $("#loginText")
                                .text("Authenticate Officer");

                            Swal.fire({
                                icon: "error",
                                title: "Access Denied",
                                text: response.message ||
                                      "Officer authentication failed.",
                                confirmButtonColor: "#FF6347"
                            });
                        }
                    },

                    // ==================================
                    // AJAX ERROR
                    // ==================================
                    error: function (xhr, status, error) {
                        console.log(
                            "AJAX STATUS:",
                            status
                        );
                        console.log(
                            "AJAX ERROR:",
                            error
                        );
                        console.log(
                            "SERVER RESPONSE:",
                            xhr.responseText
                        );

                        // Restore button
                        button.prop("disabled", false);

                        $("#loginIcon")
                            .removeClass("loader")
                            .addClass("fa-right-to-bracket");

                        $("#loginText")
                            .text("Authenticate Officer");

                        Swal.fire({
                            icon: "error",
                            title: "Server Error",
                            text: "Unable to communicate with the authentication server.",
                            confirmButtonColor: "#FF6347"
                        });
                    }
                });
            });

            // ==========================================
            // Enter Key Support
            // ==========================================
            $("#badge_number, #password").on("keypress", function (e) {
                if (e.which === 13) {
                    $("#officerLoginForm").submit();
                }
            });
        });
    </script>
</body>
</html>
<?php
require_once("../../includes/config.php");

// ===============================
// Officer Authentication
// ===============================
if (!isset($_SESSION["officer_id"])) {
    header("Location: " . urlof("pages/officer/login.php"));
    exit;
}

$officer_id   = $_SESSION["officer_id"];
$officer_name = $_SESSION["officer_name"] ?? "Inspector Desk";
$badge_number = $_SESSION["badge_number"] ?? "JMC-8492";
$officer_dept = $_SESSION["officer_dept"] ?? null;

// ===============================
// Fetch Officer Department
// ===============================
$officer = null;
try {
    $stmt = $conn->prepare("
        SELECT o.id, o.full_name, o.badge_number, o.email, o.department_id, d.department_name
        FROM officers o
        LEFT JOIN departments d ON o.department_id = d.id
        WHERE o.id = ? LIMIT 1
    ");
    $stmt->execute([$officer_id]);
    $officer = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$officer) {
        session_unset();
        session_destroy();
        header("Location: " . urlof("pages/officer/login.php"));
        exit;
    }
    $officer_name = $officer["full_name"];
    $badge_number = $officer["badge_number"];
    $officer_dept = $officer["department_id"];
} catch (PDOException $e) {
    die("Database error: " . htmlspecialchars($e->getMessage()));
}

// ===============================
// Fetch Department Complaints
// ===============================
$cases = [];
try {
    $stmt = $conn->prepare("
        SELECT c.*, u.full_name AS citizen_name, u.mobile AS citizen_contact, d.department_name
        FROM complaints c
        INNER JOIN users u ON c.user_id = u.id
        LEFT JOIN departments d ON c.department_id = d.id
        WHERE c.department_id = ?
        ORDER BY CASE
            WHEN c.status = 'Pending' THEN 1
            WHEN c.status = 'In Progress' THEN 2
            WHEN c.status = 'Resolved' THEN 3
            ELSE 4 END, c.created_at DESC
    ");
    $stmt->execute([$officer_dept]);
    $cases = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $cases = [];
}

// ===============================
// Calculate Metrics
// ===============================
$active = 0;
$resolved = 0;
foreach ($cases as $case) {
    if ($case["status"] === "Pending" || $case["status"] === "In Progress") {
        $active++;
    }
    if ($case["status"] === "Resolved") {
        $resolved++;
    }
}

$complaintImageBase = urlof("assets/uploads/complaints/");
$logoPath = urlof("assets/imgs/nn-final.png");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officer Command Desk | NagarNivaran</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Courier+Prime:wght@400;700&family=Outfit:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'saffron': '#FF9933', 'orange-glow': '#FF7A00', 'tomato': '#FF6347',
                        'saas-bg': '#F8FAFC', 'ink': '#0F172A', 'sidebar': '#0B1120',
                    },
                    fontFamily: {
                        heading: ['"Outfit"', 'sans-serif'], sans: ['"Plus Jakarta Sans"', 'sans-serif'], mono: ['"Courier Prime"', 'monospace'],
                    },
                    boxShadow: {
                        'saas': '0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03)',
                        'saas-hover': '0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.025)',
                    }
                }
            }
        }
    </script>
    <style>
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 999px; }
        ::-webkit-scrollbar-thumb:hover { background: #94A3B8; }
        body { background-color: #F8FAFC; }
        
        /* Updated Orange Cross Pattern Background */
        .bg-cross-pattern {
            background-color: #F8FAFC;
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }

        /* Flash Hover Effect */
        .btn-flash {
            position: relative;
            overflow: hidden;
        }
        .btn-flash::after {
            content: '';
            position: absolute;
            top: 0; left: -100%;
            width: 50%; height: 100%;
            background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,0.3) 50%, rgba(255,255,255,0) 100%);
            transform: skewX(-25deg);
            z-index: 1;
        }
        .btn-flash:hover::after {
            animation: flash-slide 0.6s ease-out forwards;
        }
        @keyframes flash-slide {
            0% { left: -100%; }
            100% { left: 200%; }
        }

        .modal-active { display: flex !important; animation: modalFadeIn 0.2s ease-out forwards; }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.95) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        .saas-input:focus { outline: none !important; border-color: #FF7A00 !important; box-shadow: 0 0 0 3px rgba(255, 122, 0, 0.15) !important; }
    </style>
</head>
<body class="text-slate-800 font-sans h-screen flex overflow-hidden selection:bg-orange-glow selection:text-white">

<!-- Mobile Sidebar Backdrop -->
<div id="sidebar-backdrop" class="fixed inset-0 bg-slate-900/60 z-40 hidden lg:hidden transition-opacity"></div>

<!-- ========================================================= -->
<!-- SIDEBAR -->
<!-- ========================================================= -->
<aside id="sidebar" class="fixed inset-y-0 left-0 z-50 w-72 bg-sidebar text-slate-300 flex flex-col justify-between transform -translate-x-full lg:translate-x-0 transition-transform duration-300 lg:static border-r border-slate-800 shadow-xl">
    <div>
        <button id="sidebar-close" class="lg:hidden absolute top-4 right-4 text-slate-400 hover:text-white"><i class="fa-solid fa-xmark text-xl"></i></button>
        <!-- BRANDING -->
        <div class="px-6 pt-7 pb-6 border-b border-slate-800/80 text-center">
            <div class="flex justify-center mb-4">
                <div class="w-[130px] h-[130px] rounded-full flex items-center justify-center shadow-xl overflow-hidden transition-transform duration-300 hover:scale-110 border border-slate-700/50">
                    <img src="<?= htmlspecialchars($logoPath) ?>" onerror="this.src='https://placehold.co/130x130/FF7A00/FFF?text=NN'" class="w-full h-full object-cover rounded-full" alt="NagarNivaran Logo">
                </div>
            </div>
            <h1 class="font-heading font-black text-2xl tracking-tight text-white">Nagar<span class="text-orange-glow">Nivaran</span></h1>
        </div>

        <!-- PROFILE INFO -->
        <div class="px-6 py-6">
            <div class="bg-slate-800/40 rounded-2xl p-5 border border-slate-700/50 shadow-inner relative overflow-hidden">
                <div class="absolute top-0 right-0 w-20 h-20 bg-orange-glow/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
                <p class="text-[10px] font-mono font-bold text-orange-400 uppercase tracking-widest mb-3 flex items-center gap-2"><i class="fa-solid fa-shield-halved"></i> Command Desk</p>
                <div class="flex items-center gap-2 mb-1.5"><i class="fa-solid fa-user-tie text-orange-glow text-sm"></i><h2 class="font-heading font-bold text-lg text-white leading-tight"><?= htmlspecialchars($officer_name) ?></h2></div>
                <div class="flex items-center gap-2 text-xs font-mono text-slate-400"><i class="fa-solid fa-id-badge text-slate-500"></i><span>ID: <?= htmlspecialchars($badge_number) ?></span></div>
                <?php if (!empty($officer["department_name"])): ?>
                    <div class="mt-4 pt-4 border-t border-slate-700/70">
                        <p class="text-[11px] font-medium text-slate-400 bg-slate-900/50 inline-flex items-center gap-2 px-2.5 py-1.5 rounded-md border border-slate-700"><i class="fa-solid fa-building-columns text-orange-glow"></i><?= htmlspecialchars($officer["department_name"]) ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- NAVIGATION -->
        <nav class="px-4 space-y-2">
            <p class="px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500 font-mono mb-2">Command Modules</p>
            <button class="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-gradient-to-r from-orange-glow to-tomato text-white font-bold text-sm shadow-md transition-all text-left btn-flash">
                <span class="w-5 text-center relative z-10"><i class="fa-solid fa-book-open"></i></span> <span class="relative z-10">Department Ledger</span>
            </button>
            <a href="<?= htmlspecialchars(urlof("pages/officer/print_report.php")) ?>" target="_blank" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white font-medium text-sm transition-all border border-transparent hover:border-slate-700 btn-flash">
                <span class="w-5 text-center relative z-10"><i class="fa-solid fa-file-pdf"></i></span> <span class="relative z-10">Generate PDF Ledger</span>
            </a>
        </nav>
    </div>

    <!-- FOOTER -->
    <div class="p-6">
        <div class="mb-5 border-t border-slate-800"></div>
        <div class="mb-4 px-4 flex items-center gap-2 text-[10px] font-mono text-slate-400 uppercase tracking-widest"><span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse border border-sidebar shadow-[0_0_8px_#10b981]"></span> System Online</div>
        <a href="<?= htmlspecialchars(urlof("api/officer/logout.php")) ?>" class="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-xl bg-slate-800/50 hover:bg-red-500/10 text-slate-400 hover:text-tomato font-bold text-xs uppercase tracking-wider transition-all border border-transparent hover:border-red-500/20 btn-flash"><span class="relative z-10 flex items-center gap-2"><i class="fa-solid fa-right-from-bracket"></i> End Shift</span></a>
    </div>
</aside>

<!-- ========================================================= -->
<!-- MAIN WORKSPACE -->
<!-- ========================================================= -->
<div class="flex-1 flex flex-col h-full w-full relative bg-cross-pattern overflow-hidden">
    <!-- TOP HEADER -->
    <header class="h-20 bg-white/95 backdrop-blur border-b border-slate-200 flex items-center justify-between px-6 lg:px-10 shrink-0 z-10 shadow-sm relative">
        <div class="flex items-center gap-4">
            <button id="sidebar-toggle" class="lg:hidden text-slate-400 hover:text-orange-glow transition-colors"><i class="fa-solid fa-bars text-2xl"></i></button>
            <h2 class="font-heading font-extrabold text-2xl text-ink tracking-tight hidden sm:flex items-center gap-3"><span class="w-9 h-9 rounded-xl bg-orange-50 border border-orange-100 text-orange-glow flex items-center justify-center"><i class="fa-solid fa-book-open text-sm"></i></span> Active Ledger</h2>
        </div>
        <div class="flex items-center gap-3 bg-slate-50 border border-slate-200 px-4 py-2 rounded-full shadow-sm"><span class="flex items-center gap-2 text-[10px] font-mono font-bold text-slate-500 tracking-wider uppercase"><i class="fa-solid fa-server text-orange-glow"></i> JMC NN v2.7</span></div>
    </header>

    <!-- SCROLLABLE CONTENT -->
    <main class="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-10 space-y-6 lg:space-y-8 relative z-[1]">
        <!-- QUICK METRICS -->
        <div>
            <h3 class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 font-mono">Performance Overview</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 lg:gap-8">
                <!-- Pending Card -->
                <div class="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-saas hover:shadow-saas-hover transition-shadow relative overflow-hidden group">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-red-50 rounded-full blur-3xl -mr-10 -mt-10 transition-transform group-hover:scale-110"></div>
                    <div class="flex items-center justify-between mb-4 relative z-10"><div class="w-12 h-12 rounded-xl bg-red-50 border border-red-100 flex items-center justify-center text-tomato text-lg shadow-sm"><i class="fa-solid fa-clock-rotate-left"></i></div><span class="text-4xl font-heading font-black text-ink"><?= $active ?></span></div>
                    <p class="font-bold text-slate-800 text-sm relative z-10">Pending Action</p>
                    <p class="text-xs text-slate-500 mt-1 font-medium relative z-10">Cases requiring your dispatch</p>
                </div>
                <!-- Resolved Card -->
                <div class="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-saas hover:shadow-saas-hover transition-shadow relative overflow-hidden group">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full blur-3xl -mr-10 -mt-10 transition-transform group-hover:scale-110"></div>
                    <div class="flex items-center justify-between mb-4 relative z-10"><div class="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 text-lg shadow-sm"><i class="fa-solid fa-check-double"></i></div><span class="text-4xl font-heading font-black text-emerald-600"><?= $resolved ?></span></div>
                    <p class="font-bold text-slate-800 text-sm relative z-10">Cases Cleared</p>
                    <p class="text-xs text-slate-500 mt-1 font-medium relative z-10">Successfully resolved complaints</p>
                </div>
            </div>
        </div>

        <!-- QUEUE TABLE -->
        <div class="bg-white border border-slate-200 shadow-saas rounded-2xl overflow-hidden">
            <div class="px-5 py-4 sm:px-6 sm:py-5 border-b border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white">
                <h3 class="text-sm font-bold text-slate-800 uppercase tracking-widest font-heading flex items-center gap-2"><i class="fa-solid fa-list-check text-orange-glow"></i> Assigned Nodal Queue</h3>
                <span class="text-[10px] font-bold text-slate-500 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-md shadow-sm">Total Logged: <span class="text-ink"><?= count($cases) ?></span></span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left whitespace-nowrap border-collapse min-w-[800px]">
                    <thead>
                        <tr class="text-[10px] uppercase tracking-wider font-bold text-slate-400 bg-slate-50 border-b border-slate-100">
                            <th class="py-4 px-6 font-medium">Case ID & Timestamp</th>
                            <th class="py-4 px-6 font-medium">Grievance & Location</th>
                            <th class="py-4 px-6 font-medium">Priority</th>
                            <th class="py-4 px-6 font-medium">Status</th>
                            <th class="py-4 px-6 text-right font-medium">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 text-sm font-medium">
                        <?php if (!empty($cases)): ?>
                            <?php foreach ($cases as $c): ?>
                                <?php
                                $caseId = (int)$c["id"];
                                $priority = $c["priority"] ?? "Medium";
                                $title = htmlspecialchars($c["title"] ?? "", ENT_QUOTES, "UTF-8");
                                $description = htmlspecialchars($c["description"] ?? "", ENT_QUOTES, "UTF-8");
                                $status = htmlspecialchars($c["status"] ?? "Pending", ENT_QUOTES, "UTF-8");
                                $location = htmlspecialchars($c["location"] ?? "", ENT_QUOTES, "UTF-8");
                                $citizen = htmlspecialchars($c["citizen_name"] ?? "", ENT_QUOTES, "UTF-8");
                                $contact = htmlspecialchars($c["citizen_contact"] ?? "", ENT_QUOTES, "UTF-8");
                                $image = htmlspecialchars($c["image"] ?? "", ENT_QUOTES, "UTF-8");
                                $createdAt = !empty($c["created_at"]) ? date("M d, Y - H:i", strtotime($c["created_at"])) : "N/A";

                                $priorityValue = strtolower(trim($priority));
                                // $priorityClass = $priorityValue === "high" ? "bg-red-50 text-tomato border-red-100" : ($priorityValue === "low" ? "bg-slate-50 text-slate-500 border-slate-200" : "bg-orange-50 text-orange-glow border-orange-100");
                                // $priorityIcon = $priorityValue === "high" ? "fa-arrow-up" : ($priorityValue === "low" ? "fa-arrow-down" : "fa-minus");
                                $priorityClass = $priorityValue === "critical"
                                ? "bg-red-100 text-red-800 border-red-200"
                                : ($priorityValue === "high"
                                    ? "bg-red-50 text-tomato border-red-100"
                                    : ($priorityValue === "low"
                                        ? "bg-emerald-50 text-emerald-500 border-emerald-200"
                                        : "bg-orange-50 text-orange-glow border-orange-100"));

                                $priorityIcon = $priorityValue === "critical"
                                    ? "fa-circle-exclamation"
                                    : ($priorityValue === "high"
                                        ? "fa-arrow-up"
                                        : ($priorityValue === "low"
                                            ? "fa-arrow-down"
                                            : "fa-minus"));


                                ?>
                                <tr class="hover:bg-slate-50/70 transition-colors group">
                                    <td class="py-4 px-6"><div class="flex flex-col"><span class="font-mono font-bold text-orange-glow text-xs uppercase">#JMC-<?= $caseId ?></span><span class="text-[11px] text-slate-400 mt-1"><i class="fa-regular fa-clock mr-1"></i> <?= $createdAt ?></span></div></td>
                                    <td class="py-4 px-6"><div class="flex items-center gap-3"><div class="w-8 h-8 rounded-lg bg-slate-100 text-slate-400 flex items-center justify-center shrink-0"><i class="fa-solid fa-file-lines text-xs"></i></div><div><p class="font-bold text-ink text-sm leading-tight group-hover:text-orange-glow transition-colors truncate max-w-[200px] sm:max-w-[250px]"><?= $title ?></p><p class="text-[11px] text-slate-500 mt-1 truncate max-w-[200px] sm:max-w-[250px]"><i class="fa-solid fa-location-dot text-tomato opacity-70 mr-1"></i> <?= $location ?></p></div></div></td>
                                    <td class="py-4 px-6 align-middle"><span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-[10px] font-bold uppercase tracking-wider <?= $priorityClass ?>"><i class="fa-solid <?= $priorityIcon ?>"></i> <?= htmlspecialchars($priority) ?></span></td>
                                    <td class="py-4 px-6 align-middle">
                                        <?php if ($status === "Resolved"): ?><span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-100"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Resolved</span>
                                        <?php elseif ($status === "In Progress"): ?><span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-50 text-orange-800 text-[10px] font-bold border border-orange-100"><span class="w-1.5 h-1.5 rounded-full bg-orange-glow animate-pulse"></span> In Progress</span>
                                        <?php else: ?><span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-50 text-red-700 text-[10px] font-bold border border-red-100"><span class="w-1.5 h-1.5 rounded-full bg-tomato"></span> Pending</span><?php endif; ?>
                                    </td>
                                    <td class="py-4 px-6 text-right align-middle">
                                        <button type="button" onclick='openCaseFile(<?= json_encode($caseId) ?>, <?= json_encode($title) ?>, <?= json_encode($description) ?>, <?= json_encode($status) ?>, <?= json_encode($location) ?>, <?= json_encode($citizen) ?>, <?= json_encode($contact) ?>, <?= json_encode($image) ?>)' class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white border border-slate-200 hover:border-orange-glow hover:text-orange-glow text-slate-600 font-bold text-[10px] uppercase tracking-wider shadow-sm transition-all">Review <i class="fa-solid fa-arrow-up-right-from-square"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="py-20 text-center"><div class="w-14 h-14 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-300 mx-auto mb-3 text-2xl"><i class="fa-solid fa-folder-open"></i></div><h3 class="font-heading font-bold text-ink text-sm">No Active Cases</h3><p class="text-xs text-slate-400 mt-1">Queue is currently clear for this ledger.</p></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="px-5 sm:px-6 py-3.5 border-t border-slate-100 bg-slate-50/40 flex items-center justify-between"><span class="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-400">JMC • Department Dispatch System</span><span class="hidden sm:flex items-center gap-1.5 text-[9px] font-medium text-slate-400"><i class="fa-solid fa-shield-halved text-emerald-500"></i> Official Audit Queue</span></div>
        </div>
    </main>
    
    <!-- Footer directly inside the main wrapper -->
    <!-- <footer class="w-full text-center py-4 px-4 text-[10px] font-mono text-slate-500 uppercase tracking-widest mt-auto border-t border-slate-200/60 bg-white/60 backdrop-blur-sm z-10 relative">
        All right reserved NagarNivaran X JMC
    </footer> -->
</div>

<!-- ========================================================= -->
<!-- CASE MODAL -->
<!-- ========================================================= -->
<div id="case-modal" class="fixed inset-0 z-[60] hidden items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 overflow-y-auto">
    <div class="w-full max-w-3xl bg-white rounded-2xl shadow-2xl relative my-8 overflow-hidden flex flex-col border border-slate-200 transform scale-95 transition-all">
        <!-- Modal Header -->
        <div class="bg-slate-50 px-5 py-4 sm:px-6 flex items-center justify-between border-b border-slate-200">
            <div class="flex items-center gap-3"><div class="w-10 h-10 rounded-xl bg-orange-50 text-orange-glow flex items-center justify-center text-lg border border-orange-100"><i class="fa-solid fa-file-invoice"></i></div><div><h3 class="font-heading font-black text-xl text-ink tracking-tight leading-tight" id="modal-case-id">#CASE-ID</h3><p class="text-[10px] text-slate-500 font-bold uppercase tracking-wider font-mono">Nodal Investigation File</p></div></div>
            <button type="button" onclick="closeCaseFile()" class="w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-200 text-slate-500 transition-colors"><i class="fa-solid fa-xmark text-lg"></i></button>
        </div>
        <!-- Modal Body -->
        <div class="p-5 sm:p-8 space-y-6 max-h-[calc(85vh-80px)] overflow-y-auto bg-white">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
                <!-- Details -->
                <div class="space-y-5">
                    <div><span class="block text-[10px] text-slate-400 font-bold uppercase font-mono mb-1">Grievance Title</span><h4 id="modal-title" class="font-heading font-extrabold text-xl text-ink leading-snug">TITLE GOES HERE</h4></div>
                    <div class="space-y-4 bg-slate-50 p-4 sm:p-5 rounded-xl border border-slate-100">
                        <div class="flex items-start gap-3"><i class="fa-solid fa-location-dot text-tomato mt-0.5 w-4 text-center"></i><div><span class="block text-[10px] text-slate-400 font-bold uppercase font-mono mb-0.5">Location</span><span id="modal-location" class="font-bold text-sm text-slate-800 leading-tight block">Location String</span></div></div>
                        <div class="flex items-start gap-3 border-t border-slate-200 pt-3"><i class="fa-solid fa-user text-slate-400 mt-0.5 w-4 text-center"></i><div><span class="block text-[10px] text-slate-400 font-bold uppercase font-mono mb-0.5">Citizen</span><span id="modal-citizen" class="font-bold text-sm text-slate-800 block">Name</span></div></div>
                        <div class="flex items-start gap-3 border-t border-slate-200 pt-3"><i class="fa-solid fa-phone text-slate-400 mt-0.5 w-4 text-center"></i><div><span class="block text-[10px] text-slate-400 font-bold uppercase font-mono mb-0.5">Contact</span><span id="modal-contact" class="font-bold text-sm text-slate-800 font-mono block">+91 XXXXX</span></div></div>
                    </div>
                    <div><span class="block text-[10px] text-slate-400 font-bold uppercase font-mono mb-2">Description</span><div class="bg-white p-4 rounded-xl border border-slate-200 text-sm text-slate-600 leading-relaxed font-medium min-h-[80px]" id="modal-desc">Description text...</div></div>
                </div>
                <!-- Action & Evidence -->
                <div class="space-y-5">
                    <div id="evidence-container" class="hidden"><span class="block text-[10px] text-slate-400 font-bold uppercase font-mono mb-2">Attached Evidence</span><div class="rounded-xl overflow-hidden border border-slate-200 bg-slate-50 p-1 shadow-sm"><img id="modal-image" src="" alt="Evidence" class="w-full h-auto max-h-48 object-cover rounded-lg"></div></div>
                    <!-- Form -->
                    <form id="action-form" method="POST" action="" class="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-saas relative overflow-hidden">
                        <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-glow to-tomato"></div>
                        <div class="flex items-center gap-2 text-xs font-bold font-heading uppercase tracking-wider text-orange-glow mb-4 mt-1"><i class="fa-solid fa-sliders"></i> Dispatch Action</div>
                        <div class="space-y-4">
                            <div class="flex flex-col"><label class="font-bold text-[10px] uppercase tracking-wider text-slate-500 mb-1.5">Change Status *</label><select name="status" id="modal-status" required class="saas-input w-full border border-slate-300 rounded-lg p-3 font-bold text-sm bg-slate-50 text-ink cursor-pointer transition-all"><option value="Pending">Pending Action</option><option value="In Progress">In Progress (Dispatched)</option><option value="Resolved">Resolved / Closed</option><option value="Rejected">Rejected / Invalid</option></select></div>
                            <div class="flex flex-col"><label class="font-bold text-[10px] uppercase tracking-wider text-slate-500 mb-1.5">Audit Note / Remarks *</label><textarea name="remark" rows="3" required placeholder="Enter resolution details..." class="saas-input w-full border border-slate-300 rounded-lg p-3 font-medium text-sm text-ink bg-slate-50 transition-all resize-none"></textarea></div>
                        </div>
                        <button type="submit" class="w-full mt-5 px-4 py-3 rounded-xl bg-ink hover:bg-slate-800 text-white font-bold text-xs uppercase tracking-wider shadow-md transition-all flex items-center justify-center gap-2 btn-flash"><span class="relative z-10 flex items-center gap-2"><i class="fa-solid fa-check"></i> Update Case Record</span></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========================================================= -->
<!-- JAVASCRIPT -->
<!-- ========================================================= -->
<script>
// UI / Mobile Controls
const sidebar = document.getElementById('sidebar');
const toggleBtn = document.getElementById('sidebar-toggle');
const backdrop = document.getElementById('sidebar-backdrop');
const closeBtn = document.getElementById('sidebar-close');

function toggleSidebar() {
    sidebar.classList.toggle('-translate-x-full');
    backdrop.classList.toggle('hidden');
}
toggleBtn.addEventListener('click', toggleSidebar);
backdrop.addEventListener('click', toggleSidebar);
closeBtn.addEventListener('click', toggleSidebar);

// Case Modal & Functional Logic
const modal = document.getElementById('case-modal');
const actionForm = document.getElementById('action-form');
const complaintImageBase = <?= json_encode($complaintImageBase) ?>;

function openCaseFile(id, title, desc, status, location, citizen, contact, imageFilename) {
    document.getElementById('modal-case-id').innerText = "#JMC-" + id;
    document.getElementById('modal-title').innerText = title || "Untitled Complaint";
    document.getElementById('modal-desc').innerText = desc || "No description provided.";
    document.getElementById('modal-location').innerText = location || "Location not provided";
    document.getElementById('modal-citizen').innerText = citizen || "Unknown Citizen";
    document.getElementById('modal-contact').innerText = contact ? "+91 " + contact : "N/A";
    document.getElementById('modal-status').value = status || "Pending";

    const imgContainer = document.getElementById('evidence-container');
    const imgTag = document.getElementById('modal-image');
    if (imageFilename && imageFilename !== "None" && imageFilename !== "null" && String(imageFilename).trim() !== "") {
        const cleanFilename = String(imageFilename).split('/').pop().split('\\').pop();
        imgTag.src = complaintImageBase + encodeURIComponent(cleanFilename);
        imgTag.onerror = function () { imgContainer.classList.add('hidden'); };
        imgTag.onload = function () { imgContainer.classList.remove('hidden'); };
    } else {
        imgContainer.classList.add('hidden');
        imgTag.src = "";
    }

    actionForm.action = <?= json_encode(urlof("api/officer/update_case.php")) ?>;
    actionForm.dataset.complaintId = id;

    modal.classList.add('modal-active');
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function closeCaseFile() {
    modal.classList.remove('modal-active');
    modal.classList.add('hidden');
    actionForm.reset();
    document.body.style.overflow = '';
}

modal.addEventListener('click', function (event) { if (event.target === modal) closeCaseFile(); });
document.addEventListener('keydown', function (event) { if (event.key === 'Escape' && !modal.classList.contains('hidden')) closeCaseFile(); });

actionForm.addEventListener('submit', function (event) {
    event.preventDefault();
    const complaintId = actionForm.dataset.complaintId;
    if (!complaintId) { alert("Complaint ID missing."); return; }

    const formData = new FormData(actionForm);
    formData.append("complaint_id", complaintId);

    const submitButton = actionForm.querySelector('button[type="submit"]');
    const originalHTML = submitButton.innerHTML;

    submitButton.disabled = true;
    submitButton.classList.add('opacity-70', 'cursor-not-allowed');
    submitButton.innerHTML = '<span class="relative z-10 flex items-center gap-2"><i class="fa-solid fa-spinner fa-spin"></i> Updating...</span>';

    fetch(actionForm.action, { method: "POST", body: formData })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeCaseFile();
            alert(data.message || "Case updated successfully.");
            window.location.reload();
        } else {
            alert(data.message || "Unable to update case.");
        }
    })
    .catch(error => {
        console.error("Update Error:", error);
        alert("Server error while updating case.");
    })
    .finally(() => {
        submitButton.disabled = false;
        submitButton.classList.remove('opacity-70', 'cursor-not-allowed');
        submitButton.innerHTML = originalHTML;
    });
});
</script>
</body>
</html>
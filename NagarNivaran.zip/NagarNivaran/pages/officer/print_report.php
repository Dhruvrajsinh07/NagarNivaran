<?php
require_once("../../includes/config.php");

// Officer authentication
if (!isset($_SESSION["officer_id"])) {
    header("Location: login.php");
    exit;
}

// These should normally be supplied by your backend.
// If this file itself is responsible for fetching the data,
// uncomment/use the database logic below.

$officer_id = $_SESSION["officer_id"];

/*
|--------------------------------------------------------------------------
| Fetch Officer
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT 
        o.id,
        o.full_name,
        o.badge_number,
        o.email,
        o.department_id,
        d.department_name
    FROM officers o
    LEFT JOIN departments d 
        ON o.department_id = d.id
    WHERE o.id = ?
");

$stmt->execute([$officer_id]);

$officer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$officer) {
    session_destroy();
    header("Location: login.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| Fetch Department Complaints
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT 
        c.id,
        c.title,
        c.location,
        c.status,
        c.created_at,
        u.full_name AS citizen_name,
        u.mobile AS citizen_contact
    FROM complaints c
    INNER JOIN users u 
        ON c.user_id = u.id
    WHERE c.department_id = ?
    ORDER BY 
        CASE
            WHEN c.status = 'Pending' THEN 1
            WHEN c.status = 'In Progress' THEN 2
            ELSE 3
        END,
        c.created_at DESC
");

$stmt->execute([$officer["department_id"]]);

$complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Report Date
|--------------------------------------------------------------------------
*/

$date = date("d-M-Y H:i");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department Ledger | NagarNivaran</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Courier+Prime:wght@400;700&family=Outfit:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'saffron': '#FF9933',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                        'ink': '#0F172A',
                    },
                    fontFamily: {
                        heading: ['"Outfit"', 'sans-serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        mono: ['"Courier Prime"', 'monospace'],
                    }
                }
            }
        }
    </script>

    <style>
        body {
            background-color: #F8FAFC;
        }

        .paper-shadow {
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05), 0 0 10px rgba(0,0,0,0.01);
        }

        .border-gradient {
            position: relative;
        }
        .border-gradient::after {
            content: '';
            position: absolute;
            bottom: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(to right, #FF7A00, #FF6347);
        }

        @media print {
            .no-print { display: none !important; }
            @page { size: A4; margin: 12mm; }
            body { background: white !important; padding: 0 !important; }
            .paper-shadow { box-shadow: none !important; border: none !important; padding: 0 !important; }
            .print-break-inside-avoid { break-inside: avoid; }
        }
    </style>
</head>

<body class="p-4 md:p-10 lg:p-16 text-slate-800">

    <!-- =========================================================
         PRINT CONTROLS (Hidden on Print)
    ========================================================== -->
    <div class="no-print max-w-5xl mx-auto mb-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
            <h2 class="font-heading font-black text-xl text-ink">Document Preview</h2>
            <p class="text-xs font-medium text-slate-500 mt-1">Ready for official municipal archiving.</p>
        </div>
        
        <div class="flex items-center gap-3 w-full sm:w-auto">
            <!-- 
                Replaced <a href> with window.close(). 
                This immediately closes the tab, returning the user to their already-open dashboard. 
            -->
            <button onclick="window.close()" class="flex-1 sm:flex-none bg-white border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-600 px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-sm">
                <i class="fa-solid fa-xmark text-sm"></i> Close Report Tab
            </button>

            <button onclick="window.print()" class="flex-1 sm:flex-none bg-ink hover:bg-orange-glow text-white px-6 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider shadow-md flex items-center justify-center gap-2 transition-all">
                <i class="fa-solid fa-print text-sm"></i> Save as PDF / Print
            </button>
        </div>
    </div>

    <!-- =========================================================
         REPORT CONTAINER (The "Paper")
    ========================================================== -->
    <div class="max-w-5xl mx-auto bg-white border border-slate-200 p-10 sm:p-12 lg:p-16 rounded-2xl paper-shadow relative overflow-hidden">
        
        <!-- Decorative subtle watermark (visible on screen, subtle on print) -->
        <div class="absolute right-[-80px] top-[-80px] w-80 h-80 bg-orange-50 rounded-full opacity-30 pointer-events-none"></div>

        <!-- =====================================================
             HEADER
        ====================================================== -->
        <div class="flex flex-col sm:flex-row justify-between sm:items-end mb-12 border-gradient pb-6 gap-6 relative z-10">
            <div class="flex items-center gap-5">
                <div class="w-20 h-20 rounded-full bg-white flex items-center justify-center border-2 border-orange-glow shadow-sm p-1">
                    <img 
                        src="../../assets/imgs/nn-final.png" 
                        onerror="this.src='https://placehold.co/100x100/FF7A00/FFFFFF?text=NN'" 
                        class="w-full h-full object-cover rounded-full" 
                        alt="NagarNivaran Logo"
                    >
                </div>
                <div>
                    <h1 class="text-3xl font-heading font-black text-ink tracking-tight flex items-center gap-1">
                        Nagar<span class="text-orange-glow">Nivaran</span>
                    </h1>
                    <p class="text-tomato font-bold text-[11px] font-mono uppercase tracking-[0.2em] mt-1">
                        Department Dispatch Ledger
                    </p>
                </div>
            </div>

            <div class="sm:text-right">
                <p class="text-[9px] font-bold font-mono text-slate-400 uppercase tracking-widest mb-1">
                    Audit Timestamp
                </p>
                <p class="font-bold text-sm text-ink bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg inline-block shadow-sm">
                    <i class="fa-regular fa-clock text-orange-glow mr-1.5"></i> <?= htmlspecialchars($date) ?>
                </p>
            </div>
        </div>

        <!-- =====================================================
             OFFICER INFORMATION
        ====================================================== -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-12 relative z-10">
            <!-- Officer Card -->
            <div class="bg-orange-50/50 p-5 rounded-xl border border-orange-100 flex items-start gap-4">
                <div class="w-10 h-10 rounded-lg bg-orange-100 text-orange-glow flex items-center justify-center shrink-0">
                    <i class="fa-solid fa-user-shield"></i>
                </div>
                <div>
                    <p class="text-[10px] font-bold font-mono text-slate-500 uppercase tracking-widest mb-0.5">Field Officer</p>
                    <p class="text-lg font-heading font-extrabold text-ink leading-tight"><?= htmlspecialchars($officer["full_name"]) ?></p>
                    <p class="text-xs font-mono font-bold text-orange-glow mt-1 flex items-center gap-1.5">
                        <i class="fa-solid fa-id-badge opacity-70"></i> <?= htmlspecialchars($officer["badge_number"]) ?>
                    </p>
                </div>
            </div>

            <!-- Department Card -->
            <div class="bg-slate-50 p-5 rounded-xl border border-slate-200 flex items-start gap-4">
                <div class="w-10 h-10 rounded-lg bg-slate-200 text-slate-600 flex items-center justify-center shrink-0">
                    <i class="fa-solid fa-building-columns"></i>
                </div>
                <div>
                    <p class="text-[10px] font-bold font-mono text-slate-500 uppercase tracking-widest mb-0.5">Assigned Division</p>
                    <p class="text-lg font-heading font-extrabold text-ink leading-tight"><?= htmlspecialchars($officer["department_name"] ?? "N/A") ?></p>
                </div>
            </div>
        </div>

        <!-- =====================================================
             COMPLAINT TABLE
        ====================================================== -->
        <div class="overflow-x-auto relative z-10">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b-2 border-slate-200">
                        <th class="pb-4 px-2 whitespace-nowrap">Log ID</th>
                        <th class="pb-4 px-2">Issue Details</th>
                        <th class="pb-4 px-2">Citizen</th>
                        <th class="pb-4 px-2">Location</th>
                        <th class="pb-4 px-2 text-right">Status</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-slate-100">
                    <?php if (!empty($complaints)): ?>
                        <?php foreach ($complaints as $c): ?>
                            <tr class="text-sm print-break-inside-avoid">
                                
                                <!-- Complaint ID -->
                                <td class="py-5 px-2 align-top w-24">
                                    <span class="font-mono font-bold text-orange-glow bg-orange-50 border border-orange-100 px-2 py-1 rounded text-xs whitespace-nowrap">
                                        #JMC-<?= htmlspecialchars($c["id"]) ?>
                                    </span>
                                </td>

                                <!-- Complaint Title -->
                                <td class="py-5 px-2 align-top max-w-xs">
                                    <p class="font-bold text-ink leading-snug">
                                        <?= htmlspecialchars($c["title"]) ?>
                                    </p>
                                </td>

                                <!-- Citizen -->
                                <td class="py-5 px-2 align-top whitespace-nowrap">
                                    <p class="font-bold text-slate-800 text-xs">
                                        <i class="fa-solid fa-user text-slate-400 mr-1"></i> <?= htmlspecialchars($c["citizen_name"]) ?>
                                    </p>
                                    <p class="text-[11px] font-mono text-slate-500 mt-1">
                                        <i class="fa-solid fa-phone text-slate-400 mr-1"></i> <?= htmlspecialchars($c["citizen_contact"]) ?>
                                    </p>
                                </td>

                                <!-- Location -->
                                <td class="py-5 px-2 align-top text-xs font-medium text-slate-600 max-w-[200px]">
                                    <i class="fa-solid fa-location-dot text-tomato opacity-70 mr-1"></i> <?= htmlspecialchars($c["location"]) ?>
                                </td>

                                <!-- Status -->
                                <td class="py-5 px-2 align-top text-right whitespace-nowrap">
                                    <?php
                                    $status = $c["status"];
                                    if ($status === "Resolved") {
                                        $statusClass = "bg-emerald-50 text-emerald-700 border-emerald-200";
                                        $dotClass = "bg-emerald-500";
                                    } elseif ($status === "In Progress") {
                                        $statusClass = "bg-orange-50 text-orange-700 border-orange-200";
                                        $dotClass = "bg-orange-glow";
                                    } else {
                                        $statusClass = "bg-red-50 text-red-700 border-red-200";
                                        $dotClass = "bg-tomato";
                                    }
                                    ?>
                                    <span class="inline-flex items-center gap-1.5 px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full border <?= $statusClass ?>">
                                        <span class="w-1.5 h-1.5 rounded-full <?= $dotClass ?>"></span>
                                        <?= htmlspecialchars($status) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <!-- No complaints -->
                        <tr>
                            <td colspan="5" class="py-16 text-center">
                                <div class="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center text-slate-300 mx-auto mb-3 text-xl border border-slate-100">
                                    <i class="fa-solid fa-folder-open"></i>
                                </div>
                                <p class="text-slate-500 font-bold text-sm">No complaints found for this division.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- =====================================================
             FOOTER
        ====================================================== -->
        <div class="mt-16 pt-6 border-t-2 border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left relative z-10">
            <div>
                <p class="text-[10px] font-bold font-mono text-slate-400 uppercase tracking-widest">
                    Officer Panel &bull; Confidential Municipal Dispatch Record
                </p>
                <p class="text-[10px] font-bold font-mono text-slate-400 uppercase tracking-widest mt-1">
                    JAMNAGAR MUNICIPAL CORPORATION &bull; NAGARNIVARAN SERVER
                </p>
            </div>
            
            <div class="w-12 h-12 opacity-50  border-2 border-emerald-400 rounded-full flex items-center justify-center print-seal ">
                <i class="fa-solid fa-stamp text-emerald-700 text-xl"></i>
            </div>
        </div>

    </div>

</body>
</html>
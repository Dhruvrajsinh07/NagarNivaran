<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once("../../includes/config.php");

// 🚨 ADD THESE 3 LINES TO PREVENT BROWSER CACHING 🚨
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

/*
|--------------------------------------------------------------------------
| Authentication Check
|--------------------------------------------------------------------------
*/
if (!isset($_SESSION["user_id"])) {
    header("Location: " . urlof("pages/user/login.php"));
    exit;
}

$userId = $_SESSION["user_id"];

/*
|--------------------------------------------------------------------------
| Fetch Logged-in User
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    SELECT id, full_name, mobile, email, house_no, area, ward, pincode, photo, created_at
    FROM users WHERE id = ? LIMIT 1
");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_unset();
    session_destroy();
    header("Location: " . urlof("pages/user/login.php"));
    exit;
}

/*
|--------------------------------------------------------------------------
| Fetch Departments
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("SELECT id, department_name, description FROM departments ORDER BY department_name ASC");
$stmt->execute();
$departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Fetch User Complaints
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    SELECT c.*, d.department_name
    FROM complaints c
    LEFT JOIN departments d ON c.department_id = d.id
    WHERE c.user_id = ?
    ORDER BY c.created_at DESC
");
$stmt->execute([$userId]);
$complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Dashboard Statistics
|--------------------------------------------------------------------------
*/
$total = count($complaints);
$resolved = 0; $pending = 0; $inProgress = 0; $rejected = 0;

foreach ($complaints as $complaint) {
    switch ($complaint["status"]) {
        case "Resolved": $resolved++; break;
        case "Pending": $pending++; break;
        case "In Progress": $inProgress++; break;
        case "Rejected": $rejected++; break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Citizen Dashboard | NagarNivaran</title>

    <link rel="icon" type="image/x-icon" href="<?= urlof('assets/imgs/nn-final.png')?>">

    <script src="https://cdn.tailwindcss.com"></script>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Hind+Vadodara:wght@500;600;700&family=Outfit:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <script>
            // 🚨 Advanced Mobile Cache Buster 🚨
        window.addEventListener("pageshow", function (event) {
            // If the page was loaded from the browser's back-forward cache (mobile swipe back)
            if (event.persisted) {
                window.location.reload(); // Force a hard reload from the server
            }
        });

        // Prevent moving back in history
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
    </script>

    <script>
        tailwind.config = {
            darkMode: 'class', // Enables dark mode toggling via class
            theme: {
                extend: {
                    colors: {
                        'civic-canvas': '#F4F7F9',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                        'dark-slate': '#18181b', 
                    },
                    fontFamily: {
                        heading: ['"Outfit"', 'sans-serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        gujarati: ['"Hind Vadodara"', 'sans-serif']
                    }
                }
            }
        };
    </script>

    <style>
        /* Base scrolling & setup */
        html { transition: font-size 0.3s ease; }
        body { background-color: #F4F7F9; transition: background-color 0.3s, color 0.3s; }
        .dark body { background-color: #0f172a; color: #f8fafc; }
        
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #FF7A00; }

        /* Orange Cross Pattern Background */
        .bg-cross-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }
        .dark .bg-cross-pattern { opacity: 0.1; }

        /* Float Animation for Logo */
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-8px); }
        }
        .animate-float { animation: float 6s ease-in-out infinite; }

        /* Glass Flash Animation for Nav Pills */
        .glass-flash { position: relative; overflow: hidden; }
        .glass-flash::after {
            content: '';
            position: absolute;
            top: 0; left: -100%;
            width: 50%; height: 100%;
            background: linear-gradient(to right, transparent, rgba(255, 255, 255, 0.8), transparent);
            transform: skewX(-25deg);
            transition: none;
        }
        .glass-flash:hover::after {
            animation: flash-anim 0.6s ease-out forwards;
        }
        @keyframes flash-anim {
            0% { left: -100%; }
            100% { left: 200%; }
        }

        /* Smooth Tab Transition Animations */
        .tab-content {
            display: none;
            opacity: 0;
            transform: translateY(15px);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .tab-content.active {
            display: block;
            opacity: 1;
            transform: translateY(0);
        }

        /* Form Inputs */
        .form-input {
            width: 100%;
            background-color: transparent;
            border: none;
            border-bottom: 2px solid #e2e8f0;
            padding: 0.75rem 0;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.2s;
            border-radius: 0;
        }
        .dark .form-input { border-bottom-color: #334155; color: #f8fafc; }
        .form-input:focus {
            outline: none;
            border-bottom-color: #FF7A00;
            box-shadow: none;
        }
        
        textarea.form-input {
            border: 2px solid #e2e8f0;
            padding: 1rem;
            border-radius: 1rem;
        }
        .dark textarea.form-input { border-color: #334155; }
        textarea.form-input:focus { border-color: #FF7A00; }

        /* Glassmorphism Select Dropdown */
        .glass-select {
            background: rgba(255, 255, 255, 0.4);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.6);
            border-radius: 0.75rem;
            padding: 0.75rem 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        }
        .dark .glass-select {
            background: rgba(30, 41, 59, 0.6);
            border-color: rgba(255, 255, 255, 0.1);
            color: #f8fafc;
        }

        /* Nav Pills active state */
        .nav-pill { transition: all 0.3s ease; }
        .nav-pill.active {
            background-color: #FF7A00; 
            color: white;
            box-shadow: 0 4px 15px rgba(255, 122, 0, 0.3);
        }
    </style>
</head>

<body class="text-slate-800 dark:text-gray-100 font-sans min-h-screen flex flex-col selection:bg-orange-glow selection:text-white transition-colors duration-300">

<div class="fixed inset-0 -z-20 bg-cross-pattern pointer-events-none"></div>
<div class="fixed top-[-10%] left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-gradient-to-b from-orange-100/60 via-orange-50/20 to-transparent dark:from-orange-900/20 dark:via-orange-900/5 rounded-full blur-3xl pointer-events-none -z-10 transition-colors duration-300"></div>

<header class="w-full pt-10 pb-6 flex flex-col items-center justify-center relative z-20 text-center">
    <div class="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-white dark:bg-slate-800 shadow-xl border-4 border-orange-glow flex items-center justify-center overflow-hidden mb-4 animate-float group cursor-pointer">
        <img src="<?= urlof('assets/imgs/nn-final.png')?>" alt="NagarNivaran Logo" onerror="this.src='https://placehold.co/110x110/FF7A00/FFFFFF?text=NN'" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110">
    </div>
    
    <h1 class="font-heading text-4xl sm:text-5xl font-black tracking-tight text-slate-900 dark:text-white transition-colors">
        Nagar<span class="text-orange-glow">Nivaran</span>
    </h1>
    <p class="font-gujarati text-red-400 text-base sm:text-lg mt-1 sm:mt-2 font-medium">નગરનિવારણ • જામનગર મહાનગરપાલિકા</p>
    <div class="mt-3">
        <span class="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-400 font-bold text-xs px-4 py-1.5 rounded-full tracking-widest uppercase shadow-sm border border-emerald-200 dark:border-emerald-800/50 transition-colors">
            Citizen Command Panel
        </span>
    </div>
</header>

<main class="w-full max-w-6xl mx-auto bg-white dark:bg-slate-900 min-h-[75vh] rounded-t-[40px] shadow-[0_-15px_50px_rgba(0,0,0,0.08)] dark:shadow-[0_-15px_50px_rgba(0,0,0,0.3)] border-t border-x border-gray-100 dark:border-slate-800 flex flex-col relative z-30 transition-colors duration-300 pb-20">

    <div class="p-6 md:p-8 pb-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-gray-100 dark:border-slate-800">
        
        <div class="flex items-center gap-4">
            <div class="w-14 h-14 rounded-full border-2 border-orange-200 dark:border-orange-500/50 overflow-hidden bg-gray-100 shrink-0 shadow-sm">
                <?php if (!empty($user["photo"])): ?>
                    <img src="<?= urlof('assets/uploads/user/' . htmlspecialchars($user["photo"])) ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <i class="fa-solid fa-user text-gray-400 w-full h-full flex items-center justify-center mt-2 text-xl"></i>
                <?php endif; ?>
            </div>
            <div class="flex flex-col">
                <div class="flex items-center gap-2">
                    <p class="text-xs text-gray-400 dark:text-gray-500 font-bold uppercase tracking-widest">Welcome Back</p>
                    <span class="w-1.5 h-1.5 rounded-full bg-gray-300 dark:bg-gray-600"></span>
                    <span class="text-[10px] font-bold text-orange-glow bg-orange-50 dark:bg-orange-900/30 px-2 py-0.5 rounded border border-orange-100 dark:border-orange-800/50">Ward: <?= htmlspecialchars($user["ward"] ?: "N/A") ?></span>
                </div>
                <h2 class="font-heading font-extrabold text-xl md:text-2xl text-slate-900 dark:text-white leading-tight truncate max-w-[250px]"><?= htmlspecialchars($user["full_name"]) ?></h2>
            </div>
        </div>

        <div class="flex items-center gap-3">
            <button onclick="toggleSettingsModal()" class="w-10 h-10 rounded-xl bg-gray-50 hover:bg-gray-100 dark:bg-slate-800 dark:hover:bg-slate-700 border border-gray-200 dark:border-slate-700 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:text-orange-glow transition-all active:scale-95 shadow-sm">
                <i class="fa-solid fa-gear text-lg"></i>
            </button>

            <a href="<?= urlof('api/user/logout.php') ?>" class="px-4 py-2 sm:py-2.5 rounded-xl bg-red-50 hover:bg-red-500 dark:bg-red-500/10 dark:hover:bg-red-600 text-red-500 hover:text-white font-bold text-xs sm:text-sm transition-all shadow-sm flex items-center gap-2 active:scale-95 border border-red-100 dark:border-red-500/20">
                <i class="fa-solid fa-power-off"></i> <span class="hidden sm:inline">Logout</span>
            </a>
        </div>
    </div>

    <div class="px-6 md:px-8 py-4 border-b border-gray-50 dark:border-slate-800">
        <div class="flex items-center gap-3 overflow-x-auto pb-2 -mb-2">
            <button onclick="switchTab('overview', this)" class="nav-pill active glass-flash shrink-0 px-6 py-3 rounded-full font-bold text-sm bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-gray-400 hover:text-orange-glow dark:hover:text-orange-400">
                <i class="fa-solid fa-chart-pie mr-1"></i> Dashboard
            </button>
            <button onclick="switchTab('report', this)" class="nav-pill glass-flash shrink-0 px-6 py-3 rounded-full font-bold text-sm bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-gray-400 hover:text-orange-glow dark:hover:text-orange-400">
                <i class="fa-solid fa-bullhorn mr-1"></i> Report Issue
            </button>
            <button onclick="switchTab('history', this)" class="nav-pill glass-flash shrink-0 px-6 py-3 rounded-full font-bold text-sm bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-gray-400 hover:text-orange-glow dark:hover:text-orange-400">
                <i class="fa-solid fa-layer-group mr-1"></i> My Cases
            </button>
            <button onclick="switchTab('profile', this)" class="nav-pill glass-flash shrink-0 px-6 py-3 rounded-full font-bold text-sm bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-gray-400 hover:text-orange-glow dark:hover:text-orange-400">
                <i class="fa-solid fa-user-shield mr-1"></i> Profile
            </button>
        </div>
    </div>

    <div class="flex-1 p-6 md:p-8 lg:p-10 relative">

        <div id="section-overview" class="tab-content active space-y-8">
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="bg-blue-50 dark:bg-slate-800 p-6 rounded-3xl border border-blue-200 dark:border-slate-700 shadow-sm flex flex-col justify-between hover:-translate-y-1 transition-transform">
                    <div class="flex justify-between items-start mb-4">
                        <div class="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-500 flex items-center justify-center text-xl">
                            <i class="fa-solid fa-folder-open"></i>
                        </div>
                        <span class="text-xs font-bold bg-blue-100 dark:bg-blue-900/50 text-blue-500 dark:text-blue-300 px-2 py-1 rounded-md">Total</span>
                    </div>
                    <div>
                        <h3 class="text-4xl font-heading font-black text-slate-900 dark:text-white"><?= $total ?></h3>
                        <p class="text-sm font-medium text-blue-500 dark:text-gray-400 mt-1">Complaints Lodged</p>
                    </div>
                </div>

                <div class="bg-emerald-50 dark:bg-slate-800 p-6 rounded-3xl border border-emerald-200 dark:border-slate-700 shadow-sm flex flex-col justify-between hover:-translate-y-1 transition-transform">
                    <div class="flex justify-between items-start mb-4">
                        <div class="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-500 flex items-center justify-center text-xl">
                            <i class="fa-solid fa-circle-check"></i>
                        </div>
                        <span class="text-xs font-bold bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 px-2 py-1 rounded-md">Done</span>
                    </div>
                    <div>
                        <h3 class="text-4xl font-heading font-black text-slate-900 dark:text-white"><?= $resolved ?></h3>
                        <p class="text-sm font-medium text-emerald-500 dark:text-gray-400 mt-1">Successfully Resolved</p>
                    </div>
                </div>

                <div class="bg-orange-50 dark:bg-slate-800 p-6 rounded-3xl border border-orange-200 dark:border-slate-700 shadow-sm flex flex-col justify-between hover:-translate-y-1 transition-transform">
                    <div class="flex justify-between items-start mb-4">
                        <div class="w-12 h-12 rounded-full bg-orange-100 dark:bg-orange-900/30 text-orange-glow flex items-center justify-center text-xl">
                            <i class="fa-solid fa-clock"></i>
                        </div>
                        <span class="text-xs font-bold bg-orange-100 dark:bg-orange-900/50 text-orange-600 dark:text-orange-400 px-2 py-1 rounded-md">Wait</span>
                    </div>
                    <div>
                        <h3 class="text-4xl font-heading font-black text-slate-900 dark:text-white"><?= $pending ?></h3>
                        <p class="text-sm font-medium text-orange-500 dark:text-gray-400 mt-1">Pending Action</p>
                    </div>
                </div>

                <div class="bg-purple-50 dark:bg-slate-800 p-6 rounded-3xl border border-purple-200 dark:border-slate-700 shadow-sm flex flex-col justify-between hover:-translate-y-1 transition-transform">
                    <div class="flex justify-between items-start mb-4">
                        <div class="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-500 flex items-center justify-center text-xl">
                            <i class="fa-solid fa-helmet-safety"></i>
                        </div>
                        <span class="text-xs font-bold bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400 px-2 py-1 rounded-md">Active</span>
                    </div>
                    <div>
                        <h3 class="text-4xl font-heading font-black text-slate-900 dark:text-white"><?= $inProgress ?></h3>
                        <p class="text-sm font-medium text-purple-500 dark:text-gray-400 mt-1">Work in Progress</p>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-r from-dark-slate to-slate-800 dark:from-black dark:to-slate-900 rounded-[32px] p-8 sm:p-12 text-white flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden shadow-xl border border-slate-700">
                <div class="absolute right-0 top-0 h-full w-1/2 bg-gradient-to-l from-orange-glow/20 to-transparent pointer-events-none"></div>
                <div class="relative z-10 max-w-xl">
                    <span class="text-xs font-bold text-tomato uppercase tracking-widest bg-white/10 px-4 py-1.5 rounded-full border border-white/10 shadow-sm backdrop-blur-md inline-block mb-4">Action Needed</span>
                    <h3 class="font-heading font-extrabold text-3xl sm:text-4xl mb-3">Spot a civic issue?</h3>
                    <p class="text-gray-300 text-sm sm:text-base leading-relaxed">Report potholes, broken lights, or water leaks directly to the municipal officers using our streamlined digital dispatch system.</p>
                </div>
                <button onclick="switchTab('report', document.querySelectorAll('.nav-pill')[1])" class="w-full md:w-auto px-8 py-4 sm:py-5 rounded-2xl bg-gradient-to-r from-orange-glow to-tomato hover:opacity-90 text-white font-bold text-sm sm:text-base shadow-[0_8px_25px_rgba(255,99,71,0.5)] transition-transform active:scale-95 shrink-0 flex items-center justify-center gap-3 relative z-10">
                    Lodge Complaint <i class="fa-solid fa-arrow-right"></i>
                </button>
            </div>

        </div>

        <div id="section-report" class="tab-content max-w-4xl mx-auto">
            
            <div class="mb-8">
                <h2 class="font-heading font-extrabold text-3xl text-slate-900 dark:text-white">File Grievance</h2>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-2">System will auto-route your report to the appropriate JMC officers based on category and location.</p>
            </div>

            <form id="complaintForm" action="<?= urlof('api/user/report.php') ?>" method="POST" enctype="multipart/form-data" class="space-y-8 bg-gray-50 dark:bg-slate-800/50 p-6 sm:p-10 rounded-3xl border border-gray-100 dark:border-slate-700 shadow-sm">
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <label class="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest mb-2">Complaint Title <span class="text-tomato">*</span></label>
                        <input type="text" name="title" required placeholder="e.g. Broken Streetlight" class="form-input text-lg">
                    </div>

                    <div class="relative">
                        <!-- <label class="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest mb-2">Assign Department <span class="text-tomato">*</span></label>
                        <select name="department_id" required class="glass-select w-full text-slate-900 font-bold text-sm appearance-none outline-none focus:border-orange-glow transition-colors cursor-pointer">
                            <option value="" disabled selected class="text-gray-500">Select appropriate department...</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?= (int)$dept["id"] ?>" class="text-slate-900 bg-white dark:bg-slate-800 dark:text-white"><?= htmlspecialchars($dept["department_name"]) ?></option>
                            <?php endforeach; ?>
                        </select> -->
                        <!-- <i class="fa-solid fa-chevron-down absolute right-4 bottom-4 text-gray-400 pointer-events-none"></i> -->
                        
                        <div class="relative" id="custom-dropdown-container">
                            <label class="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest mb-2">Assign Department <span class="text-tomato">*</span></label>
    
                            <input type="hidden" name="department_id" id="department_id" required>

                            <button type="button" id="dropdown-trigger" class="w-full text-left bg-white/40 dark:bg-slate-800/60 backdrop-blur-md border border-white/60 dark:border-slate-700 rounded-xl px-4 py-3 text-sm font-bold text-gray-500 dark:text-gray-400 shadow-sm focus:outline-none focus:border-orange-glow transition-colors flex justify-between items-center">
                                <span id="dropdown-selected-text">Select appropriate department...</span>
                                <i class="fa-solid fa-chevron-down text-gray-400 transition-transform duration-300" id="dropdown-icon"></i>
                            </button>

                            <ul id="dropdown-menu" class="absolute z-50 w-full mt-2 bg-white/60 dark:bg-slate-800/70 backdrop-blur-xl border border-orange-200 dark:border-slate-700 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.1)] p-2 hidden opacity-0 translate-y-[-10px] transition-all duration-300 max-h-60 overflow-y-auto custom-scroll">

                                <?php foreach ($departments as $dept): ?>
                                    <li data-value="<?= (int)$dept["id"] ?>" class="dropdown-item px-4 py-3 mb-1.5 last:mb-0 rounded-xl text-sm font-bold text-slate-700 dark:text-gray-200 cursor-pointer bg-transparent hover:bg-orange-50 dark:hover:bg-slate-700 hover:text-orange-glow hover:shadow-sm transition-all flex items-center justify-between">
                                        <?= htmlspecialchars($dept["department_name"]) ?>
                                       <i class="fa-solid fa-check text-orange-glow opacity-0 transition-opacity check-icon"></i>
                                    </li>
                                <?php endforeach; ?>
                                
                            </ul>
                        </div>

                        <style>
                            .custom-scroll::-webkit-scrollbar { width: 4px; }
                            .custom-scroll::-webkit-scrollbar-track { background: transparent; }
                            .custom-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
                            .dark .custom-scroll::-webkit-scrollbar-thumb { background: #475569; }
                        </style>
                    </div>

                    <!-- Priority -->
                        <div class="relative" id="priority-dropdown-container">

                            <label class="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest mb-2">
                                Complaint Priority
                                <span class="text-tomato">*</span>
                            </label>
                            <!-- Actual value submitted to PHP -->
                            <input
                                type="hidden"
                                name="priority"
                                id="priority"
                                value="Medium"
                            >
                            <!-- Custom dropdown button -->
                            <button
                                type="button"
                                id="priority-trigger"
                                class="w-full text-left bg-white/40 dark:bg-slate-800/60 backdrop-blur-md border border-white/60 dark:border-slate-700 rounded-xl px-4 py-3 text-sm font-bold text-slate-900 dark:text-white shadow-sm focus:outline-none focus:border-orange-glow transition-colors flex justify-between items-center">
                                <span
                                    id="priority-selected-text"
                                    class="flex items-center gap-3">
                                    <span class="w-2.5 h-2.5 rounded-full bg-orange-glow"></span>
                                    Medium
                                </span>

                                <i class="fa-solid fa-chevron-down text-gray-400 transition-transform duration-300" id="priority-icon"></i>
                            </button>
                            <!-- Priority Menu -->
                            <ul
                                id="priority-menu"
                                class="absolute z-50 w-full mt-2 bg-white/60 dark:bg-slate-800/70 backdrop-blur-xl border border-orange-200 dark:border-slate-700 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.1)] p-2 hidden opacity-0 translate-y-[-10px] transition-all duration-300">

                                <!-- Low -->
                                <li
                                    data-value="Low"
                                    class="priority-item px-4 py-3 mb-1.5 rounded-xl text-sm font-bold text-slate-700 dark:text-gray-200 cursor-pointer hover:bg-orange-50 dark:hover:bg-slate-700 hover:text-orange-glow transition-all flex items-center justify-between"
                                >
                                    <span class="flex items-center gap-3">
                                        <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                                        Low
                                    </span>

                                    <i class="fa-solid fa-check text-orange-glow opacity-0 check-icon"></i>
                                </li>


                                <!-- Medium -->
                                <li
                                    data-value="Medium"
                                    class="priority-item px-4 py-3 mb-1.5 rounded-xl text-sm font-bold text-slate-700 dark:text-gray-200 cursor-pointer hover:bg-orange-50 dark:hover:bg-slate-700 hover:text-orange-glow transition-all flex items-center justify-between"
                                >
                                    <span class="flex items-center gap-3">
                                        <span class="w-2.5 h-2.5 rounded-full bg-orange-glow"></span>
                                        Medium
                                    </span>

                                    <i class="fa-solid fa-check text-orange-glow check-icon"></i>
                                </li>


                                <!-- High -->
                                <li
                                    data-value="High"
                                    class="priority-item px-4 py-3 mb-1.5 rounded-xl text-sm font-bold text-slate-700 dark:text-gray-200 cursor-pointer hover:bg-orange-50 dark:hover:bg-slate-700 hover:text-orange-glow transition-all flex items-center justify-between"
                                >
                                    <span class="flex items-center gap-3">
                                        <span class="w-2.5 h-2.5 rounded-full bg-orange-500"></span>
                                        High
                                    </span>

                                    <i class="fa-solid fa-check text-orange-glow opacity-0 check-icon"></i>
                                </li>


                                <!-- Critical -->
                                <li
                                    data-value="Critical"
                                    class="priority-item px-4 py-3 rounded-xl text-sm font-bold text-slate-700 dark:text-gray-200 cursor-pointer hover:bg-orange-50 dark:hover:bg-slate-700 hover:text-orange-glow transition-all flex items-center justify-between"
                                >
                                    <span class="flex items-center gap-3">
                                        <span class="w-2.5 h-2.5 rounded-full bg-red-600"></span>
                                        Critical
                                    </span>

                                    <i class="fa-solid fa-check text-orange-glow opacity-0 check-icon"></i>
                                </li>

                            </ul>

                        </div>

                    <div>
                        <label class="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest mb-2">Ward & Landmark Location <span class="text-tomato">*</span></label>
                        <input type="text" name="location" id="location-input" required placeholder="Enter area..." class="form-input text-base">
                    </div>

                    <div class="flex items-end">
                        <button type="button" onclick="getLocation()" class="w-full py-3 bg-white dark:bg-slate-700 hover:bg-orange-50 dark:hover:bg-orange-900/30 text-gray-700 dark:text-gray-200 hover:text-orange-glow font-bold text-sm rounded-xl border border-gray-200 dark:border-slate-600 hover:border-orange-200 transition-all flex items-center justify-center gap-2 shadow-sm active:scale-95">
                            <i class="fa-solid fa-location-crosshairs text-orange-glow"></i> Fetch GPS Coordinates
                        </button>
                        <input type="hidden" name="latitude" id="lat-input">
                        <input type="hidden" name="longitude" id="lng-input">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest mb-3">Detailed Description <span class="text-tomato">*</span></label>
                    <textarea name="description" rows="4" required placeholder="Describe the severity, exact spot, and potential hazards..." class="form-input text-base resize-none bg-white dark:bg-slate-800 shadow-sm"></textarea>
                </div>

                <div>
                    <label class="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest mb-3">Photographic Evidence</label>
                    <div onclick="document.getElementById('image-upload').click()" class="w-full border-2 border-dashed border-gray-300 dark:border-slate-600 rounded-2xl p-8 text-center bg-white dark:bg-slate-800 hover:bg-orange-50 dark:hover:bg-orange-900/20 hover:border-orange-300 dark:hover:border-orange-500 cursor-pointer transition-all group shadow-sm">
                        <div class="w-14 h-14 bg-gray-50 dark:bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-orange-100 dark:group-hover:bg-orange-900/50 transition-colors">
                            <i class="fa-solid fa-cloud-arrow-up text-2xl text-gray-400 dark:text-gray-500 group-hover:text-orange-glow transition-colors"></i>
                        </div>
                        <span class="block text-base font-bold text-gray-700 dark:text-gray-300">Tap to upload image evidence</span>
                        <span class="block text-xs text-gray-400 dark:text-gray-500 mt-2">Supported: PNG, JPG, WEBP (Max 5MB)</span>
                        <span id="file-name" class="block text-sm font-bold text-tomato mt-3"></span>
                        <input type="file" name="image" id="image-upload" accept="image/*" class="hidden" onchange="displayFileName(this)">
                    </div>
                </div>

                <div class="pt-4 border-t border-gray-200 dark:border-slate-700 flex justify-end">
                    <button type="submit" id="submitBtn" class="w-full sm:w-auto px-10 py-4 bg-dark-slate glass-flash dark:bg-orange-glow hover:bg-orange-glow dark:hover:bg-orange-600 text-white font-bold text-sm sm:text-base rounded-2xl shadow-xl transition-all active:scale-95 flex items-center justify-center gap-3">
                        Submit to Grid <i class="fa-solid fa-paper-plane"></i>
                    </button>
                </div>

            </form>
        </div>

        <div id="section-history" class="tab-content">
            <div class="mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                    <h2 class="font-heading font-extrabold text-3xl text-slate-900 dark:text-white">My Cases Ledger</h2>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mt-2">Live tracking of your submissions against JMC dispatch logs.</p>
                </div>
                <div class="px-4 py-2 bg-gray-100 dark:bg-slate-800 rounded-lg text-sm font-bold text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-slate-700 shadow-sm">
                    Total: <span class="text-orange-glow ml-1"><?= $total ?></span>
                </div>
            </div>

            <div class="bg-white dark:bg-slate-800 rounded-3xl border border-gray-100 dark:border-slate-700 shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse whitespace-nowrap">
                        <thead>
                            <tr class="border-b border-gray-100 dark:border-slate-700 text-xs uppercase tracking-widest font-bold text-gray-400 dark:text-gray-500 bg-gray-50/50 dark:bg-slate-900/50">
                                <th class="py-5 px-6">Filed ID</th>
                                <th class="py-5 px-6">Grievance / Department</th>
                                <th class="py-5 px-6">Date Lodged</th>
                                <th class="py-5 px-6">Live Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-50 dark:divide-slate-700/50 text-sm">
                            <?php if (!empty($complaints)): ?>
                                <?php foreach ($complaints as $c): ?>
                                    <tr class="hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors group">
                                        <td class="py-5 px-6 font-mono font-bold text-gray-400 dark:text-gray-500 group-hover:text-orange-glow transition-colors">#<?= (int)$c["id"] ?></td>
                                        <td class="py-5 px-6">
                                            <p class="font-bold text-base text-slate-900 dark:text-gray-100"><?= htmlspecialchars($c["title"]) ?></p>
                                            <p class="text-xs text-gray-500 dark:text-gray-400 font-medium mt-1"><i class="fa-solid fa-building-user mr-1 text-gray-300"></i> <?= htmlspecialchars($c["department_name"] ?? "JMC System") ?></p>
                                        </td>
                                        <td class="py-5 px-6 text-gray-500 dark:text-gray-400 font-medium text-sm">
                                            <i class="fa-regular fa-calendar mr-1.5 text-gray-300"></i> <?= !empty($c["created_at"]) ? date("M d, Y", strtotime($c["created_at"])) : "N/A" ?>
                                        </td>
                                        <td class="py-5 px-6">
                                            <?php if ($c["status"] === "Resolved"): ?>
                                                <span class="px-3 py-1.5 rounded-md bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800 text-xs font-bold tracking-wide"><i class="fa-solid fa-check mr-1"></i> Resolved</span>
                                            <?php elseif ($c["status"] === "In Progress"): ?>
                                                <span class="px-3 py-1.5 rounded-md bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 border border-purple-100 dark:border-purple-800 text-xs font-bold tracking-wide"><i class="fa-solid fa-spinner fa-spin mr-1"></i> Active</span>
                                            <?php elseif ($c["status"] === "Rejected"): ?>
                                                <span class="px-3 py-1.5 rounded-md bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 border border-red-100 dark:border-red-800 text-xs font-bold tracking-wide"><i class="fa-solid fa-xmark mr-1"></i> Rejected</span>
                                            <?php else: ?>
                                                <span class="px-3 py-1.5 rounded-md bg-orange-50 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400 border border-orange-100 dark:border-orange-800 text-xs font-bold tracking-wide"><i class="fa-solid fa-clock mr-1"></i> Pending</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="py-16 text-center text-gray-400 text-sm font-medium">
                                        <div class="w-16 h-16 bg-gray-50 dark:bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
                                            <i class="fa-solid fa-inbox text-2xl text-gray-300 dark:text-gray-500"></i>
                                        </div>
                                        No complaints recorded in the ledger yet.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="section-profile" class="tab-content max-w-4xl mx-auto">
            
            <div class="flex flex-col md:flex-row items-center md:items-start gap-8 mb-10">
                <div class="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-white dark:border-slate-800 shadow-xl overflow-hidden bg-gray-100 shrink-0">
                    <?php if (!empty($user["photo"])): ?>
                        <img src="<?= urlof('assets/uploads/user/' . htmlspecialchars($user["photo"])) ?>" class="w-full h-full object-cover">
                    <?php else: ?>
                        <i class="fa-solid fa-user text-gray-300 text-6xl w-full h-full flex items-center justify-center mt-4"></i>
                    <?php endif; ?>
                </div>
                
                <div class="text-center md:text-left pt-2">
                    <h2 class="font-heading font-black text-3xl md:text-4xl text-slate-900 dark:text-white"><?= htmlspecialchars($user["full_name"]) ?></h2>
                    <p class="text-xs font-bold text-emerald-500 uppercase tracking-widest mt-2 bg-emerald-50 dark:bg-emerald-900/30 border border-emerald-100 dark:border-emerald-800 inline-block px-3 py-1 rounded-full"><i class="fa-solid fa-shield-check mr-1"></i> Verified Auditor</p>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mt-4 leading-relaxed max-w-md">Official account associated with Jamnagar Smart City Grid. Keeping your details up to date ensures faster grievance routing.</p>
                </div>
            </div>

            <div class="mb-6">
                <span class="inline-block bg-gray-200 dark:bg-slate-700 text-gray-700 dark:text-gray-300 font-bold text-xs uppercase tracking-widest px-4 py-2 rounded-md shadow-sm border border-gray-300 dark:border-slate-600">
                    Registered Details
                </span>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                
                <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-blue-200 dark:border-blue-900/50 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
                    <div class="absolute left-0 top-0 h-full w-1.5 bg-blue-400"></div>
                    <p class="text-[10px] font-bold text-blue-500 uppercase tracking-widest mb-1 pl-3"><i class="fa-solid fa-phone mr-1"></i> Mobile Number</p>
                    <p class="font-mono font-bold text-lg text-slate-900 dark:text-white pl-3">+91 <?= htmlspecialchars($user["mobile"] ?: "N/A") ?></p>
                </div>
                
                <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-purple-200 dark:border-purple-900/50 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
                    <div class="absolute left-0 top-0 h-full w-1.5 bg-purple-400"></div>
                    <p class="text-[10px] font-bold text-purple-500 uppercase tracking-widest mb-1 pl-3"><i class="fa-solid fa-envelope mr-1"></i> Email Address</p>
                    <p class="font-bold text-base text-slate-900 dark:text-white pl-3 truncate"><?= htmlspecialchars($user["email"] ?: "N/A") ?></p>
                </div>
                
                <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-orange-200 dark:border-orange-900/50 shadow-sm hover:shadow-md transition-shadow sm:col-span-2 relative overflow-hidden">
                    <div class="absolute left-0 top-0 h-full w-1.5 bg-orange-400"></div>
                    <p class="text-[10px] font-bold text-orange-500 uppercase tracking-widest mb-1 pl-3"><i class="fa-solid fa-house mr-1"></i> Residential Address</p>
                    <p class="font-bold text-lg text-slate-900 dark:text-white pl-3 leading-snug"><?= htmlspecialchars($user["house_no"] . ", " . $user["area"]) ?></p>
                </div>
                
                <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-emerald-200 dark:border-emerald-900/50 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
                    <div class="absolute left-0 top-0 h-full w-1.5 bg-emerald-400"></div>
                    <p class="text-[10px] font-bold text-emerald-500 uppercase tracking-widest mb-1 pl-3"><i class="fa-solid fa-map-location-dot mr-1"></i> Assigned Ward</p>
                    <p class="font-bold text-lg text-orange-glow pl-3"><?= htmlspecialchars($user["ward"] ?: "N/A") ?></p>
                </div>
                
                <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-pink-200 dark:border-pink-900/50 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
                    <div class="absolute left-0 top-0 h-full w-1.5 bg-pink-400"></div>
                    <p class="text-[10px] font-bold text-pink-500 uppercase tracking-widest mb-1 pl-3"><i class="fa-solid fa-location-pin mr-1"></i> PIN Code</p>
                    <p class="font-mono font-bold text-lg text-slate-900 dark:text-white pl-3"><?= htmlspecialchars($user["pincode"] ?: "N/A") ?></p>
                </div>

            </div>
        </div>

    </div>
</main>

<div id="settingsOverlay" class="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 hidden transition-opacity" onclick="toggleSettingsModal()"></div>

<div id="settingsModal" class="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white dark:bg-slate-900 w-11/12 max-w-sm rounded-3xl shadow-2xl border border-gray-100 dark:border-slate-800 z-50 hidden scale-95 opacity-0 transition-all duration-300">
    <div class="p-6 border-b border-gray-100 dark:border-slate-800 flex items-center justify-between">
        <h3 class="font-heading font-black text-xl text-slate-900 dark:text-white"><i class="fa-solid fa-sliders text-orange-glow mr-2"></i> Settings</h3>
        <button onclick="toggleSettingsModal()" class="w-8 h-8 rounded-full bg-gray-100 dark:bg-slate-800 text-gray-500 hover:text-red-500 flex items-center justify-center transition-colors">
            <i class="fa-solid fa-times"></i>
        </button>
    </div>
    
    <div class="p-6 space-y-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="font-bold text-sm text-slate-900 dark:text-white">Appearance</p>
                <p class="text-xs text-gray-500 dark:text-gray-400">Toggle dark mode theme</p>
            </div>
            <button onclick="toggleDarkMode()" id="darkModeBtn" class="w-14 h-8 bg-gray-200 dark:bg-orange-glow rounded-full relative transition-colors shadow-inner flex items-center px-1 cursor-pointer">
                <div id="darkModeKnob" class="w-6 h-6 bg-white rounded-full shadow-md transform transition-transform duration-300 dark:translate-x-6 flex items-center justify-center">
                    <i class="fa-solid fa-moon text-[10px] text-gray-400 dark:text-orange-glow hidden dark:block"></i>
                    <i class="fa-solid fa-sun text-[10px] text-orange-400 dark:hidden"></i>
                </div>
            </button>
        </div>

        <div>
            <div class="mb-3">
                <p class="font-bold text-sm text-slate-900 dark:text-white">Text Size</p>
                <p class="text-xs text-gray-500 dark:text-gray-400">Adjust overall font scale</p>
            </div>
            <div class="flex items-center gap-4 bg-gray-50 dark:bg-slate-800 p-2 rounded-xl border border-gray-100 dark:border-slate-700">
                <button onclick="adjustTextSize(-1)" class="flex-1 py-2 bg-white dark:bg-slate-700 text-slate-700 dark:text-white rounded-lg shadow-sm border border-gray-200 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-600 font-bold active:scale-95 transition-all">
                    <i class="fa-solid fa-minus"></i>
                </button>
                <span class="font-mono font-bold text-sm text-gray-500 dark:text-gray-400 w-12 text-center" id="textSizeDisplay">100%</span>
                <button onclick="adjustTextSize(1)" class="flex-1 py-2 bg-white dark:bg-slate-700 text-slate-700 dark:text-white rounded-lg shadow-sm border border-gray-200 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-600 font-bold active:scale-95 transition-all">
                    <i class="fa-solid fa-plus"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<script>
/*
|--------------------------------------------------------------------------
| Tab Switching & Animations
|--------------------------------------------------------------------------
*/
function switchTab(tabId, clickedBtn) {
    const tabs = ['overview', 'report', 'history', 'profile'];
    
    // Hide all sections
    tabs.forEach(id => {
        document.getElementById('section-' + id).classList.remove('active');
    });

    // Reset all buttons
    document.querySelectorAll('.nav-pill').forEach(btn => {
        btn.classList.remove('active', 'bg-orange-glow', 'text-white', 'shadow-md', 'dark:bg-slate-800');
        // If not active, it should be gray
        btn.classList.add('bg-gray-100', 'text-gray-500', 'dark:bg-slate-800', 'dark:text-gray-400');
    });

    // Show target section with slight delay for animation
    setTimeout(() => { 
        document.getElementById('section-' + tabId).classList.add('active');
    }, 10);

    // Style clicked button
    clickedBtn.classList.remove('bg-gray-100', 'text-gray-500', 'dark:bg-slate-800', 'dark:text-gray-400');
    clickedBtn.classList.add('active', 'bg-orange-glow', 'text-white', 'shadow-md');
    
    // Ensure button is visible in scroll area
    clickedBtn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
}

/*
|--------------------------------------------------------------------------
| Display Uploaded Filename
|--------------------------------------------------------------------------
*/
function displayFileName(input) {
    if (input.files && input.files[0]) {
        document.getElementById('file-name').innerText = "Attached: " + input.files[0].name;
    }
}

/*
|--------------------------------------------------------------------------
| GPS Location
|--------------------------------------------------------------------------
*/
function getLocation() {
    const locInput = document.getElementById('location-input');
    if (!navigator.geolocation) {
        Swal.fire('Error', "Geolocation is not supported by your browser.", 'error');
        return;
    }
    locInput.value = "Acquiring satellites...";
    navigator.geolocation.getCurrentPosition(
        function(position) {
            document.getElementById('lat-input').value = position.coords.latitude;
            document.getElementById('lng-input').value = position.coords.longitude;
            locInput.value = `GPS: ${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`;
        },
        function() {
            Swal.fire('Warning', "Unable to retrieve location. Please type manually.", 'warning');
            locInput.value = "";
        }
    );
}

/*
|--------------------------------------------------------------------------
| Settings Modal (Dark Mode & Text Size)
|--------------------------------------------------------------------------
*/
function toggleSettingsModal() {
    const overlay = document.getElementById('settingsOverlay');
    const modal = document.getElementById('settingsModal');
    
    if (modal.classList.contains('hidden')) {
        overlay.classList.remove('hidden');
        modal.classList.remove('hidden');
        setTimeout(() => {
            modal.classList.remove('scale-95', 'opacity-0');
            modal.classList.add('scale-100', 'opacity-100');
        }, 10);
    } else {
        modal.classList.remove('scale-100', 'opacity-100');
        modal.classList.add('scale-95', 'opacity-0');
        setTimeout(() => {
            modal.classList.add('hidden');
            overlay.classList.add('hidden');
        }, 300);
    }
}

// Check Local Storage for Dark Mode on load
// if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
//     document.documentElement.classList.add('dark');
// }

// Check Local Storage for Theme on load - DEFAULT TO LIGHT
if (localStorage.getItem('theme') === 'dark') {
    document.documentElement.classList.add('dark'); // Apply dark only if explicitly saved
} else {
    document.documentElement.classList.remove('dark'); // Force Light mode by default
    localStorage.setItem('theme', 'light'); // Save light mode as the default state
}

function toggleDarkMode() {
    if (document.documentElement.classList.contains('dark')) {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('theme', 'light');
    } else {
        document.documentElement.classList.add('dark');
        localStorage.setItem('theme', 'dark');
    }
}

// Text Size Control
let currentScale = 100;
const rootHtml = document.documentElement;
const sizeDisplay = document.getElementById('textSizeDisplay');

// Load text size from local storage
if(localStorage.getItem('textScale')) {
    currentScale = parseInt(localStorage.getItem('textScale'));
    applyTextScale();
}

function adjustTextSize(direction) {
    if (direction > 0 && currentScale < 120) {
        currentScale += 10;
    } else if (direction < 0 && currentScale > 80) {
        currentScale -= 10;
    }
    applyTextScale();
}

function applyTextScale() {
    rootHtml.style.fontSize = (16 * (currentScale / 100)) + "px";
    sizeDisplay.innerText = currentScale + "%";
    localStorage.setItem('textScale', currentScale);
}

/*
|--------------------------------------------------------------------------
| AJAX Complaint Submission
|--------------------------------------------------------------------------
*/
$(document).ready(function() {
    $('#complaintForm').on('submit', function(e) {
        e.preventDefault(); 
        
        let formData = new FormData(this);
        let btn = $('#submitBtn');
        let originalText = btn.html();

        btn.html('<i class="fa-solid fa-spinner fa-spin"></i> Processing...').prop('disabled', true);

        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        title: 'Logged Successfully',
                        text: "Ticket ID: #" + response.complaint_id,
                        icon: 'success',
                        confirmButtonColor: '#FF7A00',
                        confirmButtonText: 'View Dashboard'
                    }).then(() => {
                        window.location.reload(); 
                    });
                } else {
                    Swal.fire('Failed', response.message, 'error');
                    btn.html(originalText).prop('disabled', false);
                }
            },
            error: function() {
                Swal.fire('Server Error', 'Could not connect to grid. Try again.', 'error');
                btn.html(originalText).prop('disabled', false);
            }
        });
    });
});
</script>

<script>
/*
|--------------------------------------------------------------------------
| Custom Glassmorphism Dropdown Logic
|--------------------------------------------------------------------------
*/
document.addEventListener('DOMContentLoaded', function() {
    const trigger = document.getElementById('dropdown-trigger');
    const menu = document.getElementById('dropdown-menu');
    const selectedText = document.getElementById('dropdown-selected-text');
    const hiddenInput = document.getElementById('department_id');
    const icon = document.getElementById('dropdown-icon');
    const items = document.querySelectorAll('.dropdown-item');

    // Toggle Dropdown
    trigger.addEventListener('click', function(e) {
        e.preventDefault();
        const isOpen = !menu.classList.contains('hidden');
        
        if (isOpen) {
            closeDropdown();
        } else {
            openDropdown();
        }
    });

    // Handle Item Selection
    items.forEach(item => {
        item.addEventListener('click', function() {
            // Update hidden input value for PHP
            hiddenInput.value = this.getAttribute('data-value');
            
            // Update the text on the trigger
            selectedText.textContent = this.innerText;
            selectedText.classList.remove('text-gray-500', 'dark:text-gray-400');
            selectedText.classList.add('text-slate-900', 'dark:text-white');

            // Reset all checks
            document.querySelectorAll('.check-icon').forEach(icon => icon.classList.add('opacity-0'));
            // Show check on selected
            this.querySelector('.check-icon').classList.remove('opacity-0');

            // Close the menu
            closeDropdown();
        });
    });

    // Close when clicking outside
    document.addEventListener('click', function(e) {
        if (!trigger.contains(e.target) && !menu.contains(e.target)) {
            closeDropdown();
        }
    });

    function openDropdown() {
        menu.classList.remove('hidden');
        // Small delay to allow display:block to apply before animation
        setTimeout(() => {
            menu.classList.remove('opacity-0', 'translate-y-[-10px]');
            icon.classList.add('rotate-180');
        }, 10);
    }

    function closeDropdown() {
        menu.classList.add('opacity-0', 'translate-y-[-10px]');
        icon.classList.remove('rotate-180');
        setTimeout(() => {
            menu.classList.add('hidden');
        }, 300); // match the duration-300 class
    }
});

/*
|--------------------------------------------------------------------------
| Priority Custom Dropdown
|--------------------------------------------------------------------------
*/

document.addEventListener('DOMContentLoaded', function () {

    const priorityTrigger =
        document.getElementById('priority-trigger');

    const priorityMenu =
        document.getElementById('priority-menu');

    const prioritySelectedText =
        document.getElementById('priority-selected-text');

    const priorityInput =
        document.getElementById('priority');

    const priorityIcon =
        document.getElementById('priority-icon');

    const priorityItems =
        document.querySelectorAll('.priority-item');


    // -------------------------------------------------
    // Open / Close Priority Dropdown
    // -------------------------------------------------

    priorityTrigger.addEventListener('click', function (e) {

        e.preventDefault();

        const isOpen =
            !priorityMenu.classList.contains('hidden');

        if (isOpen) {

            closePriorityDropdown();

        } else {

            openPriorityDropdown();

        }

    });


    // -------------------------------------------------
    // Select Priority
    // -------------------------------------------------

    priorityItems.forEach(function (item) {

        item.addEventListener('click', function () {

            const value =
                this.getAttribute('data-value');


            // Send selected value to PHP
            priorityInput.value = value;


            // Get the text + dot
            const selectedContent =
                this.querySelector('span.flex').innerHTML;


            prioritySelectedText.innerHTML =
                selectedContent;


            // Remove all check marks
            priorityItems.forEach(function (option) {

                const check =
                    option.querySelector('.check-icon');

                check.classList.add('opacity-0');

            });


            // Show selected check mark
            this.querySelector('.check-icon')
                .classList.remove('opacity-0');


            // Close dropdown
            closePriorityDropdown();

        });

    });


    // -------------------------------------------------
    // Close When Clicking Outside
    // -------------------------------------------------

    document.addEventListener('click', function (e) {

        const container =
            document.getElementById(
                'priority-dropdown-container'
            );

        if (
            !container.contains(e.target)
        ) {

            closePriorityDropdown();

        }

    });


    // -------------------------------------------------
    // Open Animation
    // -------------------------------------------------

    function openPriorityDropdown() {

        priorityMenu.classList.remove('hidden');

        setTimeout(function () {

            priorityMenu.classList.remove(
                'opacity-0',
                'translate-y-[-10px]'
            );

            priorityIcon.classList.add(
                'rotate-180'
            );

        }, 10);

    }


    // -------------------------------------------------
    // Close Animation
    // -------------------------------------------------

    function closePriorityDropdown() {

        priorityMenu.classList.add(
            'opacity-0',
            'translate-y-[-10px]'
        );

        priorityIcon.classList.remove(
            'rotate-180'
        );

        setTimeout(function () {

            priorityMenu.classList.add(
                'hidden'
            );

        }, 300);

    }

});
</script>

</body>
</html>
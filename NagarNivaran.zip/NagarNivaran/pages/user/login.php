<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once("../../includes/config.php");

// 🚨 ADD THIS: IF ALREADY LOGGED IN, BOUNCE THEM TO DASHBOARD 🚨
if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Official Citizen Login | JMC Access Pass</title>

    <link rel="icon" type="image/x-icon" href="<?= urlof('assets/imgs/nn-final.png')?>">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Courier+Prime:ital,wght@0,400;0,700;1,400&family=Hind+Vadodara:wght@500;600;700&family=IBM+Plex+Serif:wght@600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'civic-canvas': '#F4F7F9',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                    },
                    fontFamily: {
                        typewriter: ['"Courier Prime"', 'monospace'],
                        official: ['"IBM Plex Serif"', 'serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        gujarati: ['"Hind Vadodara"', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #F4F7F9; }
        ::-webkit-scrollbar-thumb { background: #FF9933; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #FF7A00; }

        /* Normal Orange Cross Pattern */
        .bg-cross-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }

        /* Slide down animation for the receipt */
        @keyframes slideDownOut {
            0% { transform: translateY(-100%); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }
        .animate-receipt {
            animation: slideDownOut 1.2s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }

        /* Clean inputs to match the image */
        input[type="text"], input[type="password"] {
            background: transparent !important;
            box-shadow: none !important;
        }
        input:focus {
            outline: none !important;
            box-shadow: none !important;
        }
    </style>
</head>
<body class="bg-civic-canvas text-slate-800 font-sans antialiased relative min-h-screen py-8 px-4 flex flex-col items-center justify-between selection:bg-orange-glow selection:text-white overflow-x-hidden">

    <!-- Orange Cross Pattern Background -->
    <div class="fixed inset-0 -z-20 bg-cross-pattern pointer-events-none"></div>
    <div class="fixed top-[-10%] left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-gradient-to-b from-orange-100/60 via-orange-50/20 to-transparent rounded-full blur-3xl pointer-events-none -z-10"></div>

    <!-- Top Navigation -->
    <div class="w-full max-w-[460px] mx-auto mb-6 sm:mb-10 flex justify-between items-center z-10 relative">
        <a href="../../index.php" class="bg-white/80 backdrop-blur-md px-4 py-2 rounded-full text-slate-700 hover:text-orange-glow text-sm font-bold shadow-sm flex items-center gap-2 transition-all hover:-translate-x-1 border border-white">
            <i class="fa-solid fa-arrow-left"></i> Return
        </a>
        <span class="bg-white/80 backdrop-blur-md text-slate-800 px-4 py-2 rounded-full text-sm font-bold shadow-sm border border-white flex items-center gap-2">
            <i class="fa-solid fa-arrow-right-to-bracket text-orange-glow"></i> Login
        </span>
    </div>

    <!-- MAIN UI: Printer & Receipt -->
    <div class="w-full max-w-[460px] mx-auto relative z-20 my-auto flex flex-col">
        
        <!-- The Printer Body (Stationary, Z-30, Hides the paper translating down) -->
        <div class="w-full bg-white rounded-t-[32px] pt-8 sm:pt-10 shadow-[0_15px_40px_rgba(0,0,0,0.12)] relative z-30 flex flex-col items-center border-b border-slate-100">
            
            <!-- Logo with Zoom Hover Effect -->
            <div class="w-[100px] h-[100px] sm:w-[110px] sm:h-[110px] rounded-full border-4 border-orange-glow bg-white overflow-hidden mb-4 shadow-md flex items-center justify-center group cursor-pointer">
                <img src="../../assets/imgs/nn-final.png" alt="JMC Logo" onerror="this.src='https://placehold.co/110x110/FF7A00/FFFFFF?text=NN'" class="w-full h-full object-cover group-hover:scale-125 transition-transform duration-500 ease-out">
            </div>
            
            <h1 class="font-heading text-3xl sm:text-4xl font-black text-slate-900 tracking-tight text-center leading-none">
                Nagar<span class="text-orange-glow">Nivaran</span>
            </h1>
            <p class="font-gujarati font-bold text-tomato text-sm sm:text-base mt-2 tracking-wide mb-6">
                નગરનિવારણ • નાગરિક પ્રવેશ
            </p>

            <!-- The Slot Hardware (Black box attached to the bottom of the printer) -->
            <div class="w-full sm:w-[104%] h-12 sm:h-14 bg-gradient-to-b from-[#3a3b42] to-[#1c1d22] sm:rounded-xl rounded-t-xl shadow-[0_15px_30px_rgba(0,0,0,0.4)] relative flex items-end justify-center pb-2.5 border border-[#4a4b52] z-30 -mb-[1px]">
                <!-- The deep black slit where paper comes out -->
                <div class="w-[94%] sm:w-[92%] h-3 sm:h-4 bg-[#050506] rounded-full shadow-[inset_0_10px_20px_rgba(0,0,0,1),inset_0_1px_2px_rgba(255,255,255,0.05)] relative flex items-center justify-center">
                    <div class="w-full h-[1px] bg-black/80 absolute top-1"></div>
                </div>
            </div>
        </div>

        <!-- The Paper Wrapper (Overflow hidden to mask the sliding animation) -->
        <div class="w-full relative z-10 -mt-6 pt-6 flex justify-center overflow-hidden drop-shadow-[0_20px_35px_rgba(0,0,0,0.1)]">
            
            <!-- The Paper Receipt -->
            <div class="w-[94%] sm:w-[90%] bg-white rounded-b-[32px] relative pt-8 pb-10 px-5 sm:px-8 animate-receipt">
                
                <!-- Receipt Header with Pill -->
                <div class="flex justify-between items-center mb-6 text-[11px] font-bold uppercase tracking-widest border-b-[2px] border-dashed border-slate-200 pb-5">
                    <span class="bg-slate-100 border border-slate-200 text-slate-600 px-3 sm:px-4 py-1.5 rounded-full shadow-sm text-[10px] sm:text-[11px]">
                        Citizen Panel Pass
                    </span>
                    <span class="text-emerald-600 bg-emerald-50 px-3 sm:px-4 py-1.5 rounded-full border border-emerald-100 shadow-sm text-[10px] sm:text-[11px] flex items-center gap-1.5">
                        <i class="fa-solid fa-shield-halved"></i> Secure
                    </span>
                </div>

                <!-- Note Style Text -->
                <p class="text-[11px] sm:text-[12px] text-slate-500 mb-8 sm:mb-10 font-mono bg-slate-50 p-3 border-l-4 border-orange-glow leading-relaxed text-left">
                    Enter your registered credentials below to authenticate and connect to Jamnagar's live civic grievance tracking grid.
                </p>

                <!-- Form Content -->
                <form id="loginForm" class="space-y-5">
                    
                    <!-- Citizen ID (Turns GREEN on hover/focus) -->
                    <div class="flex items-center justify-between p-3.5 border border-slate-100 rounded-2xl bg-slate-50/70 hover:bg-white hover:border-emerald-200 focus-within:bg-white focus-within:border-emerald-400 focus-within:shadow-[0_0_0_3px_rgba(52,211,153,0.15)] transition-all group">
                        <div class="flex items-center gap-4 w-full">
                            <div class="w-10 h-10 rounded-full bg-white shadow-sm border border-slate-200 flex items-center justify-center text-slate-400 group-hover:text-emerald-500 group-focus-within:text-emerald-500 group-focus-within:border-emerald-200 transition-colors shrink-0">
                                <i class="fa-regular fa-user text-lg"></i>
                            </div>
                            <div class="flex flex-col w-full">
                                <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest group-focus-within:text-emerald-600 transition-colors">Citizen ID</label>
                                <input type="text" id="login" name="login" required class="w-full text-slate-900 font-bold text-sm sm:text-base placeholder-slate-300 bg-transparent mt-0.5" placeholder="Mobile or Email">
                            </div>
                        </div>
                    </div>
                    <div id="loginError" class="text-red-500 text-xs font-bold px-2 -mt-3 min-h-[16px]"></div>

                    <!-- Passcode (Turns ORANGE on hover/focus) -->
                    <div class="flex items-center justify-between p-3.5 border border-slate-100 rounded-2xl bg-slate-50/70 hover:bg-white hover:border-orange-200 focus-within:bg-white focus-within:border-orange-400 focus-within:shadow-[0_0_0_3px_rgba(255,122,0,0.15)] transition-all group">
                        <div class="flex items-center gap-4 w-full">
                            <div class="w-10 h-10 rounded-full bg-white shadow-sm border border-slate-200 flex items-center justify-center text-slate-400 group-hover:text-orange-glow group-focus-within:text-orange-glow group-focus-within:border-orange-200 transition-colors shrink-0">
                                <i class="fa-solid fa-lock text-sm"></i>
                            </div>
                            <div class="flex flex-col w-full relative">
                                <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest group-focus-within:text-orange-600 transition-colors">Passcode</label>
                                <input type="password" id="password" name="password" required class="w-full text-slate-900 font-bold text-sm sm:text-base placeholder-slate-300 bg-transparent mt-0.5 tracking-[0.2em]" placeholder="••••••••">
                                <a href="#" class="absolute right-0 top-0 text-[10px] text-orange-glow hover:underline font-bold bg-white px-1 mt-0.5">Forgot?</a>
                            </div>
                        </div>
                    </div>
                    <div id="passwordError" class="text-red-500 text-xs font-bold px-2 -mt-3 min-h-[16px]"></div>

                    <!-- Footer Action Buttons -->
                    <div class="flex items-center justify-between gap-3 pt-2">
                        <a href="<?= urlof('pages/user/register.php') ?>" class="w-full py-4 bg-slate-50 hover:bg-slate-200 text-slate-700 text-center rounded-[16px] font-bold text-sm transition-colors border border-slate-200 shadow-sm">
                            Register
                        </a>
                        <input
                            type="button"
                            id="btnLogin"
                            value="Login"
                            class="w-full py-4 bg-orange-glow hover:bg-orange-600 text-white text-center rounded-[16px] font-bold text-sm shadow-md shadow-orange-500/30 cursor-pointer active:scale-[0.97] transition-all">
                    </div>

                <!-- Note Style Text -->
                <p class="text-[11px] sm:text-[12px] text-slate-500 mb-8 sm:mb-10 font-mono bg-slate-50 p-3 border-l-4 border-red-400 leading-relaxed text-left">
                    Don’t have an account? Click <b class="text-red-400">“Register”</b> to create your account and start reporting civic issues.
                </p>

                </form>

                <!-- Dashed Line separator -->
                <div class="border-b-[2px] border-dashed border-slate-200 w-full mt-8 mb-6"></div>

                <!-- Granted Stamp inside receipt -->
                <div class="w-full flex justify-center">
                    <div class="w-24 h-24 rounded-full border-[3px] border-emerald-500/40 flex flex-col items-center justify-center -rotate-[15deg] bg-emerald-50/50 shadow-inner">
                        <i class="fa-solid fa-building-columns text-emerald-600/70 text-2xl mb-1.5"></i>
                        <span class="font-official font-black text-[12px] text-emerald-700/90 tracking-widest uppercase leading-none">Granted</span>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Bottom Footer -->
    <footer class="w-full mt-8 mb-4 text-center text-[10px] sm:text-xs text-slate-400 font-bold tracking-wide z-10 space-y-1">
        <p class="uppercase">Jamnagar Municipal Corporation</p>
        <p class="font-normal opacity-70">NagarNivaran &copy; 2026</p>
    </footer>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
    let redirectUrl = "";

    function showSystemAlert(title, message, url) {
        redirectUrl = url; 
        document.getElementById('alert-title').innerText = title;
        document.getElementById('alert-message').innerText = message;
        const alertBox = document.getElementById('system-alert');
        const alertCard = document.getElementById('alert-card');

        alertBox.classList.remove('hidden');
        alertBox.classList.add('flex');
        
        setTimeout(() => {
            alertBox.classList.remove('opacity-0');
            alertCard.classList.remove('scale-95');
            alertCard.classList.add('scale-100');
        }, 10);
    }

    $("#login").on("keyup", function () {
        let value = $(this).val().trim();
        if (value == "") {
            $("#loginError").text("Login ID is required.");
        } else {
            $("#loginError").text("");
        }
    });

    $("#password").on("keyup", function () {
        let value = $(this).val();
        if (value.length < 6) {
            $("#passwordError").text("Password must be at least 6 characters.");
        } else {
            $("#passwordError").text("");
        }
    });

    $("#btnLogin").click(function(){
        let login = $("#login").val().trim();
        let password = $("#password").val();

        if(login==""){
            $("#loginError").text("Enter Mobile or Email.");
            return;
        }
        if(password==""){
            $("#passwordError").text("Enter Password.");
            return;
        }

        // Change button text to show loading state
        let btn = $(this);
        let originalText = btn.val();
        btn.val("Authenticating...").prop("disabled", true);

        // $.ajax({
        //     url:"../../api/user/login.php",
        //     type:"POST",
        //     data:{
        //         login:login,
        //         password:password
        //     },
        //     dataType:"json",
        //     success:function(response){
        //         console.log(response);
        //         if(response.success){
        //             alert(response.message);
        //             window.location.href = "dashboard.php";
        //         }else{
        //             alert(response.message);
        //             btn.val(originalText).prop("disabled", false);
        //         }
        //     },
        //     error:function(xhr){
        //         console.log("Status:", xhr.status);
        //         console.log("Response:", xhr.responseText);
        //         btn.val(originalText).prop("disabled", false);
        //     }
        // });

        $.ajax({
            url: "../../api/user/login.php",
            type: "POST",
            data: {
                login: login,
                password: password
            },
            dataType: "json",
            success: function(response) {
                console.log(response);
                if (response.success) {
                    // 🎉 SUCCESS ALERT (Glassmorphic)
                    Swal.fire({
                        title: '<div class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Access Granted!</div>',
                        html: '<div class="pt-2">' + response.message + '</div>',
                        showCloseButton: false,
                        confirmButtonText: 'Enter Dashboard',
                        buttonsStyling: false,
                        customClass: {
                            // Heavy glassmorphism background
                            popup: 'bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-white/50 dark:border-slate-700/50 rounded-3xl shadow-2xl p-6',
                            // Thin horizontal line under the header
                            header: 'border-b border-gray-200/50 dark:border-slate-700/50 pb-4 mb-2 w-full',
                            // Left-aligned title
                            title: 'font-heading font-black text-xl text-slate-900 dark:text-white w-full m-0 p-0 text-left',
                            // Settings-style 'X' close button
                            closeButton: 'text-gray-500 hover:text-red-500 bg-gray-100/80 dark:bg-slate-800/80 rounded-full w-8 h-8 flex items-center justify-center top-6 right-6 focus:outline-none transition-colors shadow-sm',
                            // Message formatting
                            htmlContainer: 'text-sm text-gray-600 dark:text-gray-300 font-medium leading-relaxed m-0 p-0 text-center',
                            // Full-width action button
                            actions: 'w-full mt-6',
                            confirmButton: 'w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-sm rounded-xl shadow-md shadow-emerald-500/30 transition-all active:scale-95'
                        }
                    }).then(() => {
                        window.location.href = "dashboard.php";
                    });
                } else {
                    // ❌ ERROR ALERT (Glassmorphic)
                    Swal.fire({
                        title: '<div class="flex items-center"><i class="fa-solid fa-triangle-exclamation text-orange-glow mr-2"></i> Attention!</div>',
                        html: '<div class="pt-2">' + response.message + '</div>',
                        showCloseButton: false,
                        confirmButtonText: 'Try Again',
                        buttonsStyling: false,
                        customClass: {
                            popup: 'bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-white/50 dark:border-slate-700/50 rounded-3xl shadow-2xl p-6',
                            header: 'border-b border-gray-200/50 dark:border-slate-700/50 pb-4 mb-2 w-full',
                            title: 'font-heading font-black text-xl text-slate-900 dark:text-white w-full m-0 p-0 text-left',
                            closeButton: 'text-gray-500 hover:text-red-500 bg-gray-100/80 dark:bg-slate-800/80 rounded-full w-8 h-8 flex items-center justify-center top-6 right-6 focus:outline-none transition-colors shadow-sm',
                            htmlContainer: 'text-sm text-gray-600 dark:text-gray-300 font-medium leading-relaxed m-0 p-0 text-center',
                            actions: 'w-full mt-6',
                            confirmButton: 'w-full py-3.5 bg-orange-glow hover:bg-orange-600 text-white font-bold text-sm rounded-xl shadow-md shadow-orange-500/30 transition-all active:scale-95'
                        }
                    });
                    btn.val(originalText).prop("disabled", false);
                }
            },
            error: function(xhr) {
                console.log("Status:", xhr.status);
                console.log("Response:", xhr.responseText);
                // ⚠️ SERVER ERROR ALERT (Glassmorphic)
                Swal.fire({
                    title: '<div class="flex items-center"><i class="fa-solid fa-server text-red-500 mr-2"></i> Server Error!</div>',
                    html: '<div class="pt-2">Could not connect to the authentication server.</div>',
                    showCloseButton: false,
                    confirmButtonText: 'Dismiss',
                    buttonsStyling: false,
                    customClass: {
                        popup: 'bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-white/50 dark:border-slate-700/50 rounded-3xl shadow-2xl p-6',
                        header: 'border-b border-gray-200/50 dark:border-slate-700/50 pb-4 mb-2 w-full',
                        title: 'font-heading font-black text-xl text-slate-900 dark:text-white w-full m-0 p-0 text-left',
                        closeButton: 'text-gray-500 hover:text-red-500 bg-gray-100/80 dark:bg-slate-800/80 rounded-full w-8 h-8 flex items-center justify-center top-6 right-6 focus:outline-none transition-colors shadow-sm',
                        htmlContainer: 'text-sm text-gray-600 dark:text-gray-300 font-medium leading-relaxed m-0 p-0 text-center',
                        actions: 'w-full mt-6',
                        confirmButton: 'w-full py-3.5 bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 text-white font-bold text-sm rounded-xl shadow-md transition-all active:scale-95'
                    }
                });
                btn.val(originalText).prop("disabled", false);
            }
        });
    });
</script>
</body>
</html>
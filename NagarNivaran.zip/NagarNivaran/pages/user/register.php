<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once("../../includes/config.php");

// 🚨 ADD THIS: IF ALREADY LOGGED IN, BOUNCE THEM TO DASHBOARD 🚨
if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formal Citizen Registration | JMC Registry</title>

    <link rel="icon" type="image/x-icon" href="<?= urlof('assets/imgs/nn-final.png')?>">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Courier+Prime:ital,wght@0,400;0,700;1,400&family=Hind+Vadodara:wght@500;600;700&family=IBM+Plex+Serif:wght@600;700&family=Plus+Jakarta+Sans:wght@600;700&display=swap" rel="stylesheet">

    <?php if (!empty($alert_message)): ?>
    <script>
        window.onload = function() {
            alert("<?php echo addslashes($alert_message); ?>");
        };
    </script>
    <?php endif; ?>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'desk': '#F4F7F9', /* Updated to match new cross background canvas */
                        'paper': '#FFFFFF', 
                        'ink': '#0F172A', 
                        'saffron': '#FF9933',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                    },
                    fontFamily: {
                        typewriter: ['"Courier Prime"', 'monospace'],
                        official: ['"IBM Plex Serif"', 'serif'],
                        typed: ['"Plus Jakarta Sans"', 'sans-serif'],
                        gujarati: ['"Hind Vadodara"', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <style>
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #F4F7F9; }
        ::-webkit-scrollbar-thumb { background: #FF7A00; border-radius: 4px; }

        /* Normal Orange Cross Pattern */
        .bg-cross-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }

        /* Typewriter Ink Underline Inputs */
        input[type="text"], input[type="email"], input[type="tel"], input[type="password"], select {
            background: transparent !important;
            border-top: 0 !important;
            border-left: 0 !important;
            border-right: 0 !important;
            border-radius: 0 !important;
            box-shadow: none !important;
        }
        input:focus, select:focus {
            outline: none !important;
            box-shadow: none !important;
        }

        /* Physical Print Checkbox */
        input[type="checkbox"] {
            appearance: none;
            background-color: #FFFFFF;
            margin: 0;
            font: inherit;
            color: #FF6347;
            width: 1.15em;
            height: 1.15em;
            border: 2px solid #0F172A;
            display: grid;
            place-content: center;
            cursor: pointer;
        }
        input[type="checkbox"]::before {
            content: "✔";
            transform: scale(0);
            font-weight: 900;
            font-size: 12px;
        }
        input[type="checkbox"]:checked::before {
            transform: scale(1);
        }
    </style>
</head>
<body class="bg-desk text-ink font-typewriter antialiased relative min-h-screen py-8 sm:py-12 px-4 sm:px-6 flex flex-col items-center justify-between selection:bg-saffron selection:text-ink overflow-x-hidden">

    <div class="fixed inset-0 -z-20 bg-cross-pattern pointer-events-none"></div>
    <div class="fixed top-[-10%] left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-gradient-to-b from-orange-100/60 via-orange-50/20 to-transparent rounded-full blur-3xl pointer-events-none -z-10"></div>

    <div class="w-full max-w-3xl mb-5 flex flex-col sm:flex-row justify-between items-center text-slate-600 text-xs px-2 font-bold gap-3 sm:gap-0">
        <a href="<?= urlof('index.php') ?>" class="hover:text-orange-glow flex items-center gap-2 transition-colors bg-white/80 sm:bg-transparent backdrop-blur-sm sm:backdrop-blur-none px-4 py-2 sm:px-0 sm:py-0 rounded-full border border-white/50 sm:border-none shadow-sm sm:shadow-none">
            <i class="fa-solid fa-arrow-left"></i> Return to Portal Desk
        </a>
        <span class="text-[10px] sm:text-[11px] font-mono tracking-widest text-tomato uppercase bg-white/80 sm:bg-transparent px-4 py-2 sm:px-0 sm:py-0 rounded-full shadow-sm sm:shadow-none border border-white/50 sm:border-none">Secure SSL Portal</span>
    </div>

    <div class="max-w-3xl w-full bg-paper text-ink shadow-[0_20px_50px_rgba(15,23,42,0.13)] border border-slate-300 rounded-[2px] p-5 sm:p-14 relative overflow-hidden my-auto">
        
        <div class="hidden sm:flex absolute right-[-40px] bottom-[120px] border-4 border-red-500/10 rounded-full w-64 h-64 items-center justify-center pointer-events-none select-none -rotate-12 z-0">
            <span class="font-official font-bold text-red-500/10 text-2xl tracking-widest uppercase text-center border-y-2 border-red-500/10 py-1">Jamnagar Corp<br>Official Copy</span>
        </div>

        <div class="flex flex-col sm:flex-row justify-between items-center border-b-2 border-ink/20 pb-2 mb-8 text-[11px] font-mono gap-2 sm:gap-0 text-center sm:text-left">
            <span class="font-bold text-ink tracking-widest">ORIGINAL IN DUPLICATE</span>
            <span class="text-tomato font-bold tracking-widest bg-red-50 sm:bg-transparent px-3 py-1 sm:p-0 rounded border border-red-100 sm:border-none">[ CITIZEN COPY ]</span>
        </div>

        <div class="text-center space-y-2 relative z-10">
            <img src="../../assets/imgs/nn-final.png" alt="Logo" onerror="this.src='https://placehold.co/80x80/FF7A00/000?text=JMC'" class="w-16 h-16 sm:w-20 sm:h-20 rounded-full mx-auto border-4 border-orange-glow object-cover">
            
            <h1 class="font-official font-bold text-xl sm:text-3xl tracking-tight text-ink uppercase leading-tight">
                Jamnagar Municipal Corporation
            </h1>
            <p class="font-gujarati font-bold text-sm sm:text-lg text-tomato tracking-wide">
                નગરનિવારણ • નાગરિક નોંધણી પત્રક
            </p>
            <p class="text-[10px] sm:text-[11px] uppercase tracking-widest bg-ink text-paper py-1 px-4 inline-block font-bold mt-2">
                Application For Citizen Auditor ID
            </p>
        </div>

        <div class="border-t-2 border-b border-ink h-1.5 my-6 sm:my-8"></div>

        <p class="text-[10px] sm:text-[11px] italic text-slate-600 mb-8 bg-amber-500/10 p-3 sm:p-4 border-l-2 border-saffron leading-relaxed text-justify sm:text-left">
            <b>Note to Citizen:</b> Please type details accurately. Information provided will be verified against Jamnagar Municipal SCADA records for account authorization.
        </p>

        <form id="registerForm" enctype="multipart/form-data" class="space-y-10 relative z-10">

            <div>
                <div class="bg-slate-100 px-3 py-1.5 font-bold text-[10px] sm:text-xs uppercase tracking-wider border-l-4 border-ink mb-6">
                    Part I: Personal Particulars
                </div>

                <div class="flex flex-col-reverse sm:grid sm:grid-cols-12 gap-6 sm:gap-6 items-start">
                    
                    <div class="sm:col-span-8 space-y-6 w-full mt-6 sm:mt-0">
                        
                        <div class="relative flex flex-col">
                            <label class="text-[10px] sm:text-[11px] font-bold uppercase tracking-tight text-slate-700">1. Full Name of Applicant (In Block Letters) <span class="text-tomato">*</span></label>
                            <input type="text" id="full_name" name="full_name" required class="w-full border-b-[2px] border-ink py-1.5 text-slate-950 font-typed font-bold text-sm sm:text-base focus:border-orange-glow transition-colors uppercase" placeholder="e.g. PRATIK M. DESANI">
                        </div>

                        <div class="relative flex flex-col">
                            <label class="text-[10px] sm:text-[11px] font-bold uppercase tracking-tight text-slate-700">2. Mobile Number (Linked with OTP) <span class="text-tomato">*</span></label>
                            <div class="flex items-end w-full">
                                <span class="border-b-[2px] border-ink py-1.5 font-typed font-bold text-sm sm:text-base pr-2 text-slate-400">+91</span>
                                <input type="tel" id="mobile" name="mobile" required maxlength="10" class="w-full border-b-[2px] border-ink py-1.5 text-slate-950 font-typed font-bold text-sm sm:text-base focus:border-orange-glow transition-colors tracking-widest font-mono" placeholder="9876543210">
                            </div>
                        </div>

                        <div class="relative flex flex-col">
                            <label class="text-[10px] sm:text-[11px] font-bold uppercase tracking-tight text-slate-700">3. Electronic Mail Address <span class="text-tomato">*</span></label>
                            <input type="email" id="email" name="email" required class="w-full border-b-[2px] border-ink py-1.5 text-slate-950 font-typed font-bold text-sm focus:border-orange-glow transition-colors lowercase" placeholder="citizen@jamnagar.guj.in">
                        </div>

                    </div>

                    <div class="sm:col-span-4 flex flex-col items-center justify-center w-full">
                        <label class="text-[10px] font-bold uppercase tracking-tight text-slate-400 mb-2 sm:mb-1 text-center">Photograph Slot</label>
                        <div id="photo-preview-box" onclick="document.getElementById('profile-photo').click()" class="w-32 h-40 border-2 border-dashed border-ink bg-slate-50 p-3 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-orange-50/60 hover:border-orange-glow transition shadow-inner relative overflow-hidden group mx-auto">
                            <div id="photo-prompt">
                                <i class="fa-solid fa-paperclip text-slate-400 text-lg mb-1 group-hover:text-orange-glow transition-colors"></i>
                                <span class="block text-[9px] font-bold leading-tight text-slate-600 uppercase">Affix 3.5 x 4.5 cm Passport Size Photograph</span>
                                <span class="text-[8px] text-tomato font-mono block mt-2 underline">[Click to Glue]</span>
                            </div>
                            <input type="file" name="photo" id="profile-photo" accept="image/*" class="hidden" onchange="gluePhoto(this)">
                        </div>
                    </div>

                </div>
            </div>

            <div>
                <div class="bg-slate-100 px-3 py-1.5 font-bold text-[10px] sm:text-xs uppercase tracking-wider border-l-4 border-ink mb-6">
                    Part II: Jamnagar Residential Jurisdiction
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-12 gap-6">
                    
                    <div class="sm:col-span-4 relative flex flex-col w-full">
                        <label class="text-[10px] sm:text-[11px] font-bold uppercase tracking-tight text-slate-700">4. Flat / House No.</label>
                        <input type="text" id="house_no" name="house_no" class="w-full border-b-[2px] border-ink py-1.5 text-slate-950 font-typed font-bold text-sm focus:border-orange-glow transition-colors" placeholder="e.g. B-102">
                    </div>

                    <div class="sm:col-span-8 relative flex flex-col w-full">
                        <label class="text-[10px] sm:text-[11px] font-bold uppercase tracking-tight text-slate-700">5. Street / Society / Area Name <span class="text-tomato">*</span></label>
                        <input type="text" id="area" name="area" required class="w-full border-b-[2px] border-ink py-1.5 text-slate-950 font-typed font-bold text-sm focus:border-orange-glow transition-colors uppercase" placeholder="e.g. PATEL COLONY, ROAD NO 3">
                    </div>

                    <div class="sm:col-span-6 relative flex flex-col w-full">
                        <label class="text-[10px] sm:text-[11px] font-bold uppercase tracking-tight text-slate-700">6. Municipal Ward No. <span class="text-tomato">*</span></label>
                        <select id="ward" name="ward" required class="w-full border-b-[2px] border-ink py-2 text-slate-950 font-typed font-bold text-xs sm:text-sm focus:border-orange-glow transition-colors cursor-pointer bg-transparent appearance-none">
                            <option value="" disabled selected>-- Select Ward District --</option>
                            <option value="Ward No. 1">Ward No. 1: Bedi</option>
                            <option value="Ward No. 2">Ward No. 2: Rameshwarnagar</option>
                            <option value="Ward No. 3">Ward No. 3: Patel Colony</option>
                            <option value="Ward No. 4">Ward No. 4: Nawagam Ghed</option>
                            <option value="Ward No. 5">Ward No. 5: Park Colony</option>
                            <option value="Ward No. 6">Ward No. 6: Digjam Colony</option>
                            <option value="Ward No. 7">Ward No. 7: Ranjitnagar</option>
                            <option value="Ward No. 8">Ward No. 8: Mehulnagar</option>
                            <option value="Ward No. 9">Ward No. 9: Chandi Bazar</option>
                            <option value="Ward No. 10">Ward No. 10: Bhoi no Dhalio</option>
                            <option value="Ward No. 11">Ward No. 11: Gulabnagar</option>
                            <option value="Ward No. 12">Ward No. 12: Pattaniwad</option>
                            <option value="Ward No. 13">Ward No. 13: Havai Chowk</option>
                            <option value="Ward No. 14">Ward No. 14: Digvijay Plot</option>
                            <option value="Ward No. 15">Ward No. 15: Sadhana Colony & Mayur Township</option>
                            <option value="Ward No. 16">Ward No. 16: Ranjitsagar Road & New Patel Park</option>
                        </select>
                    </div>

                    <div class="sm:col-span-6 relative flex flex-col w-full">
                        <label class="text-[10px] sm:text-[11px] font-bold uppercase tracking-tight text-slate-700">7. Jamnagar PIN Code <span class="text-tomato">*</span></label>
                        <input type="text" id="pincode" name="pincode" required maxlength="6" class="w-full border-b-[2px] border-ink py-1.5 text-slate-950 font-typed font-bold text-sm focus:border-orange-glow tracking-widest font-mono" placeholder="361001">
                    </div>

                </div>
            </div>

            <div>
                <div class="bg-slate-100 px-3 py-1.5 font-bold text-[10px] sm:text-xs uppercase tracking-wider border-l-4 border-ink mb-6">
                    Part III: Dispatch Access Credentials
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full">
                    <div class="relative flex flex-col w-full">
                        <label class="text-[10px] sm:text-[11px] font-bold uppercase tracking-tight text-slate-700">8. Create Access Password <span class="text-tomato">*</span></label>
                        <input type="password" id="password" name="password" required class="w-full border-b-[2px] border-ink py-1.5 text-slate-950 font-typed font-bold text-base focus:border-orange-glow tracking-widest" placeholder="••••••••">
                    </div>

                    <div class="relative flex flex-col w-full">
                        <label class="text-[10px] sm:text-[11px] font-bold uppercase tracking-tight text-slate-700">9. Confirm Access Password <span class="text-tomato">*</span></label>
                        <input type="password" id="confirm_password" name="confirm_password" required class="w-full border-b-[2px] border-ink py-1.5 text-slate-950 font-typed font-bold text-base focus:border-orange-glow tracking-widest" placeholder="••••••••">
                    </div>
                </div>
            </div>

            <div class="pt-2">
                <div class="bg-slate-100 px-3 py-1.5 font-bold text-[10px] sm:text-xs uppercase tracking-wider border-l-4 border-ink mb-4">
                    Part IV: Declaration By Applicant
                </div>

                <p class="font-gujarati text-[11px] sm:text-xs leading-relaxed text-slate-800 mb-6 bg-slate-50 p-4 border border-slate-300 text-justify">
                    "(હું) આથી સોગંદપૂર્વક જાહેર કરું છું કે ઉપર આપેલી તમામ વિગતો મારી જાણ મુજબ સાચી છે. જો કોઈ માહિતી ખોટી સાબિત થશે, તો જામનગર મહાનગરપાલિકા મારું ખાતું રદ કરવા માટે હકદાર રહેશે."
                </p>

                <div class="space-y-4 pl-1">
                    <label class="flex items-start sm:items-center gap-3 cursor-pointer group select-none">
                        <input type="checkbox" required class="mt-0.5 sm:mt-0 shrink-0">
                        <span class="text-[11px] sm:text-xs text-slate-800 group-hover:text-tomato font-bold leading-tight">
                            I agree to the Municipal Terms of Grievance Dispatch.
                        </span>
                    </label>
                    
                    <label class="flex items-start sm:items-center gap-3 cursor-pointer group select-none">
                        <input type="checkbox" required class="mt-0.5 sm:mt-0 shrink-0">
                        <span class="text-[11px] sm:text-xs text-slate-800 group-hover:text-tomato font-bold leading-tight">
                            I consent to GIS geo-location tagging on uploaded civic photo audits.
                        </span>
                    </label>

                    <label class="flex items-start sm:items-center gap-3 cursor-pointer group select-none">
                        <input type="checkbox" required class="mt-0.5 sm:mt-0 shrink-0 w-4 h-4 cursor-pointer accent-orange-glow">
                        <span class="text-[11px] sm:text-xs text-slate-800 group-hover:text-tomato transition-colors duration-300 font-bold leading-tight">
                            By registering, you agree to our 
                            <a href="<?= urlof('templates/privacy.php') ?>" class="underline hover:text-indigo-600 hover:decoration-indigo-600 transition-colors duration-300">Privacy Policy</a> 
                            and 
                            <a href="<?= urlof('templates/T&C.php') ?>" class="underline hover:text-indigo-600 hover:decoration-indigo-600 transition-colors duration-300">Terms & Conditions</a>.
                        </span>
                    </label>
                </div>
            </div>

            <div class="pt-8 border-t border-ink/30 flex flex-col sm:flex-row items-center justify-between gap-6 w-full">
                <div class="text-[9px] sm:text-[10px] text-slate-400 font-mono text-center sm:text-left w-full sm:w-auto order-2 sm:order-1">
                    <span class="block mb-0.5">STATUS: UNVERIFIED APPLICATION</span>
                    <span class="block">JURISDICTION: GUJARAT STATE</span>
                </div>

                <input
                    type="button"
                    id="btnRegister"
                    value="[ Submit Application ]"
                    class="w-full sm:w-auto px-6 sm:px-10 py-4 bg-ink hover:bg-gradient-to-r hover:from-saffron hover:via-orange-glow hover:to-tomato text-paper hover:text-white font-official font-bold text-xs sm:text-sm tracking-widest uppercase shadow-[4px_4px_0px_#FF6347] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all border-2 border-ink cursor-pointer active:scale-95 order-1 sm:order-2">
            </div>

        </form>

        <div class="mt-10 sm:mt-12 pt-6 border-t-2 border-ink flex flex-col sm:flex-row justify-between items-center text-[10px] text-slate-400 font-mono gap-4 sm:gap-0">
            <span>SHEET 1 OF 1</span>
            <a href="<?= urlof('pages/user/login.php') ?>" class="text-orange-glow font-bold hover:underline bg-orange-50 sm:bg-transparent px-4 py-2 sm:p-0 rounded border border-orange-100 sm:border-none">Already Registered? Login to Registry</a>
        </div>

    </div>

    <footer class="w-full max-w-3xl mt-6 mb-4 text-center text-[10px] sm:text-[11px] text-slate-500 font-mono space-y-1">
        <p>JAMNAGAR MUNICIPAL CORPORATION &bull; NAGARNIVARAN SERVER</p>
        <p class="text-slate-400">&copy; 2026 Government of Gujarat. Formal Digital Interface Engine.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script>

        $(document).ready(function () {

    const fields = {
        full_name: {test: v => /^[A-Za-z][A-Za-z .'-]{2,49}$/.test(v), msg: "Enter a valid full name (letters only)."},
        mobile: {test: v => /^[6-9]\d{9}$/.test(v), msg: "Enter a valid 10-digit mobile number."},
        email: {test: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v), msg: "Enter a valid email address."},
        area: {test: v => v.length >= 3 && /^[A-Za-z0-9][A-Za-z0-9 .,'/#()&-]{2,99}$/.test(v), msg: "Enter a valid area or society name."},
        pincode: {test: v => /^3[0-9]{5}$/.test(v), msg: "Enter a valid 6-digit Jamnagar PIN code."},
        password: {test: v => /^(?=.*[A-Za-z])(?=.*\d)(?=.*[^A-Za-z0-9]).{6,}$/.test(v), msg: "Password must be at least 6 characters with a letter, number, and special character."},
        confirm_password: {test: v => v === $("#password").val() && v !== "", msg: "Passwords do not match."}
    };
    function validateField(id) {
        const el = $("#" + id), value = el.val().trim(), rule = fields[id];
        const valid = rule.test(value);
        el.attr("aria-invalid", !valid).toggleClass("border-red-500", !valid).toggleClass("border-ink", valid);
        el.next(".live-error").remove();
        if (!valid) el.after('<small class="live-error text-red-500 text-[10px] font-bold mt-1">' + rule.msg + '</small>');
        return valid;
    }
    Object.keys(fields).forEach(id => $("#" + id).on("input blur", () => validateField(id)));
    $("#ward").on("change", function () { $(this).toggleClass("border-red-500", !this.value).toggleClass("border-ink", !!this.value); });
    $("#profile-photo").on("change", function () {
        const file = this.files[0];
        if (file && (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size > 5 * 1024 * 1024)) {
            alert("Photo must be JPG, PNG, or WEBP and maximum 5 MB.");
            this.value = "";
        }
    });
    $("#btnRegister").click(function () {
        let valid = Object.keys(fields).every(validateField);
        if (!$("#ward").val()) { $("#ward").addClass("border-red-500"); valid = false; } else $("#ward").removeClass("border-red-500");
        if ($('input[type="checkbox"][required]:checked').length !== 3) valid = false;
        if (!valid) { alert("Please correct the highlighted fields before submitting."); return; }

        var formData = new FormData();

        formData.append("full_name", $("#full_name").val().trim());
        formData.append("mobile", $("#mobile").val().trim());
        formData.append("email", $("#email").val().trim());
        formData.append("house_no", $("#house_no").val().trim());
        formData.append("area", $("#area").val().trim());
        formData.append("ward", $("#ward").val());
        formData.append("pincode", $("#pincode").val().trim());
        formData.append("password", $("#password").val());
        formData.append("confirm_password", $("#confirm_password").val());

        formData.append("photo", $("#profile-photo")[0].files[0]);

        // Disable button during process
        let btn = $(this);
        let originalText = btn.val();
        btn.val("[ Processing... ]").prop('disabled', true);

        $.ajax({

            url: "../../api/user/register.php",

            type: "POST",

            data: formData,

            processData: false,

            contentType: false,

            dataType: "json",

            success: function (response) {

                if (response.success) {

                    alert(response.message);

                    window.location.href = "login.php";

                } else {

                    alert(response.message);
                    btn.val(originalText).prop('disabled', false);

                }

            },

            error:function(xhr){

                console.log(xhr.responseText);

                alert("Server Error");
                btn.val(originalText).prop('disabled', false);

            }

        });

    });

});

        function gluePhoto(input) {
            const previewBox = document.getElementById('photo-preview-box');
            const promptText = document.getElementById('photo-prompt');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewBox.style.backgroundImage = `url('${e.target.result}')`;
                    previewBox.style.backgroundSize = 'cover';
                    previewBox.style.backgroundPosition = 'center';
                    previewBox.style.borderStyle = 'solid';
                    previewBox.style.borderColor = '#FF7A00';
                    promptText.style.display = 'none';
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>
</html>
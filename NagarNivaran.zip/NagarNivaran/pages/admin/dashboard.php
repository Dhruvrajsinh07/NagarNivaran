<?php include '../../api/admin/dashboard.php'; ?>
<!DOCTYPE html>
<html lang="en" class="transition-all duration-300">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | NagarNivaran</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet">

    <script>
        if (localStorage.getItem('theme') === 'dark') {
            document.documentElement.classList.add('dark');
        }
        const savedSize = localStorage.getItem('textSize');
        if (savedSize) {
            document.documentElement.style.fontSize = savedSize + 'px';
        }
    </script>

    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        'saffron': '#FF9933',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                        'dark-base': '#0F172A',
                        'dark-surface': '#1E293B',
                        'dark-border': '#334155',
                    },
                    fontFamily: {
                        sans: ['"Inter"', 'sans-serif'],
                        display: ['"Plus Jakarta Sans"', 'sans-serif'],
                    },
                    boxShadow: {
                        'saas': '0 4px 20px -2px rgba(0, 0, 0, 0.05)',
                        'saas-lg': '0 10px 25px -5px rgba(0, 0, 0, 0.08)',
                        'neon': '0 4px 20px -2px rgba(255, 122, 0, 0.4)',
                    }
                }
            }
        }
    </script>
    <style>
        /* Smooth base transitions */
        html { transition: font-size 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        body * { transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease; }

        
        /* Soft transition for tabs */
        .tab-section { animation: fadeSlideIn 0.4s ease-out forwards; }
        @keyframes fadeSlideIn {
            0% { opacity: 0; transform: translateY(15px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        /* Flash hover effect */
        .btn-flash { position: relative; overflow: hidden; z-index: 1; }
        .btn-flash::after {
            content: ''; position: absolute; top: 50%; left: 50%; width: 0; height: 0;
            background: rgba(255, 255, 255, 0.25); border-radius: 50%; transform: translate(-50%, -50%);
            transition: width 0.4s ease-out, height 0.4s ease-out, opacity 0.4s ease-out; opacity: 0; z-index: -1;
        }
        .btn-flash:hover::after { width: 300%; height: 300%; opacity: 1; }

        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 10px; }
        .dark ::-webkit-scrollbar-thumb { background: #475569; }
        ::-webkit-scrollbar-thumb:hover { background: #FF7A00; }
    </style>
</head>

<body class="bg-slate-50 dark:bg-dark-base text-slate-800 dark:text-gray-200 font-sans min-h-screen flex antialiased selection:bg-orange-glow selection:text-white">
    
    <?php if(!empty($alert_message)): ?>
        <script>alert("<?= addslashes($alert_message) ?>");</script>
    <?php endif; ?>

    <div id="mobile-overlay" onclick="toggleSidebar()" class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-40 hidden lg:hidden opacity-0 transition-opacity duration-300"></div>

    <aside id="sidebar" class="w-[280px] bg-white dark:bg-dark-surface border-r border-slate-200 dark:border-dark-border fixed inset-y-0 left-0 z-50 flex flex-col shadow-2xl rounded-r-[30px] my-2 h-[calc(100vh-16px)] transform -translate-x-full lg:translate-x-0 transition-transform duration-300">
        <div class="pt-8 pb-5 flex flex-col items-center justify-center border-b border-slate-100 dark:border-dark-border mx-auto w-full relative">
            <button onclick="toggleSidebar()" class="absolute top-4 right-4 lg:hidden text-slate-400 hover:text-tomato"><i class="fa-solid fa-xmark text-xl"></i></button>
            <div class="w-[100px] h-[100px] rounded-full border-4 border-orange-glow/20 bg-white dark:bg-dark-base p-1 mb-3 flex items-center justify-center overflow-hidden shadow-lg hover:scale-105 transition-transform duration-500">
                <img src="<?= urlof('assets/imgs/nn-final.png') ?>" onerror="this.src='https://placehold.co/100x100/FF7A00/FFF?text=NN'" class="w-full h-full object-cover rounded-full">
            </div>
            <h1 class="font-display font-bold text-xl text-slate-900 dark:text-white tracking-tight">NagarNivaran</h1>
            <p class="text-[10px] font-bold text-orange-glow uppercase tracking-widest mt-1">Control Center</p>
        </div>

        <div class="flex-1 overflow-y-auto py-5 px-3 space-y-2">
            <button onclick="switchTab('overview')" id="tab-overview" class="btn-flash tab-btn w-full flex items-center gap-3.5 px-4 py-3 text-sm font-semibold rounded-2xl bg-orange-50 dark:bg-dark-base text-orange-glow border-l-4 border-orange-glow shadow-sm transition-all">
                <i class="fa-solid fa-chart-pie w-5 text-center"></i> Dashboard
            </button>
            <button onclick="switchTab('dispatch')" id="tab-dispatch" class="btn-flash tab-btn w-full flex items-center gap-3.5 px-4 py-3 text-sm font-semibold rounded-2xl text-slate-500 dark:text-gray-400 hover:bg-slate-50 dark:hover:bg-dark-base hover:text-slate-900 dark:hover:text-white border-l-4 border-transparent transition-all">
                <i class="fa-solid fa-paper-plane w-5 text-center"></i> Dispatch Desk
            </button>
            <button onclick="switchTab('officers')" id="tab-officers" class="btn-flash tab-btn w-full flex items-center gap-3.5 px-4 py-3 text-sm font-semibold rounded-2xl text-slate-500 dark:text-gray-400 hover:bg-slate-50 dark:hover:bg-dark-base hover:text-slate-900 dark:hover:text-white border-l-4 border-transparent transition-all">
                <i class="fa-solid fa-shield-halved w-5 text-center"></i> Manage Officers
            </button>
            <button onclick="switchTab('departments')" id="tab-departments" class="btn-flash tab-btn w-full flex items-center gap-3.5 px-4 py-3 text-sm font-semibold rounded-2xl text-slate-500 dark:text-gray-400 hover:bg-slate-50 dark:hover:bg-dark-base hover:text-slate-900 dark:hover:text-white border-l-4 border-transparent transition-all">
                <i class="fa-solid fa-building-flag w-5 text-center"></i> Departments
            </button>
            <button onclick="switchTab('users')" id="tab-users" class="btn-flash tab-btn w-full flex items-center gap-3.5 px-4 py-3 text-sm font-semibold rounded-2xl text-slate-500 dark:text-gray-400 hover:bg-slate-50 dark:hover:bg-dark-base hover:text-slate-900 dark:hover:text-white border-l-4 border-transparent transition-all">
                <i class="fa-solid fa-users w-5 text-center"></i> Citizens Directory
            </button>
            <div class="my-4 border-t border-slate-100 dark:border-dark-border"></div>
            <button onclick="switchTab('settings')" id="tab-settings" class="btn-flash tab-btn w-full flex items-center gap-3.5 px-4 py-3 text-sm font-semibold rounded-2xl text-slate-500 dark:text-gray-400 hover:bg-slate-50 dark:hover:bg-dark-base hover:text-slate-900 dark:hover:text-white border-l-4 border-transparent transition-all">
                <i class="fa-solid fa-gear w-5 text-center"></i> System Settings
            </button>
        </div>

        <div class="p-4 border-t border-slate-100 dark:border-dark-border bg-slate-50/50 dark:bg-dark-base/50 rounded-br-[30px]">
            <div class="flex items-center gap-3 px-2">
                <div class="w-10 h-10 rounded-2xl bg-white dark:bg-dark-border flex items-center justify-center text-slate-600 dark:text-gray-300 shadow-sm border border-slate-200 dark:border-gray-600">
                    <i class="fa-solid fa-user-tie"></i>
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-xs font-bold text-slate-900 dark:text-white truncate"><?= htmlspecialchars($_SESSION['admin_name'] ?? 'Administrator') ?></p>
                    <p class="text-[10px] uppercase tracking-wider font-bold text-emerald-500 truncate"><i class="fa-solid fa-circle-dot animate-pulse"></i> Online</p>
                </div>
                <a href="../../api/admin/logout.php" class="btn-flash w-10 h-10 flex items-center justify-center rounded-xl bg-white dark:bg-dark-border border border-slate-200 dark:border-gray-600 text-slate-400 hover:text-tomato hover:border-tomato hover:bg-red-50 dark:hover:bg-tomato/10 transition-all" title="Logout">
                    <i class="fa-solid fa-power-off"></i>
                </a>
            </div>
        </div>
    </aside>

    <div class="flex-1 lg:ml-[290px] flex flex-col min-h-screen">
        
        <header class="h-20 bg-white/90 dark:bg-dark-surface/90 backdrop-blur-md border-b border-slate-200 dark:border-dark-border flex items-center justify-between px-6 md:px-8 sticky top-0 z-40 shadow-sm">
            <div class="flex items-center gap-4">
                <button onclick="toggleSidebar()" class="lg:hidden text-slate-600 dark:text-gray-300 text-xl hover:text-orange-glow transition-colors">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <h2 class="font-display font-bold text-xl text-slate-800 dark:text-white tracking-tight" id="page-title">Dashboard Overview</h2>
            </div>
            <div class="flex items-center gap-4">
                <div class="hidden md:flex items-center gap-2 px-4 py-2 bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border rounded-xl text-xs font-bold text-slate-600 dark:text-gray-300 shadow-inner">
                    <i class="fa-regular fa-clock text-orange-glow"></i>
                    <span id="real-time-clock">Loading...</span>
                </div>
            </div>
        </header>

        <main class="p-6 md:p-8 w-full max-w-[1400px] mx-auto space-y-8 overflow-x-hidden">

            <div id="section-overview" class="space-y-8 block tab-section">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    
                    <div class="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-3xl border border-blue-100 dark:border-blue-800 shadow-saas hover:-translate-y-1 transition-all duration-300 group">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-[11px] font-bold uppercase tracking-wider text-blue-600/70 dark:text-blue-400">Total Citizens</p>
                                <h3 class="font-display font-extrabold text-3xl text-blue-900 dark:text-blue-100 mt-2"><?= htmlspecialchars($total_users) ?></h3>
                            </div>
                            <div class="w-12 h-12 rounded-2xl bg-white dark:bg-blue-800/40 text-blue-500 flex items-center justify-center text-xl shadow-sm group-hover:rotate-6 transition-transform">
                                <i class="fa-solid fa-users"></i>
                            </div>
                        </div>
                    </div>

                    <div class="bg-orange-50 dark:bg-orange-900/20 p-6 rounded-3xl border border-orange-100 dark:border-orange-800 shadow-saas hover:-translate-y-1 transition-all duration-300 group">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-[11px] font-bold uppercase tracking-wider text-orange-600/70 dark:text-orange-400">Issues Logged</p>
                                <h3 class="font-display font-extrabold text-3xl text-orange-900 dark:text-orange-100 mt-2"><?= htmlspecialchars($total_complaints) ?></h3>
                            </div>
                            <div class="w-12 h-12 rounded-2xl bg-white dark:bg-orange-800/40 text-orange-glow flex items-center justify-center text-xl shadow-sm group-hover:rotate-6 transition-transform">
                                <i class="fa-solid fa-clipboard-list"></i>
                            </div>
                        </div>
                    </div>

                    <div class="bg-indigo-50 dark:bg-indigo-900/20 p-6 rounded-3xl border border-indigo-100 dark:border-indigo-800 shadow-saas hover:-translate-y-1 transition-all duration-300 group">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-[11px] font-bold uppercase tracking-wider text-indigo-600/70 dark:text-indigo-400">Active Officers</p>
                                <h3 class="font-display font-extrabold text-3xl text-indigo-900 dark:text-indigo-100 mt-2"><?= htmlspecialchars($total_officers) ?></h3>
                            </div>
                            <div class="w-12 h-12 rounded-2xl bg-white dark:bg-indigo-800/40 text-indigo-500 flex items-center justify-center text-xl shadow-sm group-hover:rotate-6 transition-transform">
                                <i class="fa-solid fa-shield-halved"></i>
                            </div>
                        </div>
                    </div>

                    <div class="bg-emerald-50 dark:bg-emerald-900/20 p-6 rounded-3xl border border-emerald-100 dark:border-emerald-800 shadow-saas hover:-translate-y-1 transition-all duration-300 group">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-[11px] font-bold uppercase tracking-wider text-emerald-600/70 dark:text-emerald-400">Resolution Rate</p>
                                <h3 class="font-display font-extrabold text-3xl text-emerald-900 dark:text-emerald-100 mt-2"><?= htmlspecialchars($resolution_rate) ?>%</h3>
                            </div>
                            <div class="w-12 h-12 rounded-2xl bg-white dark:bg-emerald-800/40 text-emerald-500 flex items-center justify-center text-xl shadow-sm group-hover:rotate-6 transition-transform">
                                <i class="fa-solid fa-chart-line"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-dark-surface border border-slate-200 dark:border-dark-border rounded-3xl p-6 md:p-8 shadow-saas">
                    <h3 class="font-display font-bold text-lg text-slate-800 dark:text-white mb-6">Department Workload Distribution</h3>
                    <div class="relative h-64 md:h-80 w-full flex justify-center"><canvas id="deptChart"></canvas></div>
                </div>
            </div>

            <div id="section-dispatch" class="space-y-6 hidden tab-section">
                <div class="bg-white dark:bg-dark-surface border border-slate-200 dark:border-dark-border rounded-3xl shadow-saas overflow-hidden">
                    <div class="p-6 border-b border-slate-100 dark:border-dark-border flex justify-between items-center">
                        <h3 class="font-display font-bold text-lg text-slate-800 dark:text-white">Pending Assignments</h3>
                        <span class="px-3 py-1 bg-red-50 dark:bg-tomato/10 text-tomato text-[11px] font-bold rounded-full border border-red-100 dark:border-tomato/30"><?= count($pending_dispatch) ?> Pending</span>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm whitespace-nowrap">
                            <thead class="bg-slate-50 dark:bg-dark-base text-slate-500 dark:text-gray-400 font-semibold text-xs uppercase tracking-wider">
                                <tr>
                                    <th class="px-6 py-4">Complaint ID</th>
                                    <th class="px-6 py-4">Issue Details</th>
                                    <th class="px-6 py-4">Department</th>
                                    <th class="px-6 py-4">Assign To Officer</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-dark-border font-medium">
                                <?php if (!empty($pending_dispatch)): ?>
                                    <?php foreach ($pending_dispatch as $c): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-dark-border/30 transition-colors">
                                        <td class="px-6 py-4 font-mono text-slate-400 dark:text-gray-500">#<?= htmlspecialchars($c['id']) ?></td>
                                        <td class="px-6 py-4">
                                            <p class="text-slate-900 dark:text-white font-bold"><?= htmlspecialchars($c['title']) ?></p>
                                            <p class="text-xs text-slate-500 dark:text-gray-400 mt-1"><i class="fa-solid fa-location-dot mr-1 text-orange-glow"></i><?= htmlspecialchars($c['location']) ?></p>
                                        </td>
                                        <td class="px-6 py-4"><span class="px-3 py-1 bg-slate-100 dark:bg-dark-base border border-transparent dark:border-dark-border text-slate-700 dark:text-gray-300 rounded-xl text-xs"><?= htmlspecialchars($c['department_name']) ?></span></td>
                                        <td class="px-6 py-4">
                                            <form action="" method="POST" class="flex flex-col sm:flex-row gap-2">
                                                <input type="hidden" name="action" value="assign_dispatch">
                                                <input type="hidden" name="complaint_id" value="<?= htmlspecialchars($c['id']) ?>">
                                                <select name="officer_id" class="border border-slate-200 dark:border-dark-border rounded-xl text-sm px-3 py-2 bg-slate-50 dark:bg-dark-base text-slate-800 dark:text-gray-200 focus:ring-2 focus:ring-orange-glow/50 outline-none cursor-pointer" required>
                                                    <option value="" disabled selected>Select Officer...</option>
                                                    <?php foreach ($officers as $o): ?>
                                                    <option value="<?= htmlspecialchars($o['id']) ?>"><?= htmlspecialchars($o['full_name']) ?> (<?= htmlspecialchars($o['department_name']) ?>)</option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <button type="submit" class="btn-flash bg-slate-900 dark:bg-orange-glow hover:bg-orange-glow dark:hover:bg-tomato text-white px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors shadow-sm">Assign</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="4" class="px-6 py-10 text-center text-slate-500 dark:text-gray-500">No pending complaints require dispatch.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="section-officers" class="space-y-6 hidden tab-section">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-dark-surface p-6 rounded-3xl border border-slate-200 dark:border-dark-border shadow-saas">
                    <h3 class="font-display font-bold text-xl text-slate-800 dark:text-white">Officer Directory</h3>
                    <button onclick="openModal('modal-officer')" class="btn-flash px-6 py-3 bg-orange-glow hover:bg-tomato text-white text-sm font-bold rounded-2xl shadow-md transition-all flex items-center gap-2 w-full sm:w-auto justify-center">
                        <i class="fa-solid fa-plus"></i> Register Officer
                    </button>
                </div>

                <div class="bg-white dark:bg-dark-surface border border-slate-200 dark:border-dark-border rounded-3xl shadow-saas overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm whitespace-nowrap">
                            <thead class="bg-slate-50 dark:bg-dark-base text-slate-500 dark:text-gray-400 font-semibold text-xs uppercase tracking-wider">
                                <tr>
                                    <th class="px-6 py-4">Badge Number</th>
                                    <th class="px-6 py-4">Officer Name</th>
                                    <th class="px-6 py-4">Department</th>
                                    <th class="px-6 py-4">Email</th>
                                    <th class="px-6 py-4 text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-dark-border font-medium text-slate-800 dark:text-gray-300">
                                <?php foreach ($officers as $o): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-dark-border/30 transition-colors">
                                    <td class="px-6 py-4 font-mono font-bold text-orange-glow"><?= htmlspecialchars($o['badge_number']) ?></td>
                                    <td class="px-6 py-4 dark:text-white font-bold"><?= htmlspecialchars($o['full_name']) ?></td>
                                    <td class="px-6 py-4 text-slate-600 dark:text-gray-400"><?= htmlspecialchars($o['department_name']) ?></td>
                                    <td class="px-6 py-4 text-slate-500 dark:text-gray-500"><?= htmlspecialchars($o['email']) ?></td>
                                    <td class="px-6 py-4">
                                        <div class="flex items-center justify-center gap-3">
                                            <button data-id="<?= htmlspecialchars($o['id']) ?>" data-badge="<?= htmlspecialchars($o['badge_number']) ?>"
                                                data-name="<?= htmlspecialchars($o['full_name']) ?>" data-dept="<?= htmlspecialchars($o['department_id']) ?>"
                                                data-email="<?= htmlspecialchars($o['email']) ?>" onclick="openEditOfficerModal(this)"
                                                class="btn-flash text-blue-500 dark:text-blue-400 bg-blue-50 dark:bg-blue-500/10 hover:bg-blue-100 dark:hover:bg-blue-500 dark:hover:text-white border border-transparent dark:border-blue-500/20 w-10 h-10 rounded-xl transition-all">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </button>

                                            <form action="" method="POST" onsubmit="return confirm('Revoke this officer?');">
                                                <input type="hidden" name="action" value="delete_officer">
                                                <input type="hidden" name="officer_id" value="<?= htmlspecialchars($o['id']) ?>">
                                                <button type="submit" class="btn-flash text-tomato bg-red-50 dark:bg-tomato/10 hover:bg-red-100 dark:hover:bg-tomato dark:hover:text-white border border-transparent dark:border-tomato/20 w-10 h-10 rounded-xl transition-all">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="section-departments" class="space-y-6 hidden tab-section">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-dark-surface p-6 rounded-3xl border border-slate-200 dark:border-dark-border shadow-saas">
                    <h3 class="font-display font-bold text-xl text-slate-800 dark:text-white">Civic Departments</h3>
                    <button onclick="openModal('modal-dept')" class="btn-flash px-6 py-3 bg-slate-900 dark:bg-dark-base hover:bg-slate-800 dark:hover:bg-gray-700 text-white border border-transparent dark:border-gray-600 text-sm font-bold rounded-2xl shadow-md transition-all flex items-center gap-2 w-full sm:w-auto justify-center">
                        <i class="fa-solid fa-plus"></i> Create Department
                    </button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($departments as $d): ?>
                    <div class="bg-white dark:bg-dark-surface border border-slate-200 dark:border-dark-border p-6 rounded-3xl shadow-saas hover:-translate-y-1 hover:shadow-saas-lg transition-all relative flex flex-col justify-between group">
                        <div>
                            <div class="w-12 h-12 rounded-2xl bg-orange-50 dark:bg-orange-glow/10 text-orange-glow flex items-center justify-center text-xl mb-5 border border-orange-100 dark:border-orange-glow/20 group-hover:scale-110 transition-transform">
                                <i class="fa-solid fa-building"></i>
                            </div>
                            <h4 class="font-display font-extrabold text-xl text-slate-900 dark:text-white"><?= htmlspecialchars($d['department_name']) ?></h4>
                            <p class="text-sm text-slate-500 dark:text-gray-400 mt-2 leading-relaxed"><?= htmlspecialchars($d['description']) ?></p>
                        </div>
                        <div class="mt-6 flex items-center gap-3 pt-5 border-t border-slate-100 dark:border-dark-border">
                            <button data-id="<?= htmlspecialchars($d['id']) ?>" data-name="<?= htmlspecialchars($d['department_name']) ?>"
                                data-desc="<?= htmlspecialchars($d['description']) ?>" onclick="openEditDeptModal(this)"
                                class="btn-flash text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-500/10 hover:bg-blue-100 dark:hover:bg-blue-500 dark:hover:text-white py-2.5 rounded-xl transition-all flex-1 text-center font-bold text-xs uppercase tracking-wider">
                                <i class="fa-solid fa-pen-to-square mr-1"></i> Edit
                            </button>
                            <form action="" method="POST" onsubmit="return confirm('Delete this department?');" class="flex-1">
                                <input type="hidden" name="action" value="delete_department">
                                <input type="hidden" name="dept_id" value="<?= htmlspecialchars($d['id']) ?>">
                                <button type="submit" class="btn-flash w-full text-tomato bg-red-50 dark:bg-tomato/10 hover:bg-red-100 dark:hover:bg-tomato dark:hover:text-white py-2.5 rounded-xl transition-all font-bold text-xs uppercase tracking-wider text-center"><i class="fa-solid fa-trash-can mr-1"></i> Delete</button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div id="section-users" class="space-y-6 hidden tab-section">
                <div class="bg-white dark:bg-dark-surface border border-slate-200 dark:border-dark-border rounded-3xl shadow-saas overflow-hidden">
                    <div class="p-6 border-b border-slate-100 dark:border-dark-border">
                        <h3 class="font-display font-bold text-xl text-slate-800 dark:text-white">Registered Citizens</h3>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm whitespace-nowrap">
                            <thead class="bg-slate-50 dark:bg-dark-base text-slate-500 dark:text-gray-400 font-semibold text-xs uppercase tracking-wider">
                                <tr>
                                    <th class="px-6 py-4">Citizen ID</th>
                                    <th class="px-6 py-4">Full Name</th>
                                    <th class="px-6 py-4">Contact Info</th>
                                    <th class="px-6 py-4">Ward Area</th>
                                    <th class="px-6 py-4 text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-dark-border font-medium">
                                <?php foreach ($users as $u): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-dark-border/30 transition-colors">
                                    <td class="px-6 py-4 font-mono text-slate-400 dark:text-gray-500">#<?= htmlspecialchars($u['id']) ?></td>
                                    <td class="px-6 py-4 text-slate-900 dark:text-white font-bold"><?= htmlspecialchars($u['full_name']) ?></td>
                                    <td class="px-6 py-4 text-slate-600 dark:text-gray-400"><?= htmlspecialchars($u['email']) ?></td>
                                    <td class="px-6 py-4"><span class="px-3 py-1 bg-slate-100 dark:bg-dark-base border border-transparent dark:border-dark-border text-slate-600 dark:text-gray-300 rounded-xl text-xs"><?= htmlspecialchars($u['ward']) ?></span></td>
                                    <td class="px-6 py-4 text-center">
                                        <form action="" method="POST" onsubmit="return confirm('Delete this citizen account?');">
                                            <input type="hidden" name="action" value="delete_user">
                                            <input type="hidden" name="user_id" value="<?= htmlspecialchars($u['id']) ?>">
                                            <button type="submit" class="btn-flash text-tomato bg-red-50 dark:bg-tomato/10 hover:bg-red-100 dark:hover:bg-tomato dark:hover:text-white px-4 py-2 rounded-xl transition-colors text-[11px] font-bold uppercase tracking-wider"><i class="fa-solid fa-trash-can mr-1"></i> Remove</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="section-settings" class="space-y-6 hidden tab-section">
                <h3 class="font-display font-bold text-2xl text-slate-800 dark:text-white mb-4">System Settings</h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-white dark:bg-dark-surface border border-slate-200 dark:border-dark-border p-6 md:p-8 rounded-3xl shadow-saas">
                        <div class="flex items-center gap-4 mb-6">
                            <div class="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-900/20 text-indigo-500 flex items-center justify-center text-xl">
                                <i class="fa-solid fa-palette"></i>
                            </div>
                            <div>
                                <h4 class="font-display font-bold text-lg text-slate-900 dark:text-white">Theme Mode</h4>
                                <p class="text-sm text-slate-500 dark:text-gray-400">Switch between light and dark UI.</p>
                            </div>
                        </div>
                        <button onclick="toggleTheme()" class="btn-flash w-full py-3.5 bg-slate-900 dark:bg-orange-glow text-white rounded-2xl font-bold text-sm transition-all shadow-md flex items-center justify-center gap-2">
                            <i class="fa-solid fa-moon dark:hidden"></i>
                            <i class="fa-solid fa-sun hidden dark:inline"></i>
                            Toggle Dark / Light Mode
                        </button>
                    </div>

                    <div class="bg-white dark:bg-dark-surface border border-slate-200 dark:border-dark-border p-6 md:p-8 rounded-3xl shadow-saas">
                        <div class="flex items-center gap-4 mb-6">
                            <div class="w-12 h-12 rounded-2xl bg-saffron/10 text-saffron flex items-center justify-center text-xl border border-saffron/20">
                                <i class="fa-solid fa-text-height"></i>
                            </div>
                            <div>
                                <h4 class="font-display font-bold text-lg text-slate-900 dark:text-white">Typography Size</h4>
                                <p class="text-sm text-slate-500 dark:text-gray-400">Scale the text size across the portal.</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-4 bg-slate-50 dark:bg-dark-base p-2 rounded-2xl border border-slate-200 dark:border-dark-border">
                            <button onclick="changeTextSize(-1)" class="btn-flash flex-1 py-3 text-slate-600 dark:text-gray-300 hover:bg-white dark:hover:bg-dark-surface rounded-xl font-bold transition-all border border-transparent hover:border-slate-200 dark:hover:border-dark-border shadow-sm">
                                <i class="fa-solid fa-minus"></i> Smaller
                            </button>
                            <span class="font-bold text-slate-400 text-sm">|</span>
                            <button onclick="changeTextSize(1)" class="btn-flash flex-1 py-3 text-slate-600 dark:text-gray-300 hover:bg-white dark:hover:bg-dark-surface rounded-xl font-bold transition-all border border-transparent hover:border-slate-200 dark:hover:border-dark-border shadow-sm">
                                <i class="fa-solid fa-plus"></i> Larger
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <div id="modal-officer" class="fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4 transition-opacity">
        <div class="bg-white dark:bg-dark-surface rounded-[30px] shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 dark:border-dark-border">
            <div class="p-6 border-b border-slate-100 dark:border-dark-border flex justify-between items-center bg-slate-50 dark:bg-dark-base">
                <h3 class="font-display font-bold text-lg text-slate-900 dark:text-white">Add New Officer</h3>
                <button onclick="closeModal('modal-officer')" class="text-slate-400 hover:text-tomato transition-all hover:rotate-90"><i class="fa-solid fa-xmark text-xl"></i></button>
            </div>
            <form action="" method="POST" class="p-6 space-y-4">
                <input type="hidden" name="action" value="add_officer">
                <input type="text" name="badge_number" required placeholder="Badge No (e.g. JMC-101)" class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none font-medium placeholder-slate-400 dark:placeholder-gray-500 transition-all">
                <input type="text" name="full_name" required placeholder="Officer Name" class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none font-medium placeholder-slate-400 dark:placeholder-gray-500 transition-all">
                <select name="department_id" required class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none cursor-pointer font-medium transition-all">
                    <option value="" disabled selected class="text-slate-400 dark:text-gray-500">Select Department...</option>
                    <?php foreach ($departments as $d): ?>
                        <option value="<?= htmlspecialchars($d['id']) ?>"><?= htmlspecialchars($d['department_name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="email" name="email" required placeholder="Email Address" class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none font-medium placeholder-slate-400 dark:placeholder-gray-500 transition-all">
                <input type="password" name="password" required placeholder="Password" class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none font-mono placeholder-slate-400 dark:placeholder-gray-500 transition-all">
                <button type="submit" class="btn-flash w-full py-4 bg-orange-glow hover:bg-tomato text-white rounded-2xl font-bold text-sm uppercase transition-all shadow-md tracking-wider">Register Officer</button>
            </form>
        </div>
    </div>

    <div id="modal-edit-officer" class="fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4 transition-opacity">
        <div class="bg-white dark:bg-dark-surface rounded-[30px] shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 dark:border-dark-border">
            <div class="p-6 border-b border-slate-100 dark:border-dark-border flex justify-between items-center bg-slate-50 dark:bg-dark-base">
                <h3 class="font-display font-bold text-lg text-slate-900 dark:text-white">Edit Officer Record</h3>
                <button onclick="closeModal('modal-edit-officer')" class="text-slate-400 hover:text-tomato transition-all hover:rotate-90"><i class="fa-solid fa-xmark text-xl"></i></button>
            </div>
            <form id="editOfficerForm" action="" method="POST" class="p-6 space-y-4">
                <input type="hidden" name="action" value="update_officer">
                <input type="hidden" name="officer_id" id="edit-officer-id">
                <input type="text" name="badge_number" id="edit-officer-badge" required class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none font-medium transition-all">
                <input type="text" name="full_name" id="edit-officer-name" required class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none font-medium transition-all">
                <select name="department_id" id="edit-officer-dept" required class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none cursor-pointer font-medium transition-all">
                    <?php foreach ($departments as $d): ?>
                        <option value="<?= htmlspecialchars($d['id']) ?>"><?= htmlspecialchars($d['department_name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="email" name="email" id="edit-officer-email" required class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none font-medium transition-all">
                <button type="submit" class="btn-flash w-full py-4 bg-orange-glow hover:bg-tomato text-white rounded-2xl font-bold text-sm uppercase transition-all shadow-md tracking-wider">Update Officer</button>
            </form>
        </div>
    </div>

    <div id="modal-dept" class="fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4 transition-opacity">
        <div class="bg-white dark:bg-dark-surface rounded-[30px] shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 dark:border-dark-border">
            <div class="p-6 border-b border-slate-100 dark:border-dark-border flex justify-between items-center bg-slate-50 dark:bg-dark-base">
                <h3 class="font-display font-bold text-lg text-slate-900 dark:text-white">Create Department</h3>
                <button onclick="closeModal('modal-dept')" class="text-slate-400 hover:text-tomato transition-all hover:rotate-90"><i class="fa-solid fa-xmark text-xl"></i></button>
            </div>
            <form action="" method="POST" class="p-6 space-y-4">
                <input type="hidden" name="action" value="add_department">
                <input type="text" name="dept_name" required placeholder="Department Name" class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none font-medium placeholder-slate-400 dark:placeholder-gray-500 transition-all">
                <textarea name="description" rows="3" required placeholder="Scope of work..." class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none resize-none font-medium placeholder-slate-400 dark:placeholder-gray-500 transition-all"></textarea>
                <button type="submit" class="btn-flash w-full py-4 bg-orange-glow hover:bg-tomato text-white rounded-2xl font-bold text-sm uppercase transition-all shadow-md tracking-wider">Establish Department</button>
            </form>
        </div>
    </div>

    <div id="modal-edit-dept" class="fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4 transition-opacity">
        <div class="bg-white dark:bg-dark-surface rounded-[30px] shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 dark:border-dark-border">
            <div class="p-6 border-b border-slate-100 dark:border-dark-border flex justify-between items-center bg-slate-50 dark:bg-dark-base">
                <h3 class="font-display font-bold text-lg text-slate-900 dark:text-white">Edit Department</h3>
                <button onclick="closeModal('modal-edit-dept')" class="text-slate-400 hover:text-tomato transition-all hover:rotate-90"><i class="fa-solid fa-xmark text-xl"></i></button>
            </div>
            <form id="editDeptForm" action="" method="POST" class="p-6 space-y-4">
                <input type="hidden" name="action" value="update_department">
                <input type="hidden" name="dept_id" id="edit-dept-id">
                <input type="text" name="dept_name" id="edit-dept-name" required class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none font-medium transition-all">
                <textarea name="description" id="edit-dept-desc" rows="3" required class="w-full bg-slate-50 dark:bg-dark-base border border-slate-200 dark:border-dark-border text-slate-900 dark:text-white rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-orange-glow/50 outline-none resize-none font-medium transition-all"></textarea>
                <button type="submit" class="btn-flash w-full py-4 bg-orange-glow hover:bg-tomato text-white rounded-2xl font-bold text-sm uppercase transition-all shadow-md tracking-wider">Update Department</button>
            </form>
        </div>
    </div>

    <script>
        // Real-time Clock
        function updateClock() {
            const now = new Date();
            const options = { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
            document.getElementById('real-time-clock').textContent = now.toLocaleDateString('en-US', options).toUpperCase();
        }
        setInterval(updateClock, 1000); updateClock();

        // Sidebar Mobile Toggle
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('mobile-overlay');
            sidebar.classList.toggle('-translate-x-full');
            
            if (overlay.classList.contains('hidden')) {
                overlay.classList.remove('hidden');
                setTimeout(() => overlay.classList.remove('opacity-0'), 10);
            } else {
                overlay.classList.add('opacity-0');
                setTimeout(() => overlay.classList.add('hidden'), 300);
            }
        }

        // Tab Switching Logic
        const tabs = ['overview', 'dispatch', 'officers', 'departments', 'users', 'settings'];
        const pageTitles = { 'overview': 'Dashboard Overview', 'dispatch': 'Dispatch Desk', 'officers': 'Officer Directory', 'departments': 'Civic Departments', 'users': 'Citizen Directory', 'settings': 'System Settings' };

        function switchTab(activeTab) {
            tabs.forEach(tab => {
                document.getElementById('section-' + tab).classList.add('hidden');
                let btn = document.getElementById('tab-' + tab);
                // Reset to inactive styles
                btn.className = "btn-flash tab-btn w-full flex items-center gap-3.5 px-4 py-3 text-sm font-semibold rounded-2xl text-slate-500 dark:text-gray-400 hover:bg-slate-50 dark:hover:bg-dark-base hover:text-slate-900 dark:hover:text-white border-l-4 border-transparent transition-all";
            });
            
            // Re-apply classes to trigger CSS animation
            const section = document.getElementById('section-' + activeTab);
            section.classList.remove('hidden');
            section.classList.remove('tab-section'); 
            void section.offsetWidth; 
            section.classList.add('tab-section');

            let activeBtn = document.getElementById('tab-' + activeTab);
            // Apply active styles
            activeBtn.className = "btn-flash tab-btn w-full flex items-center gap-3.5 px-4 py-3 text-sm font-semibold rounded-2xl bg-orange-50 dark:bg-dark-base text-orange-glow border-l-4 border-orange-glow shadow-sm transition-all";
            
            document.getElementById('page-title').textContent = pageTitles[activeTab];
            
            // Close sidebar on mobile after clicking a tab
            if (window.innerWidth < 1024) toggleSidebar();
        }

        // Settings: Theme Toggle
        function toggleTheme() {
            const html = document.documentElement;
            html.classList.toggle('dark');
            if (html.classList.contains('dark')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
            // Optional: Re-render Chart.js to update label colors dynamically
            if(window.myChart) {
                window.myChart.options.plugins.legend.labels.color = html.classList.contains('dark') ? '#9CA3AF' : '#475569';
                window.myChart.update();
            }
        }

        // Settings: Text Size Adjuster
        let currentFontSize = parseInt(localStorage.getItem('textSize')) || 16;
        function changeTextSize(step) {
            currentFontSize += step;
            // Limit bounds so it doesn't get ridiculously small or large
            if (currentFontSize < 12) currentFontSize = 12;
            if (currentFontSize > 22) currentFontSize = 22;
            
            document.documentElement.style.fontSize = currentFontSize + 'px';
            localStorage.setItem('textSize', currentFontSize);
        }

        // Modal Handlers
        function openModal(id) { document.getElementById(id).classList.remove('hidden'); }
        function closeModal(id) { document.getElementById(id).classList.add('hidden'); }

        function openEditOfficerModal(button) {
            document.getElementById('edit-officer-id').value = button.getAttribute('data-id');
            document.getElementById('edit-officer-badge').value = button.getAttribute('data-badge');
            document.getElementById('edit-officer-name').value = button.getAttribute('data-name');
            document.getElementById('edit-officer-dept').value = button.getAttribute('data-dept');
            document.getElementById('edit-officer-email').value = button.getAttribute('data-email');
            openModal('modal-edit-officer');
        }

        function openEditDeptModal(button) {
            document.getElementById('edit-dept-id').value = button.getAttribute('data-id');
            document.getElementById('edit-dept-name').value = button.getAttribute('data-name');
            document.getElementById('edit-dept-desc').value = button.getAttribute('data-desc');
            openModal('modal-edit-dept');
        }

        // Chart.js
        document.addEventListener("DOMContentLoaded", function () {
            const labels = <?= json_encode($chart_labels ?? []) ?>;
            const dataValues = <?= json_encode($chart_values ?? []) ?>;
            
            if (labels.length > 0) {
                const isDark = document.documentElement.classList.contains('dark');
                Chart.defaults.color = isDark ? '#9CA3AF' : '#475569'; 

                window.myChart = new Chart(document.getElementById('deptChart').getContext('2d'), {
                    type: 'doughnut',
                    data: { 
                        labels: labels, 
                        datasets: [{ 
                            data: dataValues, 
                            backgroundColor: ['#FF7A00', '#FF6347', '#3B82F6', '#10B981', '#6366F1'], 
                            borderWidth: 0, 
                            hoverOffset: 8 
                        }] 
                    },
                    options: { 
                        responsive: true, 
                        maintainAspectRatio: false, 
                        cutout: '75%', 
                        layout: { padding: 10 },
                        plugins: { 
                            legend: { 
                                position: 'right', 
                                labels: { 
                                    usePointStyle: true, 
                                    padding: 20, 
                                    font: { family: "'Plus Jakarta Sans', sans-serif", size: 13, weight: '700' } 
                                } 
                            } 
                        } 
                    }
                });
            }
        });
    </script>
</body>
</html>
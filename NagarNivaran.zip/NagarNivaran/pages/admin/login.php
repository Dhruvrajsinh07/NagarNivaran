<?php
require_once("../../includes/config.php");

$error = $_SESSION['admin_error'] ?? null;
unset($_SESSION['admin_error']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Control Access | NagarNivaran</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Courier+Prime:ital,wght@0,400;0,700;1,400&family=Hind+Vadodara:wght@500;600;700&family=IBM+Plex+Serif:wght@600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap"
        rel="stylesheet">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'desk': '#EAE7E0',
                        'paper': '#FDFDFD',
                        'ink': '#0F172A',
                        'stamp-red': '#FF6347',
                        'stamp-orange': '#FF7A00',
                        'stamp-saffron': '#FF9933',
                    },
                    fontFamily: {
                        official: ['"IBM Plex Serif"', 'serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        gujarati: ['"Hind Vadodara"', 'sans-serif'],
                        mono: ['"Courier Prime"', 'monospace'],
                    },
                    boxShadow: {
                        'ticket-shadow': '0 25px 50px -12px rgba(15, 23, 42, 0.15)',
                        'hard-press-ink': '4px 4px 0px #0F172A',
                    }
                }
            }
        }
    </script>

    <style>
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #EAE7E0;
        }

        ::-webkit-scrollbar-thumb {
            background: #FF7A00;
            border-radius: 4px;
        }

        .paper-input {
            background: transparent !important;
            border-top: 0 !important;
            border-left: 0 !important;
            border-right: 0 !important;
            border-bottom: 2px solid #0F172A !important;
            border-radius: 0 !important;
            box-shadow: none !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
        }

        .paper-input:focus {
            outline: none !important;
            border-bottom-color: #FF7A00 !important;
        }
    </style>
</head>

<body
    class="bg-desk text-ink font-sans antialiased relative min-h-screen py-10 px-4 flex flex-col items-center justify-between selection:bg-stamp-orange selection:text-white">

    <div
        class="fixed inset-0 -z-10 bg-[radial-gradient(#0F172A_1.5px,transparent_1.5px)] [background-size:32px_32px] opacity-[0.06] pointer-events-none">
    </div>

    <div
        class="w-full max-w-4xl mb-4 flex justify-between items-center text-slate-600 text-xs px-2 font-bold relative z-20">

        <a href="<?= urlof('') ?>"
            class="hover:text-stamp-orange flex items-center gap-2 transition-colors">

            <i class="fa-solid fa-arrow-left"></i>
            Return to Public Portal
        </a>

        <span
            class="text-[11px] font-mono tracking-widest text-stamp-orange uppercase font-bold">
            [ Control Hub ]
        </span>
    </div>

    <?php if ($error): ?>

        <div class="w-full max-w-4xl relative z-20">

            <div
                class="mb-6 p-4 border-2 border-stamp-red bg-red-50 text-stamp-red text-xs font-mono font-bold uppercase tracking-widest shadow-md flex items-center gap-3">

                <i class="fa-solid fa-triangle-exclamation text-lg animate-pulse"></i>

                <span>
                    SECURITY NOTICE: <?= htmlspecialchars($error) ?>
                </span>

            </div>

        </div>

    <?php endif; ?>


    <div
        class="max-w-4xl w-full bg-paper text-ink shadow-ticket-shadow border-2 border-ink rounded-sm relative my-auto flex flex-col md:flex-row overflow-hidden">

        <div
            class="hidden md:block absolute top-[-15px] left-[68%] -translate-x-1/2 w-7 h-7 rounded-full bg-desk border-b-2 border-ink z-30 shadow-inner">
        </div>

        <div
            class="hidden md:block absolute bottom-[-15px] left-[68%] -translate-x-1/2 w-7 h-7 rounded-full bg-desk border-t-2 border-ink z-30 shadow-inner">
        </div>


        <div
            class="w-full md:w-[68%] p-8 sm:p-14 md:border-r-2 border-dashed border-slate-300 relative z-10 flex flex-col justify-between bg-white">

            <div>

                <div
                    class="flex justify-between items-center border-b-2 border-ink/20 pb-3 mb-8 text-xs font-bold font-mono text-slate-500">

                    <span class="tracking-widest uppercase text-ink">
                        JMC Central Command
                    </span>

                    <span
                        class="text-stamp-orange tracking-widest uppercase font-black">
                        <i class="fa-solid fa-lock mr-1"></i>
                        [ MASTER CLEARANCE ]
                    </span>

                </div>


                <div class="flex items-center gap-5 mb-8">

                    <div
                        class="w-16 h-16 rounded-full border-2 border-stamp-orange p-0.5 overflow-hidden shrink-0 flex items-center justify-center bg-white shadow-sm select-none">

                        <i class="fa-solid fa-shield-halved text-3xl text-stamp-orange"></i>

                    </div>

                    <div>

                        <h1
                            class="font-official font-bold text-2xl sm:text-3xl tracking-tight text-ink uppercase leading-none">
                            Master Control
                        </h1>

                        <p
                            class="font-gujarati font-bold text-sm sm:text-base text-stamp-orange tracking-wide mt-1.5">
                            નગરનિવારણ • મુખ્ય સંચાલક
                        </p>

                        <span
                            class="text-[10px] font-mono bg-orange-50 text-stamp-orange px-2.5 py-0.5 font-bold mt-1 inline-block border border-orange-200 rounded uppercase tracking-wider">
                            Level 1 System Authorization
                        </span>

                    </div>

                </div>


                <p
                    class="text-xs text-slate-600 mb-8 font-mono bg-slate-50 p-3.5 rounded border-l-4 border-stamp-orange leading-relaxed font-bold">

                    Provide authorized system administrator credentials to access the central intelligence hub and dispatch grids.

                </p>


                <!-- PHP BACKEND -->
                <form
                    action="<?= urlof('api/admin/login.php') ?>"
                    method="POST"
                    class="space-y-7">

                    <div class="relative flex flex-col">

                        <label
                            class="text-[11px] font-extrabold uppercase tracking-wider text-slate-800 font-sans">

                            1. Admin Clearance ID
                            <span class="text-stamp-orange">*</span>

                        </label>

                        <div class="relative flex items-center mt-1">

                            <i
                                class="fa-solid fa-terminal absolute right-2.5 bottom-3 text-slate-400 text-sm">
                            </i>

                            <input
                                type="text"
                                name="username"
                                required
                                autocomplete="off"
                                class="paper-input w-full py-2.5 text-slate-950 font-bold text-base transition-colors placeholder-slate-300 tracking-wide"
                                placeholder="e.g. jmc_master">

                        </div>

                    </div>


                    <div class="relative flex flex-col pt-2">

                        <div class="flex justify-between items-center">

                            <label
                                class="text-[11px] font-extrabold uppercase tracking-wider text-slate-800 font-sans">

                                2. Encryption Key
                                <span class="text-stamp-orange">*</span>

                            </label>

                        </div>

                        <div class="relative flex items-center mt-1">

                            <i
                                class="fa-solid fa-key absolute right-2.5 bottom-3 text-slate-400 text-sm">
                            </i>

                            <input
                                type="password"
                                name="password"
                                required
                                class="paper-input w-full py-2.5 text-slate-950 font-bold text-lg transition-colors tracking-[0.2em] font-mono placeholder-slate-300"
                                placeholder="••••••••">

                        </div>

                    </div>


                    <div class="pt-6">

                        <button
                            type="submit"
                            class="w-full py-4 bg-ink hover:bg-stamp-orange text-white font-official font-bold text-sm tracking-widest uppercase shadow-hard-press-ink hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-none transition-all border-2 border-ink flex items-center justify-center gap-2.5 group rounded-sm">

                            <i
                                class="fa-solid fa-fingerprint text-stamp-saffron group-hover:text-white transition-colors text-lg">
                            </i>

                            <span>[ Validate Clearance ]</span>

                        </button>

                    </div>

                </form>

            </div>


            <div
                class="mt-10 pt-4 border-t border-slate-200 flex justify-between items-center text-[11px] font-mono text-slate-400">

                <span>PORTAL STATUS: SECURE ENCLAVE</span>

                <span class="text-stamp-orange font-bold uppercase">
                    AES-256 Encrypted Node
                </span>

            </div>

        </div>


        <div
            class="w-full md:w-[32%] bg-slate-50 p-8 flex flex-col justify-between items-center text-center relative select-none border-t-2 md:border-t-0 border-dashed border-slate-300">

            <div
                class="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03]">

                <i class="fa-solid fa-user-shield text-9xl text-slate-900"></i>

            </div>


            <div class="w-full border-b border-slate-200 pb-4 relative z-10">

                <span
                    class="text-[10px] font-mono text-slate-400 block tracking-widest uppercase font-bold">
                    Gate Stub
                </span>

                <span
                    class="font-official font-bold text-base text-ink block mt-1 uppercase">
                    SysAdmin Record
                </span>

                <span
                    class="text-[10px] font-mono text-stamp-orange font-bold tracking-wider block mt-0.5">
                    INTERNAL USE ONLY
                </span>

            </div>


            <div class="my-auto space-y-3 relative z-10 py-8">

                <div
                    class="w-24 h-24 rounded-full border-2 border-dashed border-stamp-orange/50 mx-auto flex flex-col items-center justify-center p-2 bg-white shadow-sm rotate-12">

                    <span
                        class="text-[9px] font-official font-bold text-stamp-orange uppercase tracking-widest">
                        Master
                    </span>

                    <i
                        class="fa-solid fa-check-double text-stamp-orange/60 text-2xl my-1">
                    </i>

                    <span
                        class="text-[8px] font-mono text-slate-600 font-bold tracking-widest">
                        CLEARANCE
                    </span>

                </div>


                <div class="pt-4">

                    <p class="font-gujarati font-bold text-sm text-slate-800">
                        જામનગર મહાનગરપાલિકા
                    </p>

                    <p class="text-xs text-slate-500 mt-0.5 font-sans font-bold">
                        ડેટા સેન્ટર
                    </p>

                </div>

            </div>


            <div
                class="w-full pt-4 border-t border-slate-200 relative z-10">

                <span
                    class="text-[10px] font-mono text-slate-600 font-bold block uppercase tracking-wider">
                    Access Log Entry
                </span>

                <span
                    class="text-[9px] font-mono text-slate-400 block mt-0.5">
                    SLIP NO: #JMC-ADM-AUTH
                </span>

            </div>

        </div>

    </div>


    <footer
        class="w-full max-w-4xl mt-6 text-center text-[11px] text-slate-500 font-mono space-y-1 relative z-20">

        <p>
            JAMNAGAR MUNICIPAL CORPORATION &bull; NAGARNIVARAN SECURE DESK
        </p>

        <p class="text-slate-400">
            &copy; 2026 Government of Gujarat. Restricted Administrator Interface.
        </p>

    </footer>

</body>

</html>
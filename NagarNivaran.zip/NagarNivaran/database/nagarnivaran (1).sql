-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2026 at 08:15 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nagarnivaran`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT 'Super Admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Bhadra', 'admin01@nn.gov.in', 'admin123', 'Super Admin', '2026-07-13 06:41:16');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `reporter_name` varchar(150) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `location` varchar(255) NOT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('Pending','In Progress','Resolved','Rejected') DEFAULT 'Pending',
  `priority` enum('Low','Medium','High','Critical') DEFAULT 'Medium',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `user_id`, `department_id`, `reporter_name`, `title`, `description`, `location`, `latitude`, `longitude`, `image`, `status`, `priority`, `created_at`, `updated_at`) VALUES
(1, 5, 1, 'Star S. star', 'Deep path hole near jakat naka circle', 'This is to inform JMC Road department that there is a big deep path hole in ward - 6 ranjit nagar jakat naka circle so fix it as soon as possible!', 'ward 6, ranjit nagar', NULL, NULL, 'ChatGPT_Image_May_28_2026_06_58_47_PM.png', 'Resolved', 'Medium', '2026-07-09 07:21:50', '2026-07-09 07:59:32'),
(2, 6, 1, 'Diya e. patel', 'Small Pathholes near patel colony-2', 'Please fix this asap', 'ward - 8, patel colony-2', NULL, NULL, '1026.jpg', 'Resolved', 'Medium', '2026-07-09 09:38:21', '2026-07-12 12:28:29'),
(3, 2, 2, 'Vishal j. trivedi', 'Water pipeline leacage problem ', 'Water is continues lick in ward - 8 sup pipeline ', 'ward - 8, patel colony-2', NULL, NULL, 'ChatGPT_Image_May_20_2026_12_13_17_PM.png', 'In Progress', 'Medium', '2026-07-13 13:54:29', '2026-07-13 14:00:08'),
(4, 4, 3, 'smruti k. jain', 'weak Sanitation problem in digvijay plot - 54', 'There is less or Weak sanitation in our aera and irregular West Segrigation....', 'ward - 11, 54-digvijay plot', NULL, NULL, 'Screenshot_2026-05-28_191240.png', 'Resolved', 'Medium', '2026-07-14 07:45:52', '2026-07-15 06:20:43'),
(5, 1, 3, 'Vikas h. gupta', 'Unblanced Sanitation process ', 'Near my home area 54-Digvijay plot has Unbalanced Sanitation issue so please fix it as soon as possible! ', 'ward - 11, 54-digvijay plot', NULL, NULL, 'images.jpeg', 'Resolved', 'Medium', '2026-07-15 06:19:19', '2026-07-15 06:24:13'),
(6, 8, 2, 'mulrajsinh a parmar', 'Inconsistence Water Supply', 'In our area inconsistence water Supply, no time, less water etc...', 'ward - 11, 54-digvijay plot', NULL, NULL, 'complaint_8_1785844183_6f2914cccf.jpg', 'In Progress', 'Medium', '2026-08-04 11:49:43', '2026-08-18 14:36:05'),
(7, 10, 3, 'Vansh k vora', 'Weak Sanitation', 'There is weak sanitation in this area and so much odear coming from suage so please fix it asap', 'ward - 14, Refinery area', NULL, NULL, 'complaint_10_1785845675_a914b6514e.jpg', 'Resolved', 'Medium', '2026-08-04 12:14:35', '2026-08-17 17:46:00'),
(8, 10, 5, 'Vansh k vora', 'Pathole', 'Deep Path hole Near my area!', 'ward - 14, Refinery area', NULL, NULL, 'complaint_10_1786988344_786dc38dea.jpg', 'In Progress', 'Medium', '2026-08-17 17:39:04', '2026-08-17 17:41:14'),
(9, 8, 3, 'mulrajsinh a parmar', 'Weak Sanitation', 'weak saniation...', 'ward - 11, 54-digvijay plot', NULL, NULL, 'complaint_8_1786988670_025597de40.jpg', 'Resolved', 'Medium', '2026-08-17 17:44:30', '2026-08-17 17:55:13'),
(11, 6, 4, 'Diya e. patel', 'Light out / power Cut', 'Power Cut Frecuent and not sowled!', 'ward - 8, patel colony-2', NULL, NULL, 'complaint_6_1787074485_2b99b69b34.png', 'Resolved', 'High', '2026-08-18 17:34:45', '2026-08-18 17:42:48'),
(12, 12, 4, 'Divtarajsinh a. gohil', 'Broken Street Light', 'Fix this asap ! this is Critical without light to see in area at night!', 'ward - 11, vrundavan Park-1,Gulabngara', NULL, NULL, 'complaint_12_1787075602_4ff37d6c26.png', 'Resolved', 'Critical', '2026-08-18 17:53:22', '2026-08-18 18:00:46'),
(13, 7, 1, 'priti p. parekh', 'Pathole', 'There is a small pathole in our area please fix it ASAP.', 'Ward no - 8, patel colony 3', NULL, NULL, 'complaint_7_1787076608_817b3537dc.jpg', 'In Progress', 'Low', '2026-08-18 18:10:08', '2026-08-18 18:15:52'),
(14, 13, 1, 'Vir', 'Rough Road', 'There is Rough Road condition near railway station road so please fix asap because of daily transportation conditions in this road.', 'Ward no - 11, Hapa Railway Station', NULL, NULL, 'complaint_13_1788697610_9bc1963c18.jpg', 'Resolved', 'High', '2026-09-06 12:26:50', '2026-09-06 13:51:51'),
(15, 15, 1, 'Vikrant A. pathak', 'Test Case', 'Test Case', 'Test case', NULL, NULL, NULL, 'Pending', 'Medium', '2026-09-14 17:24:16', '2026-09-14 17:24:16');

-- --------------------------------------------------------

--
-- Table structure for table `complaint_assignments`
--

CREATE TABLE `complaint_assignments` (
  `id` int(11) NOT NULL,
  `complaint_id` int(11) NOT NULL,
  `officer_id` int(11) NOT NULL,
  `assigned_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Active','Reassigned','Revoked') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaint_assignments`
--

INSERT INTO `complaint_assignments` (`id`, `complaint_id`, `officer_id`, `assigned_date`, `status`) VALUES
(1, 4, 3, '2026-07-14 07:51:28', 'Active'),
(2, 5, 3, '2026-07-15 06:22:21', 'Active'),
(3, 6, 2, '2026-08-05 16:14:03', 'Active'),
(4, 7, 3, '2026-08-05 16:14:13', 'Active'),
(5, 8, 1, '2026-08-17 17:41:14', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `complaint_remarks`
--

CREATE TABLE `complaint_remarks` (
  `id` int(11) NOT NULL,
  `complaint_id` int(11) NOT NULL,
  `officer_id` int(11) NOT NULL,
  `remark` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaint_remarks`
--

INSERT INTO `complaint_remarks` (`id`, `complaint_id`, `officer_id`, `remark`, `created_at`) VALUES
(1, 1, 1, 'asjdjj', '2026-07-09 07:56:47'),
(2, 1, 1, 'This Issue is Resolve! ', '2026-07-09 07:59:32'),
(3, 2, 1, 'Resolved! case', '2026-07-09 09:40:21'),
(4, 2, 1, 'Resolved! case', '2026-07-09 09:41:04'),
(5, 3, 2, 'This issue is dispatched and in 2 day resolve!', '2026-07-13 14:00:08'),
(6, 4, 3, 'xyz', '2026-07-14 07:54:29'),
(7, 5, 3, 'Done!', '2026-07-15 06:24:13'),
(8, 7, 3, 'done', '2026-08-17 17:46:00'),
(9, 9, 3, 'Done!', '2026-08-17 17:54:04'),
(10, 6, 2, 'Dispatched', '2026-08-18 14:26:43'),
(11, 11, 4, 'Problem Solved!', '2026-08-18 17:42:48'),
(12, 12, 4, 'Resoveld! Crictical problem in under 1 hours...', '2026-08-18 18:00:46'),
(13, 13, 1, 'Progress', '2026-08-18 18:14:02'),
(14, 14, 1, 'all Done!', '2026-09-06 12:28:54');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `department_name`, `description`) VALUES
(1, 'Roads & Transport Department', 'Handles potholes, broken roads, and footpaths'),
(2, 'Water Supply Department', 'Handles water leakage, pressure issues, and pipeline breaks'),
(3, 'Sanitation & Solid Waste', 'Handles garbage overflow, illegal dumping, and street cleaning'),
(4, 'Electrical & Street Lights', 'Handles faulty streetlights and open electrical hazards'),
(5, 'Drainage & Sewage', 'Handles water logging and blocked municipal drains');

-- --------------------------------------------------------

--
-- Table structure for table `officers`
--

CREATE TABLE `officers` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `badge_number` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `officers`
--

INSERT INTO `officers` (`id`, `department_id`, `full_name`, `email`, `badge_number`, `password`, `created_at`) VALUES
(1, 1, 'Mr. Vikram Singh', 'vikram.jmc@nn.gov.in', 'JMC-NN-RT-01', 'secure@123', '2026-07-09 07:45:07'),
(2, 2, 'Mr. Jagat Maheta', 'Jagat.jmc@nn.gov.in', 'JMC-NN-WS-02', 'Jagat@nnw', '2026-07-12 12:23:16'),
(3, 3, 'Ms. Vanita Dasani', 'vanita.jmc@nn.gov.in', 'JMC-NN-SW-03', 'Vanita@nnec', '2026-07-14 07:40:14'),
(4, 4, 'Ms. Kavya Ahir', 'kavya.jmc@nn.gov.in', 'JMC-NN-ES-04', 'Kavya@NNES', '2026-08-18 17:16:44');

-- --------------------------------------------------------

--
-- Table structure for table `status_logs`
--

CREATE TABLE `status_logs` (
  `id` int(11) NOT NULL,
  `complaint_id` int(11) NOT NULL,
  `old_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) NOT NULL,
  `changed_by` varchar(100) NOT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `status_logs`
--

INSERT INTO `status_logs` (`id`, `complaint_id`, `old_status`, `new_status`, `changed_by`, `changed_at`) VALUES
(2, 1, 'Pending', 'In Progress', 'Insp. Vikram Singh', '2026-07-09 07:56:47'),
(3, 1, 'In Progress', 'Resolved', 'Insp. Vikram Singh', '2026-07-09 07:59:32'),
(4, 2, 'Pending', 'Resolved', 'Insp. Vikram Singh', '2026-07-12 12:28:29'),
(5, 2, 'Pending', 'Resolved', 'Insp. Vikram Singh', '2026-07-12 12:28:29'),
(6, 3, 'Pending', 'In Progress', 'Mr. Jagat Maheta', '2026-07-13 14:00:08'),
(7, 4, 'In Progress', 'Resolved', 'Ms. Vanita Dasani', '2026-07-15 06:20:43'),
(8, 5, 'In Progress', 'Resolved', 'Ms. Vanita Dasani', '2026-07-15 06:24:13'),
(9, 6, NULL, 'Pending', 'Citizen #8', '2026-08-04 11:49:43'),
(10, 7, NULL, 'Pending', 'Citizen #10', '2026-08-04 12:14:35'),
(11, 8, NULL, 'Pending', 'Citizen #10', '2026-08-17 17:39:04'),
(12, 9, NULL, 'Pending', 'Citizen #8', '2026-08-17 17:44:30'),
(13, 7, 'In Progress', 'Resolved', 'Ms. Vanita Dasani', '2026-08-17 17:46:00'),
(14, 9, 'Pending', 'In Progress', 'Ms. Vanita Dasani', '2026-08-17 17:54:04'),
(15, 9, 'In Progress', 'Resolved', 'Ms. Vanita Dasani', '2026-08-17 17:55:13'),
(16, 6, 'In Progress', 'Pending', 'Mr. Jagat Maheta', '2026-08-18 14:26:43'),
(17, 6, 'Pending', 'In Progress', 'Mr. Jagat Maheta', '2026-08-18 14:36:05'),
(19, 11, NULL, 'Pending', 'Citizen #6', '2026-08-18 17:34:45'),
(20, 11, 'Pending', 'Resolved', 'Ms. Kavya Ahir', '2026-08-18 17:42:48'),
(21, 12, NULL, 'Pending', 'Citizen #12', '2026-08-18 17:53:22'),
(22, 12, 'Pending', 'Resolved', 'Ms. Kavya Ahir', '2026-08-18 18:00:46'),
(23, 13, NULL, 'Pending', 'Citizen #7', '2026-08-18 18:10:08'),
(24, 13, 'Pending', 'In Progress', 'Mr. Vikram Singh', '2026-08-18 18:14:02'),
(25, 13, 'In Progress', 'Resolved', 'Mr. Vikram Singh', '2026-08-18 18:15:21'),
(26, 13, 'Resolved', 'In Progress', 'Mr. Vikram Singh', '2026-08-18 18:15:52'),
(27, 14, NULL, 'Pending', 'Citizen #13', '2026-09-06 12:26:50'),
(28, 14, 'Pending', 'In Progress', 'Mr. Vikram Singh', '2026-09-06 12:28:54'),
(29, 14, 'In Progress', 'Resolved', 'Mr. Vikram Singh', '2026-09-06 12:32:53'),
(30, 14, 'Resolved', 'In Progress', 'Mr. Vikram Singh', '2026-09-06 12:36:22'),
(31, 14, 'In Progress', 'Resolved', 'Mr. Vikram Singh', '2026-09-06 13:51:51'),
(32, 15, NULL, 'Pending', 'Citizen #15', '2026-09-14 17:24:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `house_no` varchar(50) DEFAULT NULL,
  `area` varchar(150) DEFAULT NULL,
  `ward` varchar(50) DEFAULT NULL,
  `pincode` varchar(6) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `mobile`, `email`, `house_no`, `area`, `ward`, `pincode`, `photo`, `password`, `created_at`) VALUES
(1, 'Vikas h. gupta', '9876543210', 'vikas23@gmail.com', 'G-15', '54, Digvijay plot', 'w11', '361002', NULL, 'Vikas@123', '2026-06-29 07:04:52'),
(2, 'Vishal j. trivedi', '8576498321', 'vishal76@gmail.com', 'E-06', 'patel colony,2', 'w8', '361005', NULL, 'Vishal@345', '2026-06-29 07:14:14'),
(4, 'smruti k. jain', '9874123456', 'smruti564@gmail.com', '104', '54, Digvijay plot', 'w11', '361002', NULL, 'Smruti$123', '2026-06-29 12:03:03'),
(5, 'Star S. star', '9895642314', 'star17@gmail.com', '101', 'vikas nagar', 'w6', '361004', NULL, 'Star@123', '2026-07-09 06:44:57'),
(6, 'Diya e. patel', '9587566472', 'diya45@gmail.com', 'B-202', 'patel colony,2', 'w8', '361003', '20260709145804_6343845.jpg', 'Diya$123', '2026-07-09 09:28:04'),
(7, 'priti p. parekh', '9547122475', 'pritiparekh20@gmail.com', '225/20', 'patel colony,3', 'Ward No. 8', '361002', '', 'Priti@123', '2026-08-03 15:21:44'),
(8, 'mulrajsinh a parmar', '9687454224', 'mulrajsinh23@gmail.com', 'C-202', '54, Digvijay plot', 'Ward No. 11', '361003', '1785770897_person.png', 'Mulraj$123', '2026-08-03 15:28:17'),
(10, 'Vansh k vora', '9754821647', 'vansh12@gmai.com', 'E-25', 'Refinery arer', 'Ward No. 14', '361005', '1785845446_photo.png', 'Vansh#09', '2026-08-04 12:10:46'),
(12, 'Divtarajsinh a. gohil', '9563482135', 'divyaraj579@gmail.com', 'A-501', 'vrundavan Park-1,Gulabngara', 'Ward No. 11', '361120', '', 'Divyaraj#123', '2026-08-18 17:50:22'),
(13, 'Vir', '9876543210', 'vir12star@gmail.com', '222/22', 'Hapa railway station', 'Ward No. 11', '361120', '1788697048_1000293554.jpg', 'Vir@12', '2026-09-06 12:17:28'),
(15, 'Vikrant A. pathak', '9684542127', 'vikrant20@gmail.com', 'C-102', 'park colony, road no-5', 'Ward No. 5', '361007', '1789394274_person.png', 'Vikrant@34', '2026-09-14 13:57:54'),
(16, 'Sonal k monani', '9787341245', 'sonal10@gmail.com', '10', 'rameshwarnagar - 5', 'Ward No. 2', '361003', '1789395393_photo.png', 'Sonal$00', '2026-09-14 14:16:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `complaint_assignments`
--
ALTER TABLE `complaint_assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `complaint_id` (`complaint_id`),
  ADD KEY `officer_id` (`officer_id`);

--
-- Indexes for table `complaint_remarks`
--
ALTER TABLE `complaint_remarks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `complaint_id` (`complaint_id`),
  ADD KEY `officer_id` (`officer_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `officers`
--
ALTER TABLE `officers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `badge_number` (`badge_number`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `status_logs`
--
ALTER TABLE `status_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `complaint_id` (`complaint_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `complaint_assignments`
--
ALTER TABLE `complaint_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `complaint_remarks`
--
ALTER TABLE `complaint_remarks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `officers`
--
ALTER TABLE `officers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `status_logs`
--
ALTER TABLE `status_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `complaints_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `complaint_assignments`
--
ALTER TABLE `complaint_assignments`
  ADD CONSTRAINT `complaint_assignments_ibfk_1` FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `complaint_assignments_ibfk_2` FOREIGN KEY (`officer_id`) REFERENCES `officers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `complaint_remarks`
--
ALTER TABLE `complaint_remarks`
  ADD CONSTRAINT `complaint_remarks_ibfk_1` FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `complaint_remarks_ibfk_2` FOREIGN KEY (`officer_id`) REFERENCES `officers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `officers`
--
ALTER TABLE `officers`
  ADD CONSTRAINT `officers_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `status_logs`
--
ALTER TABLE `status_logs`
  ADD CONSTRAINT `status_logs_ibfk_1` FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

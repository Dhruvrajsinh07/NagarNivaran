<?php

require_once("includes/mail_config.php");

$testEmail = "vir12star@gmail.com";

$sent = sendComplaintStatusEmail(
    $testEmail,
    "Test Citizen",
    9999,
    "Test Civic Complaint",
    "In Progress",
    "Test Officer"
);

if ($sent) {
    echo "<h2 style='color:green;'>✅ Test email sent successfully!</h2>";
    echo "<p>Check the inbox of: " . htmlspecialchars($testEmail) . "</p>";
} else {
    echo "<h2 style='color:red;'>❌ Email could not be sent.</h2>";
    echo "<p>Check your SMTP configuration and PHPMailer setup.</p>";
}
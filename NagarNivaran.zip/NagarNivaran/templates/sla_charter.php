<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SLA Charter | NagarNivaran</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Premium Fonts: Plus Jakarta Sans, Outfit, Courier Prime, Hind Vadodara, Mukta Vaani -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;700;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Courier+Prime:wght@400;700&family=Hind+Vadodara:wght@500;600;700&family=Mukta+Vaani:wght@400;500;700&display=swap" rel="stylesheet">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'saffron': '#FF9933',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                        'ink': '#0F172A',
                    },
                    fontFamily: {
                        heading: ['"Outfit"', 'sans-serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        mono: ['"Courier Prime"', 'monospace'],
                        'gu-heading': ['"Hind Vadodara"', 'sans-serif'],
                        'gu-body': ['"Mukta Vaani"', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    
    <style>
        body { background-color: #F8FAFC; }
        
        /* Orange Cross Pattern Background */
        .bg-cross-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }

        /* Table Styling */
        .sla-table th { background-color: #F8FAFC; border-bottom: 2px solid #E2E8F0; }
        .sla-table td { border-bottom: 1px solid #F1F5F9; }
        .sla-table tr:last-child td { border-bottom: none; }

        /* Language Toggle Classes */
        body.lang-gu .en-text { display: none !important; }
        body.lang-gu .gu-text { display: block !important; }
        body.lang-gu .gu-inline { display: inline !important; }
        
        body.lang-en .gu-text { display: none !important; }
        body.lang-en .gu-inline { display: none !important; }
        body.lang-en .en-text { display: block !important; }
        body.lang-en .en-inline { display: inline !important; }

        .gu-inline, .en-inline { display: none; } /* Default hide inline spans */
    </style>
</head>

<body class="lang-gu py-6 sm:py-10 px-4 text-slate-800 font-sans selection:bg-orange-glow selection:text-white relative min-h-screen">

    <!-- Background Pattern -->
    <div class="fixed inset-0 -z-20 bg-cross-pattern pointer-events-none"></div>

    <!-- Mobile Responsive Toolbar -->
    <div class="max-w-4xl mx-auto mb-6 flex flex-col sm:flex-row justify-between items-center gap-4 relative z-10">
        
        <a href="../index.php" class="w-full sm:w-auto justify-center text-sm font-bold text-slate-600 hover:text-orange-glow transition-colors flex items-center gap-2 bg-white px-5 py-3 rounded-xl shadow-sm border border-slate-200">
            <i class="fa-solid fa-arrow-left"></i> 
            <span class="en-inline">Back to Portal</span>
            <span class="gu-inline font-gu-body font-bold">પોર્ટલ પર પાછા જાઓ</span>
        </a>
        
        <!-- Language Toggle (Stretches on Mobile) -->
        <div class="w-full sm:w-auto bg-white border border-slate-200 p-1.5 rounded-xl shadow-sm flex font-bold text-sm">
            <button onclick="setLanguage('en')" id="btn-en" class="flex-1 sm:flex-none px-6 py-2 rounded-lg text-slate-500 hover:text-slate-800 transition-colors">English</button>
            <button onclick="setLanguage('gu')" id="btn-gu" class="flex-1 sm:flex-none px-6 py-2 rounded-lg bg-orange-glow text-white shadow-sm transition-colors">ગુજરાતી</button>
        </div>

    </div>

    <!-- A4 Document Sheet -->
    <div class="max-w-4xl mx-auto bg-white shadow-2xl rounded-2xl overflow-hidden border border-slate-200 relative z-10">
        
        <!-- Header Ribbon -->
        <div class="h-2 w-full bg-gradient-to-r from-orange-glow to-tomato"></div>
        
        <div class="p-6 sm:p-10 md:p-14">
            
            <!-- Branding Header -->
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b-2 border-slate-100 pb-6 mb-8 sm:mb-10 gap-4">
                <div class="flex items-center gap-4">
                    <img src="../assets/imgs/nn-final.png" onerror="this.src='https://placehold.co/60x60/FF7A00/FFF?text=JMC'" class="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-2 border-orange-glow object-cover shrink-0">
                    <div>
                        <h1 class="font-heading font-black text-2xl sm:text-3xl text-ink tracking-tight">Nagar<span class="text-orange-glow">Nivaran</span></h1>
                        <p class="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1 en-text">Official Service Agreement</p>
                        <p class="text-sm font-bold text-slate-500 mt-1 gu-text font-gu-heading">અધિકૃત સેવા કરાર</p>
                    </div>
                </div>
                <div class="text-left sm:text-right w-full sm:w-auto bg-slate-50 sm:bg-transparent p-3 sm:p-0 rounded-lg sm:rounded-none">
                    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Document Ref</p>
                    <p class="font-mono text-sm font-bold text-ink sm:bg-slate-50 sm:border sm:border-slate-200 sm:px-2 sm:py-1 rounded mt-1">JMC-SLA-CHTR-01</p>
                </div>
            </div>

            <!-- Introduction -->
            <div class="mb-10">
                <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">What is an SLA Charter?</h2>
                <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">SLA ચાર્ટર શું છે?</h2>
                
                <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                    An SLA (Service Level Agreement) Charter is a formal document that defines the service standards and expected response/resolution times between a service provider and its users. NagarNivaran is a centralized Civic Issue Reporting System engineered to digitize municipal complaint management. This charter dictates exactly how quickly the Jamnagar Municipal Corporation - JMC will acknowledge, assign, respond to, and resolve various types of civic complaints.
                </p>
                <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                    SLA (સર્વિસ લેવલ એગ્રીમેન્ટ) ચાર્ટર એક ઔપચારિક દસ્તાવેજ છે જે સેવા પ્રદાતા અને તેના વપરાશકર્તાઓ વચ્ચે સેવાના ધોરણો અને અપેક્ષિત પ્રતિસાદ/ઉકેલના સમયને વ્યાખ્યાયિત કરે છે. નગરનિવારણ એ મ્યુનિસિપલ ફરિયાદ વ્યવસ્થાપનને ડિજિટલ બનાવવા માટે રચાયેલ કેન્દ્રીય સિસ્ટમ છે (Civic Issue Reporting System). આ ચાર્ટર સ્પષ્ટ કરે છે કે જામનગર મહાનગરપાલિકા (JMC) કેટલી ઝડપથી વિવિધ પ્રકારની નાગરિક ફરિયાદોને સ્વીકારશે, સોંપશે, પ્રતિસાદ આપશે અને ઉકેલશે.
                </p>
            </div>

            <!-- Lifecycle Workflow -->
            <div class="mb-12">
                <h3 class="font-heading text-base sm:text-lg text-slate-900 font-extrabold mb-5 uppercase tracking-wider text-center text-slate-400 en-text">Standard Resolution Lifecycle</h3>
                <h3 class="font-gu-heading text-lg sm:text-xl text-slate-900 font-bold mb-5 tracking-wide text-center text-slate-400 gu-text">પ્રમાણભૂત ઉકેલ જીવનચક્ર</h3>
                
                <div class="flex flex-col sm:flex-row items-center justify-between bg-slate-50 p-6 rounded-2xl border border-slate-100 relative">
                    <!-- Step 1 -->
                    <div class="text-center z-10 w-full sm:w-1/4 mb-6 sm:mb-0 relative">
                        <div class="w-12 h-12 mx-auto bg-white border border-slate-200 rounded-full flex items-center justify-center text-orange-glow shadow-sm mb-2">
                            <i class="fa-solid fa-user-pen text-lg"></i>
                        </div>
                        <p class="text-[11px] font-bold text-slate-700 uppercase tracking-wider en-text">Citizen Reports</p>
                        <p class="text-[13px] font-bold text-slate-700 font-gu-heading gu-text mt-1">નાગરિક ફરિયાદ કરે છે</p>
                        <div class="sm:hidden absolute -bottom-5 left-1/2 -translate-x-1/2 text-slate-300"><i class="fa-solid fa-chevron-down"></i></div>
                    </div>
                    
                    <!-- Arrow -->
                    <div class="hidden sm:block text-slate-300"><i class="fa-solid fa-chevron-right"></i></div>
                    
                    <!-- Step 2 -->
                    <div class="text-center z-10 w-full sm:w-1/4 mb-6 sm:mb-0 relative">
                        <div class="w-12 h-12 mx-auto bg-white border border-slate-200 rounded-full flex items-center justify-center text-blue-500 shadow-sm mb-2">
                            <i class="fa-solid fa-microchip text-lg"></i>
                        </div>
                        <p class="text-[11px] font-bold text-slate-700 uppercase tracking-wider en-text">System Records Priority</p>
                        <p class="text-[13px] font-bold text-slate-700 font-gu-heading gu-text mt-1">સિસ્ટમ પ્રાથમિકતા નોંધે છે</p>
                        <div class="sm:hidden absolute -bottom-5 left-1/2 -translate-x-1/2 text-slate-300"><i class="fa-solid fa-chevron-down"></i></div>
                    </div>

                    <!-- Arrow -->
                    <div class="hidden sm:block text-slate-300"><i class="fa-solid fa-chevron-right"></i></div>

                    <!-- Step 3 -->
                    <div class="text-center z-10 w-full sm:w-1/4 mb-6 sm:mb-0 relative">
                        <div class="w-12 h-12 mx-auto bg-white border border-slate-200 rounded-full flex items-center justify-center text-tomato shadow-sm mb-2">
                            <i class="fa-solid fa-helmet-safety text-lg"></i>
                        </div>
                        <p class="text-[11px] font-bold text-slate-700 uppercase tracking-wider en-text">Authority Handles via SLA</p>
                        <p class="text-[13px] font-bold text-slate-700 font-gu-heading gu-text mt-1">સત્તાધિકારી SLA મુજબ કાર્યવાહી કરે છે</p>
                        <div class="sm:hidden absolute -bottom-5 left-1/2 -translate-x-1/2 text-slate-300"><i class="fa-solid fa-chevron-down"></i></div>
                    </div>

                    <!-- Arrow -->
                    <div class="hidden sm:block text-slate-300"><i class="fa-solid fa-chevron-right"></i></div>

                    <!-- Step 4 -->
                    <div class="text-center z-10 w-full sm:w-1/4">
                        <div class="w-12 h-12 mx-auto bg-white border border-slate-200 rounded-full flex items-center justify-center text-emerald-500 shadow-sm mb-2">
                            <i class="fa-solid fa-check-double text-lg"></i>
                        </div>
                        <p class="text-[11px] font-bold text-slate-700 uppercase tracking-wider en-text">Status Updated</p>
                        <p class="text-[13px] font-bold text-slate-700 font-gu-heading gu-text mt-1">સ્થિતિ અપડેટ થાય છે</p>
                    </div>
                </div>
            </div>

            <!-- SLA Matrix Table -->
            <div class="mb-10">
                <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-4 border-l-4 border-orange-glow pl-3 en-text">NagarNivaran Resolution Matrix</h2>
                <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-4 border-l-4 border-orange-glow pl-3 gu-text">નગરનિવારણ ઉકેલ મેટ્રિક્સ</h2>
                
                <div class="overflow-x-auto rounded-xl border border-slate-200 shadow-sm">
                    <table class="w-full text-left sla-table whitespace-nowrap min-w-[650px]">
                        <thead>
                            <tr>
                                <th class="py-4 px-4 sm:px-6 text-xs font-bold text-slate-500 uppercase tracking-widest">
                                    <span class="en-inline">Priority</span>
                                    <span class="gu-inline font-gu-heading text-sm text-slate-600">પ્રાથમિકતા</span>
                                </th>
                                <th class="py-4 px-4 sm:px-6 text-xs font-bold text-slate-500 uppercase tracking-widest">
                                    <span class="en-inline">Example Issue</span>
                                    <span class="gu-inline font-gu-heading text-sm text-slate-600">ઉદાહરણ સમસ્યા</span>
                                </th>
                                <th class="py-4 px-4 sm:px-6 text-xs font-bold text-slate-500 uppercase tracking-widest">
                                    <span class="en-inline">Expected Response</span>
                                    <span class="gu-inline font-gu-heading text-sm text-slate-600">અપેક્ષિત પ્રતિસાદ</span>
                                </th>
                                <th class="py-4 px-4 sm:px-6 text-xs font-bold text-slate-500 uppercase tracking-widest">
                                    <span class="en-inline">Target Resolution</span>
                                    <span class="gu-inline font-gu-heading text-sm text-slate-600">લક્ષ્ય ઉકેલ</span>
                                </th>
                            </tr>
                        </thead>
                        <tbody class="text-sm font-medium">
                            
                            <!-- Critical -->
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="py-5 px-4 sm:px-6">
                                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-red-50 text-red-700 border border-red-100 text-[11px] font-bold uppercase tracking-wider">
                                        <span class="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse"></span> 
                                        <span class="en-inline">Critical</span>
                                        <span class="gu-inline font-gu-body text-[13px] font-bold tracking-normal">ગંભીર</span>
                                    </span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 text-slate-700">
                                    <span class="en-text">Major public safety issue</span>
                                    <span class="gu-text font-gu-body text-sm">જાહેર સલામતીની મોટી સમસ્યા</span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 font-bold text-ink">
                                    <span class="en-inline">1 Hour</span>
                                    <span class="gu-inline font-gu-body tracking-normal">૧ કલાક</span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 font-bold text-ink">
                                    <span class="en-inline">4–8 Hours</span>
                                    <span class="gu-inline font-gu-body tracking-normal">૪-૮ કલાક</span>
                                </td>
                            </tr>

                            <!-- High -->
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="py-5 px-4 sm:px-6">
                                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-orange-50 text-orange-800 border border-orange-100 text-[11px] font-bold uppercase tracking-wider">
                                        <span class="w-1.5 h-1.5 rounded-full bg-orange-500"></span> 
                                        <span class="en-inline">High</span>
                                        <span class="gu-inline font-gu-body text-[13px] font-bold tracking-normal">વધુ</span>
                                    </span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 text-slate-700">
                                    <span class="en-text">Serious road/water problem</span>
                                    <span class="gu-text font-gu-body text-sm">રસ્તા/પાણીની ગંભીર સમસ્યા</span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 font-bold text-ink">
                                    <span class="en-inline">4 Hours</span>
                                    <span class="gu-inline font-gu-body tracking-normal">૪ કલાક</span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 font-bold text-ink">
                                    <span class="en-inline">24 Hours</span>
                                    <span class="gu-inline font-gu-body tracking-normal">૨૪ કલાક</span>
                                </td>
                            </tr>

                            <!-- Medium -->
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="py-5 px-4 sm:px-6">
                                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-amber-50 text-amber-700 border border-amber-100 text-[11px] font-bold uppercase tracking-wider">
                                        <span class="w-1.5 h-1.5 rounded-full bg-orange-glow"></span> 
                                        <span class="en-inline">Medium</span>
                                        <span class="gu-inline font-gu-body text-[13px] font-bold tracking-normal">મધ્યમ</span>
                                    </span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 text-slate-700">
                                    <span class="en-text">Streetlight, garbage, drainage</span>
                                    <span class="gu-text font-gu-body text-sm">સ્ટ્રીટલાઈટ, કચરો, ગટર</span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 font-bold text-ink">
                                    <span class="en-inline">1 Day</span>
                                    <span class="gu-inline font-gu-body tracking-normal">૧ દિવસ</span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 font-bold text-ink">
                                    <span class="en-inline">2–3 Days</span>
                                    <span class="gu-inline font-gu-body tracking-normal">૨-૩ દિવસ</span>
                                </td>
                            </tr>

                            <!-- Low -->
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="py-5 px-4 sm:px-6">
                                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-100 text-[11px] font-bold uppercase tracking-wider">
                                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> 
                                        <span class="en-inline">Low</span>
                                        <span class="gu-inline font-gu-body text-[13px] font-bold tracking-normal">ઓછું</span>
                                    </span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 text-slate-700">
                                    <span class="en-text">Minor civic issue</span>
                                    <span class="gu-text font-gu-body text-sm">સામાન્ય નાગરિક સમસ્યા</span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 font-bold text-ink">
                                    <span class="en-inline">2 Days</span>
                                    <span class="gu-inline font-gu-body tracking-normal">૨ દિવસ</span>
                                </td>
                                <td class="py-5 px-4 sm:px-6 font-bold text-ink">
                                    <span class="en-inline">5–7 Days</span>
                                    <span class="gu-inline font-gu-body tracking-normal">૫-૭ દિવસ</span>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>

            <div class="mt-8 bg-blue-50 p-4 sm:p-5 rounded-xl border border-blue-100 flex items-start gap-3">
                <i class="fa-solid fa-circle-info text-blue-500 mt-0.5"></i>
                <div class="text-xs sm:text-sm text-blue-800 font-medium leading-relaxed">
                    <p class="en-text">
                        <strong>Note:</strong> Response time indicates the maximum allowable time for a nodal officer to officially assign the issue to a field unit (moving from "Pending" to "In Progress"). Resolution time indicates the deadline to completely resolve the physical defect on the ground.
                    </p>
                    <p class="gu-text font-gu-body text-sm">
                        <strong class="font-gu-heading">નોંધ:</strong> પ્રતિસાદ સમય એ નોડલ અધિકારી માટે સમસ્યાને સત્તાવાર રીતે ફીલ્ડ યુનિટને સોંપવા માટેનો મહત્તમ સ્વીકાર્ય સમય દર્શાવે છે ("પેન્ડિંગ" થી "ઇન પ્રોગ્રેસ" સુધી). ઉકેલ સમય એ જમીન પરની ભૌતિક ખામીને સંપૂર્ણપણે ઉકેલવા માટેની અંતિમ સમયમર્યાદા દર્શાવે છે.
                    </p>
                </div>
            </div>

            <!-- Footer Note -->
            <div class="border-t-2 border-dashed border-slate-200 pt-6 mt-12 flex flex-col sm:flex-row justify-between items-center gap-2 sm:gap-4 text-[10px] sm:text-xs font-mono text-slate-500 text-center sm:text-left">
                <p class="en-text">JMC • Integrated Command & Control Center</p>
                <p class="gu-text font-gu-body text-xs sm:text-sm font-bold">જામનગર મહાનગરપાલિકા • ઇન્ટિગ્રેટેડ કમાન્ડ એન્ડ કંટ્રોલ સેન્ટર</p>
                <p class="font-bold text-slate-400">© 2026 Jamnagar Smart City</p>
            </div>
            
        </div>
    </div>

    <!-- JavaScript for Language Toggle -->
    <script>
        function setLanguage(lang) {
            const body = document.body;
            const btnEn = document.getElementById('btn-en');
            const btnGu = document.getElementById('btn-gu');

            if (lang === 'en') {
                body.classList.remove('lang-gu');
                body.classList.add('lang-en');
                
                // Style buttons
                btnEn.classList.add('bg-orange-glow', 'text-white');
                btnEn.classList.remove('text-slate-500');
                
                btnGu.classList.remove('bg-orange-glow', 'text-white');
                btnGu.classList.add('text-slate-500');
            } else {
                body.classList.remove('lang-en');
                body.classList.add('lang-gu');
                
                // Style buttons
                btnGu.classList.add('bg-orange-glow', 'text-white');
                btnGu.classList.remove('text-slate-500');
                
                btnEn.classList.remove('bg-orange-glow', 'text-white');
                btnEn.classList.add('text-slate-500');
            }
        }
    </script>
</body>
</html>
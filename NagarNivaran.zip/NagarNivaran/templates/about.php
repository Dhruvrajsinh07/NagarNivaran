<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>About NagarNivaran | Civic Grievance Platform</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <!-- Google Font -->
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@500;600;700;800;900&family=Hind+Vadodara:wght@500;600;700&display=swap"
        rel="stylesheet"
    >

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                    },
                    fontFamily: {
                        heading: ['"Plus Jakarta Sans"', 'sans-serif'],
                        sans: ['"Inter"', 'sans-serif'],
                        gujarati: ['"Hind Vadodara"', 'sans-serif'],
                    }
                }
            }
        }
    </script>

    <style>
        * {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Inter', sans-serif;
        }

        /* Orange Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #F1F5F9;
        }
        ::-webkit-scrollbar-thumb {
            background: #FF7A00;
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #FF6347;
        }

        .heading-font {
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        /* Background Cross Pattern with 0.3 opacity */
        .bg-cross-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }

        /* Float Animation */
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-8px); }
        }
        .animate-float {
            animation: float 5s ease-in-out infinite;
        }

        /* Flash Effect on Hover for Nav Pill Indicator */
        .pill-flash {
            position: relative;
            overflow: hidden;
        }
        .pill-flash::after {
            content: '';
            position: absolute;
            top: 0;
            left: -120%;
            width: 70%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.75), transparent);
            transform: skewX(-20deg);
            pointer-events: none;
        }
        .trigger-flash::after {
            animation: navFlash 0.55s ease-in-out forwards;
        }
        @keyframes navFlash {
            0% { left: -120%; }
            100% { left: 160%; }
        }

        .soft-card {
            transition: all 0.3s ease;
        }

        .soft-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.08);
        }

        .timeline-line {
            background: linear-gradient(
                to bottom,
                #FF7A00,
                #FF6347,
                #cbd5e1
            );
        }
    </style>
</head>

<body class="bg-slate-50 text-slate-800 relative selection:bg-orange-500 selection:text-white">

<!-- Cross "+" Pattern with 0.3 opacity -->
<div class="fixed inset-0 -z-20 bg-cross-pattern pointer-events-none"></div>

<!-- =========================================================
     CENTER STAGE LOGO & TITLE HEADER
========================================================= -->
<header class="pt-8 sm:pt-12 pb-4 sm:pb-6 flex flex-col items-center justify-center relative z-40 text-center px-4">
    <div class="w-[110px] h-[110px] sm:w-[150px] sm:h-[150px] rounded-full bg-white shadow-lg border-4 border-orange-glow flex items-center justify-center overflow-hidden mb-4 sm:mb-5 relative group z-10 animate-float">
        <img src="../assets/imgs/nn-final.png" alt="NagarNivaran Logo" onerror="this.src='https://placehold.co/150x150/FF7A00/FFFFFF?text=NN'" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
    </div>
    <h1 class="font-heading text-4xl sm:text-6xl font-black tracking-tight text-slate-900">
        Nagar<span class="bg-gradient-to-r from-orange-glow to-tomato bg-clip-text text-transparent">Nivaran</span>
    </h1>
    <p class="font-gujarati text-slate-600 text-base sm:text-lg mt-1 sm:mt-2 font-medium">Civic Grievance Platform</p>
</header>

<!-- =========================================================
     STICKY NAVIGATION BAR (Refined Hover Size + Flash Effect + Mobile Responsive)
========================================================= -->
<div class="sticky top-4 z-50 max-w-5xl mx-auto px-4 mb-8">
    <nav class="bg-white/90 backdrop-blur-xl border border-slate-200/90 rounded-2xl md:rounded-full p-2.5 sm:p-2 shadow-xl shadow-slate-900/5">
        
        <div class="flex items-center justify-between gap-3">
            <!-- Back to Home Page Button -->
            <a href="../index.php" class="inline-flex items-center gap-2 bg-slate-900 text-white px-4 sm:px-5 py-2 sm:py-2.5 rounded-full font-bold text-xs sm:text-sm hover:bg-orange-500 transition-colors shadow-sm shrink-0">
                <i class="fa-solid fa-arrow-left"></i>
                <span>Back to Home</span>
            </a>

            <!-- Sliding Pill Navigation Group (Desktop) -->
            <div id="nav-pill-group" class="hidden md:inline-flex items-center relative bg-orange-400 p-1.5 rounded-full border border-orange-300/80 shadow-inner">
                
                <!-- Pill Indicator sized and rounded to match buttons with flash effect -->
                <div id="pill-indicator" class="pill-flash absolute rounded-full bg-orange-100 transition-all duration-300 ease-out z-0 shadow-sm pointer-events-none"></div>
                
                <a href="#about" class="nav-item relative z-10 px-5 py-2 rounded-full font-bold text-sm transition-colors duration-200 text-slate-900 active-link">About</a>
                <a href="#how-it-works" class="nav-item relative z-10 px-5 py-2 rounded-full font-bold text-sm transition-colors duration-200 text-white hover:text-slate-900">How It Works</a>
                <a href="#departments" class="nav-item relative z-10 px-5 py-2 rounded-full font-bold text-sm transition-colors duration-200 text-white hover:text-slate-900">Departments</a>
                <a href="#contacts" class="nav-item relative z-10 px-5 py-2 rounded-full font-bold text-sm transition-colors duration-200 text-white hover:text-slate-900">Team & Contact</a>
            </div>

            <!-- Mobile Menu Toggle Button -->
            <button id="mobileMenuBtn" class="md:hidden w-10 h-10 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center text-base border border-orange-200 focus:outline-none shrink-0" aria-label="Toggle Menu">
                <i class="fa-solid fa-bars" id="menuIcon"></i>
            </button>

            <!-- Quick Info Link / Badge (Desktop) -->
            <a href="#about" class="hidden lg:inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-50 border border-orange-200/70 px-4 py-2 rounded-full shrink-0">
                <span class="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
                Overview
            </a>
        </div>

        <!-- Mobile Expandable Dropdown -->
        <div id="mobileMenu" class="hidden md:hidden pt-3 mt-2 border-t border-slate-100 flex flex-col gap-1">
            <a href="#about" class="mobile-nav-link px-4 py-2.5 rounded-xl font-bold text-sm text-slate-800 hover:bg-orange-50 hover:text-orange-600 transition-colors">About</a>
            <a href="#how-it-works" class="mobile-nav-link px-4 py-2.5 rounded-xl font-bold text-sm text-slate-800 hover:bg-orange-50 hover:text-orange-600 transition-colors">How It Works</a>
            <a href="#departments" class="mobile-nav-link px-4 py-2.5 rounded-xl font-bold text-sm text-slate-800 hover:bg-orange-50 hover:text-orange-600 transition-colors">Departments</a>
            <a href="#contacts" class="mobile-nav-link px-4 py-2.5 rounded-xl font-bold text-sm text-slate-800 hover:bg-orange-50 hover:text-orange-600 transition-colors">Team & Contact</a>
        </div>
    </nav>
</div>


<!-- =========================================================
     HERO (With Right-Side Image Option)
========================================================= -->

<section id="about" class="relative overflow-hidden bg-white/60 backdrop-blur-sm border-b border-slate-200/60">

    <div class="absolute -top-32 -right-32 w-96 h-96 bg-orange-100 rounded-full blur-3xl opacity-60"></div>
    <div class="absolute -bottom-40 -left-40 w-96 h-96 bg-slate-100 rounded-full blur-3xl"></div>

    <div class="relative max-w-7xl mx-auto px-6 lg:px-8 py-12 sm:py-16 lg:py-24">

        <div class="grid lg:grid-cols-12 gap-10 lg:gap-12 items-center">

            <!-- Left Content Column -->
            <div class="lg:col-span-7">

                <!-- Small label -->
                <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-orange-50 border border-orange-100 text-orange-600 text-xs font-bold uppercase tracking-wider mb-6">
                    <span class="w-2 h-2 bg-orange-500 rounded-full"></span>
                    About NagarNivaran
                </div>

                <!-- Heading -->
                <h2 class="heading-font text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.15] sm:leading-[1.08]">
                    A simpler way to
                    <span class="text-orange-500">speak up</span>
                    about civic issues.
                </h2>

                <!-- Description -->
                <p class="mt-5 sm:mt-7 max-w-2xl text-sm sm:text-base lg:text-lg text-slate-500 leading-7 sm:leading-8">
                    NagarNivaran is a proposed digital civic grievance platform
                    designed to help citizens report local public issues,
                    follow their complaints, and stay informed about updates
                    from the concerned department.
                </p>

                <!-- Mini stats -->
                <div class="mt-8 sm:mt-10 flex flex-wrap gap-2.5 sm:gap-3">

                    <div class="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 sm:px-4 sm:py-3 shadow-sm">
                        <i class="fa-solid fa-file-circle-plus text-orange-500"></i>
                        <span class="text-xs sm:text-sm font-semibold text-slate-600">
                            Easy Reporting
                        </span>
                    </div>

                    <div class="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 sm:px-4 sm:py-3 shadow-sm">
                        <i class="fa-solid fa-location-dot text-orange-500"></i>
                        <span class="text-xs sm:text-sm font-semibold text-slate-600">
                            Location Based
                        </span>
                    </div>

                    <div class="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 sm:px-4 sm:py-3 shadow-sm">
                        <i class="fa-solid fa-bell text-orange-500"></i>
                        <span class="text-xs sm:text-sm font-semibold text-slate-600">
                            Status Updates
                        </span>
                    </div>

                </div>

            </div>

            <!-- Right-Side Image Option Column -->
            <div class="lg:col-span-5 flex justify-center">
                <div class="relative w-full max-w-sm sm:max-w-md">
                    <div class="absolute -inset-2 bg-gradient-to-r from-orange-glow to-tomato rounded-3xl blur-xl opacity-20 transform -rotate-2"></div>
                    <div class="relative w-full h-[280px] sm:h-[380px] lg:h-[420px] rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-slate-100 group">
                        <img 
                            src="../assets/imgs/active.png" 
                            alt="NagarNivaran Platform Showcase" 
                            class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent flex items-end p-5 sm:p-6">
                            <span class="text-white text-[11px] sm:text-xs font-mono font-bold tracking-wider uppercase bg-white/20 backdrop-blur-md px-3 py-1.5 rounded-lg">
                                Real-Time Civic Monitoring
                            </span>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</section>


<!-- =========================================================
     WHAT THE PLATFORM DOES
========================================================= -->

<section class="py-16 sm:py-20 lg:py-24">

    <div class="max-w-7xl mx-auto px-6 lg:px-8">

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

            <!-- Card 1 -->
            <div class="soft-card bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-sm">
                <div class="w-12 h-12 rounded-2xl bg-orange-50 text-orange-500 flex items-center justify-center mb-6">
                    <i class="fa-solid fa-bullhorn text-lg"></i>
                </div>
                <h3 class="heading-font text-lg sm:text-xl font-extrabold text-slate-900">
                    Report a Problem
                </h3>
                <p class="mt-3 text-sm text-slate-500 leading-6 sm:leading-7">
                    Citizens can report common civic problems such as
                    damaged roads, potholes, garbage, drainage issues,
                    streetlights, water-related concerns, and other
                    public-service issues.
                </p>
            </div>

            <!-- Card 2 -->
            <div class="soft-card bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-sm">
                <div class="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-6">
                    <i class="fa-solid fa-location-crosshairs text-lg"></i>
                </div>
                <h3 class="heading-font text-lg sm:text-xl font-extrabold text-slate-900">
                    Provide Useful Details
                </h3>
                <p class="mt-3 text-sm text-slate-500 leading-6 sm:leading-7">
                    A complaint can include its description, location,
                    priority, and supporting image so that the concerned
                    department has useful information for reviewing
                    the issue.
                </p>
            </div>

            <!-- Card 3 -->
            <div class="soft-card bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-sm md:col-span-2 lg:col-span-1">
                <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-6">
                    <i class="fa-solid fa-chart-line text-lg"></i>
                </div>
                <h3 class="heading-font text-lg sm:text-xl font-extrabold text-slate-900">
                    Track the Progress
                </h3>
                <p class="mt-3 text-sm text-slate-500 leading-6 sm:leading-7">
                    Citizens can follow the current status of their
                    complaints and receive notification when the
                    concerned department makes an official status update.
                </p>
            </div>

        </div>

    </div>

</section>


<!-- =========================================================
     HOW IT WORKS (Alternate Colors & Rounded Square Border)
========================================================= -->

<section id="how-it-works" class="py-16 sm:py-20 lg:py-24 bg-white/70 backdrop-blur-sm border-y border-slate-200/70">

    <div class="max-w-7xl mx-auto px-6 lg:px-8">

        <div class="text-center max-w-2xl mx-auto">

            <!-- "Simple Process" text in rounded square border box -->
            <span class="inline-block border-2 border-orange-500/40 bg-orange-50 text-orange-500 text-xs font-extrabold uppercase tracking-[0.18em] px-4 py-1.5 rounded-xl">
                Simple Process
            </span>

            <h2 class="heading-font mt-4 text-2xl sm:text-4xl font-extrabold text-slate-900">
                From complaint to update
            </h2>

            <p class="mt-3 sm:mt-4 text-sm sm:text-base text-slate-500 leading-6 sm:leading-7">
                NagarNivaran connects citizens with the appropriate
                department through a simple complaint-management flow.
            </p>

        </div>

        <div class="relative max-w-4xl mx-auto mt-12 sm:mt-16">

            <!-- Vertical line -->
            <div class="absolute left-[23px] top-8 bottom-8 w-px timeline-line hidden sm:block"></div>

            <!-- Step 1 (01 Orange) -->
            <div class="relative flex gap-4 sm:gap-6 mb-10 sm:mb-12">
                <div class="relative z-10 shrink-0 w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-[#FF7A00] text-white flex items-center justify-center font-extrabold text-sm sm:text-base shadow-lg shadow-orange-500/20">
                    01
                </div>

                <div class="pt-0.5 sm:pt-1">
                    <h3 class="heading-font text-base sm:text-lg font-extrabold text-slate-900">
                        Citizen reports an issue
                    </h3>
                    <p class="mt-1.5 sm:mt-2 text-xs sm:text-sm text-slate-500 leading-6 sm:leading-7">
                        The citizen submits the civic problem with
                        relevant details, location, priority, and
                        optional supporting evidence.
                    </p>
                </div>
            </div>

            <!-- Step 2 (02 Tomato Red) -->
            <div class="relative flex gap-4 sm:gap-6 mb-10 sm:mb-12">
                <div class="relative z-10 shrink-0 w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-[#FF6347] text-white flex items-center justify-center font-extrabold text-sm sm:text-base shadow-lg shadow-red-500/20">
                    02
                </div>

                <div class="pt-0.5 sm:pt-1">
                    <h3 class="heading-font text-base sm:text-lg font-extrabold text-slate-900">
                        Concerned department reviews it
                    </h3>
                    <p class="mt-1.5 sm:mt-2 text-xs sm:text-sm text-slate-500 leading-6 sm:leading-7">
                        Department officers can review complaints
                        relevant to their department and take
                        appropriate action.
                    </p>
                </div>
            </div>

            <!-- Step 3 (03 Orange) -->
            <div class="relative flex gap-4 sm:gap-6 mb-10 sm:mb-12">
                <div class="relative z-10 shrink-0 w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-[#FF7A00] text-white flex items-center justify-center font-extrabold text-sm sm:text-base shadow-lg shadow-orange-500/20">
                    03
                </div>

                <div class="pt-0.5 sm:pt-1">
                    <h3 class="heading-font text-base sm:text-lg font-extrabold text-slate-900">
                        Status and remarks are updated
                    </h3>
                    <p class="mt-1.5 sm:mt-2 text-xs sm:text-sm text-slate-500 leading-6 sm:leading-7">
                        Officers can update the complaint status and
                        record relevant remarks as the issue progresses.
                    </p>
                </div>
            </div>

            <!-- Step 4 (04 Tomato Red) -->
            <div class="relative flex gap-4 sm:gap-6">
                <div class="relative z-10 shrink-0 w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-[#FF6347] text-white flex items-center justify-center font-extrabold text-sm sm:text-base shadow-lg shadow-red-500/20">
                    04
                </div>

                <div class="pt-0.5 sm:pt-1">
                    <h3 class="heading-font text-base sm:text-lg font-extrabold text-slate-900">
                        Citizen stays informed
                    </h3>
                    <p class="mt-1.5 sm:mt-2 text-xs sm:text-sm text-slate-500 leading-6 sm:leading-7">
                        The citizen can view the latest complaint status
                        and receive a notification when an official
                        status change is made.
                    </p>
                </div>
            </div>

        </div>

    </div>

</section>


<!-- =========================================================
     DEPARTMENT OFFICERS SECTION (5 Cards)
========================================================= -->

<section id="departments" class="py-16 sm:py-20 lg:py-24">

    <div class="max-w-7xl mx-auto px-6 lg:px-8">

        <div class="max-w-2xl mb-10 sm:mb-12">
            <!-- "Assistance & Contact" in square border box -->
            <span class="inline-block border border-orange-500 text-orange-500 text-xs font-extrabold uppercase tracking-[0.18em] px-3.5 py-1.5">
                Assistance & Contact
            </span>

            <h2 class="heading-font mt-4 text-2xl sm:text-4xl font-extrabold text-slate-900">
                Departmental Nodal Desks
            </h2>

            <p class="mt-3 sm:mt-4 text-sm sm:text-base text-slate-500 leading-6 sm:leading-7">
                Direct points of administrative contact across Jamnagar Municipal Corporation nodal divisions.
            </p>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

            <!-- Dept Card 1 -->
            <div class="soft-card bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                <div class="h-2 bg-orange-500"></div>
                <div class="p-6 sm:p-7">
                    <div class="flex items-start justify-between">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-orange-50 text-orange-500 flex items-center justify-center">
                            <i class="fa-solid fa-road text-lg sm:text-xl"></i>
                        </div>
                        <span class="px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 text-[10px] font-extrabold uppercase tracking-wider">
                            Division 01
                        </span>
                    </div>

                    <h3 class="heading-font mt-5 sm:mt-6 text-lg sm:text-xl font-extrabold text-slate-900">
                        Roads & Transport
                    </h3>

                    <p class="mt-2 text-xs sm:text-sm text-slate-500 leading-6">
                        Potholes, road resurfacing, asphalt defects, footpath paving, and transit corridor maintenance.
                    </p>

                    <div class="mt-5 sm:mt-6 space-y-3">
                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-user"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Officer</p>
                                <p class="font-semibold text-slate-700">Executive Engineer (Roads)</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-building"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Department</p>
                                <p class="font-semibold text-slate-700">Roads & Transport Department</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Email</p>
                                <p class="font-semibold text-slate-700">roads@jmc.gov.in</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dept Card 2 -->
            <div class="soft-card bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                <div class="h-2 bg-blue-500"></div>
                <div class="p-6 sm:p-7">
                    <div class="flex items-start justify-between">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-blue-50 text-blue-500 flex items-center justify-center">
                            <i class="fa-solid fa-faucet-drip text-lg sm:text-xl"></i>
                        </div>
                        <span class="px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 text-[10px] font-extrabold uppercase tracking-wider">
                            Division 02
                        </span>
                    </div>

                    <h3 class="heading-font mt-5 sm:mt-6 text-lg sm:text-xl font-extrabold text-slate-900">
                        Water Supply
                    </h3>

                    <p class="mt-2 text-xs sm:text-sm text-slate-500 leading-6">
                        Pipeline leakages, irregular pressure, water contamination, and local distribution valves.
                    </p>

                    <div class="mt-5 sm:mt-6 space-y-3">
                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-user"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Officer</p>
                                <p class="font-semibold text-slate-700">Hydraulic Engineer</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-building"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Department</p>
                                <p class="font-semibold text-slate-700">Water Supply Department</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Email</p>
                                <p class="font-semibold text-slate-700">watersupply@jmc.gov.in</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dept Card 3 -->
            <div class="soft-card bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                <div class="h-2 bg-emerald-500"></div>
                <div class="p-6 sm:p-7">
                    <div class="flex items-start justify-between">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-emerald-50 text-emerald-500 flex items-center justify-center">
                            <i class="fa-solid fa-trash-can text-lg sm:text-xl"></i>
                        </div>
                        <span class="px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 text-[10px] font-extrabold uppercase tracking-wider">
                            Division 03
                        </span>
                    </div>

                    <h3 class="heading-font mt-5 sm:mt-6 text-lg sm:text-xl font-extrabold text-slate-900">
                        Sanitation & Solid Waste
                    </h3>

                    <p class="mt-2 text-xs sm:text-sm text-slate-500 leading-6">
                        Garbage disposal dumps, street sweeping, container overflow, and municipal sanitation trucks.
                    </p>

                    <div class="mt-5 sm:mt-6 space-y-3">
                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-user"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Officer</p>
                                <p class="font-semibold text-slate-700">Chief Sanitary Inspector</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-building"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Department</p>
                                <p class="font-semibold text-slate-700">Sanitation & Solid Waste</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Email</p>
                                <p class="font-semibold text-slate-700">sanitation@jmc.gov.in</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dept Card 4 -->
            <div class="soft-card bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                <div class="h-2 bg-amber-500"></div>
                <div class="p-6 sm:p-7">
                    <div class="flex items-start justify-between">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center">
                            <i class="fa-solid fa-lightbulb text-lg sm:text-xl"></i>
                        </div>
                        <span class="px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 text-[10px] font-extrabold uppercase tracking-wider">
                            Division 04
                        </span>
                    </div>

                    <h3 class="heading-font mt-5 sm:mt-6 text-lg sm:text-xl font-extrabold text-slate-900">
                        Electrical & Street Lights
                    </h3>

                    <p class="mt-2 text-xs sm:text-sm text-slate-500 leading-6">
                        Broken poles, unlit fixtures, exposed wires, short circuits, and park illumination networks.
                    </p>

                    <div class="mt-5 sm:mt-6 space-y-3">
                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-user"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Officer</p>
                                <p class="font-semibold text-slate-700">Electrical Inspector</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-building"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Department</p>
                                <p class="font-semibold text-slate-700">Electrical & Street Lights</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Email</p>
                                <p class="font-semibold text-slate-700">lighting@jmc.gov.in</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dept Card 5 -->
            <div class="soft-card bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm md:col-span-2 lg:col-span-1">
                <div class="h-2 bg-purple-500"></div>
                <div class="p-6 sm:p-7">
                    <div class="flex items-start justify-between">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-purple-50 text-purple-500 flex items-center justify-center">
                            <i class="fa-solid fa-water text-lg sm:text-xl"></i>
                        </div>
                        <span class="px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 text-[10px] font-extrabold uppercase tracking-wider">
                            Division 05
                        </span>
                    </div>

                    <h3 class="heading-font mt-5 sm:mt-6 text-lg sm:text-xl font-extrabold text-slate-900">
                        Drainage & Sewage
                    </h3>

                    <p class="mt-2 text-xs sm:text-sm text-slate-500 leading-6">
                        Blocked drains, overflowing gutters, stormwater backups, and manhole cap replacements.
                    </p>

                    <div class="mt-5 sm:mt-6 space-y-3">
                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-user"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Officer</p>
                                <p class="font-semibold text-slate-700">Drainage Supervisor</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-building"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Department</p>
                                <p class="font-semibold text-slate-700">Drainage & Sewage</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Email</p>
                                <p class="font-semibold text-slate-700">drainage@jmc.gov.in</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</section>


<!-- =========================================================
     ENGINEERING TEAM (Lead Architect & Systems Engineer)
========================================================= -->

<section id="contacts" class="py-16 sm:py-20 lg:py-24 bg-white/60 backdrop-blur-sm border-t border-slate-200/60">

    <div class="max-w-7xl mx-auto px-6 lg:px-8">

        <div class="max-w-2xl mb-10 sm:mb-12">
            <span class="inline-block border border-orange-500 text-orange-500 text-xs font-extrabold uppercase tracking-[0.18em] px-3.5 py-1.5">
                Engineering Team
            </span>

            <h2 class="heading-font mt-4 text-2xl sm:text-4xl font-extrabold text-slate-900">
                Technical Architects
            </h2>

            <p class="mt-3 sm:mt-4 text-sm sm:text-base text-slate-500 leading-6 sm:leading-7">
                The software engineers responsible for architecting, designing, and maintaining the NagarNivaran platform.
            </p>
        </div>

        <div class="grid md:grid-cols-2 gap-6">

            <!-- Developer 1: Lead Architect -->
            <div class="soft-card bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                <div class="h-2 bg-slate-900"></div>

                <div class="p-6 sm:p-7">
                    <div class="flex items-start justify-between">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-slate-100 text-slate-800 flex items-center justify-center">
                            <i class="fa-solid fa-code text-lg sm:text-xl"></i>
                        </div>
                        <span class="px-3 py-1 rounded-full bg-orange-50 text-orange-600 text-[10px] font-extrabold uppercase tracking-wider">
                            Lead Engineering
                        </span>
                    </div>

                    <h3 class="heading-font mt-5 sm:mt-6 text-lg sm:text-xl font-extrabold text-slate-900">
                        Lead System Architect
                    </h3>

                    <p class="mt-2 text-xs sm:text-sm text-slate-500 leading-6">
                        Heads platform architecture, PDO database management, security protocol deployment, and command desk workflows.
                    </p>

                    <div class="mt-5 sm:mt-6 space-y-3">
                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-user-gear"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Name</p>
                                <p class="font-semibold text-slate-700">[Lead Developer Name]</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-laptop-code"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Designation</p>
                                <p class="font-semibold text-slate-700">Full-Stack Platform Architect</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Email</p>
                                <p class="font-semibold text-slate-700">lead.dev@nagarnivaran.in</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Developer 2: Systems Engineer -->
            <div class="soft-card bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                <div class="h-2 bg-[#FF6347]"></div>

                <div class="p-6 sm:p-7">
                    <div class="flex items-start justify-between">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-red-50 text-red-500 flex items-center justify-center">
                            <i class="fa-solid fa-terminal text-lg sm:text-xl"></i>
                        </div>
                        <span class="px-3 py-1 rounded-full bg-blue-50 text-blue-600 text-[10px] font-extrabold uppercase tracking-wider">
                            Core Development
                        </span>
                    </div>

                    <h3 class="heading-font mt-5 sm:mt-6 text-lg sm:text-xl font-extrabold text-slate-900">
                        Associate Systems Engineer
                    </h3>

                    <p class="mt-2 text-xs sm:text-sm text-slate-500 leading-6">
                        Focuses on responsive user interfaces, real-time GPS telemetry binding, and API middleware performance.
                    </p>

                    <div class="mt-5 sm:mt-6 space-y-3">
                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-user-gear"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Name</p>
                                <p class="font-semibold text-slate-700">[Associate Developer Name]</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-laptop-code"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Designation</p>
                                <p class="font-semibold text-slate-700">Frontend & Infrastructure Engineer</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 text-xs sm:text-sm">
                            <div class="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <div>
                                <p class="text-[10px] uppercase font-bold text-slate-400">Email</p>
                                <p class="font-semibold text-slate-700">core.dev@nagarnivaran.in</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</section>


<!-- =========================================================
     MISSION
========================================================= -->

<section class="py-16 sm:py-20 bg-slate-900 relative overflow-hidden">

    <div class="max-w-5xl mx-auto px-6 text-center relative z-10">

        <div class="w-12 h-12 sm:w-14 sm:h-14 mx-auto rounded-2xl bg-orange-500 text-white flex items-center justify-center shadow-xl shadow-orange-500/20">
            <i class="fa-solid fa-city text-lg sm:text-xl"></i>
        </div>

        <h2 class="heading-font mt-6 sm:mt-7 text-2xl sm:text-4xl font-extrabold text-white">
            Built around one simple idea.
        </h2>

        <p class="mt-4 sm:mt-5 text-sm sm:text-base text-slate-400 leading-7 sm:leading-8 max-w-2xl mx-auto">
            Civic problems become easier to manage when citizens can
            report them clearly, departments can respond systematically,
            and everyone can stay informed about the progress.
        </p>

        <div class="mt-6 sm:mt-8 inline-flex items-center gap-2 text-orange-400 text-xs sm:text-sm font-bold">
            <i class="fa-solid fa-arrow-right"></i>
            Report. Track. Stay Informed.
        </div>

    </div>

</section>


<!-- =========================================================
     FOOTER
========================================================= -->

<footer class="bg-white border-t border-slate-200 relative z-10">

    <div class="max-w-7xl mx-auto px-6 lg:px-8 py-10">

        <div class="flex flex-col md:flex-row justify-between gap-8">

            <!-- Brand -->
            <div class="max-w-sm">

                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-white border border-slate-200 p-0.5 flex items-center justify-center shadow-sm shrink-0">
                        <img src="../assets/imgs/nn-final.png" alt="NagarNivaran Logo" onerror="this.src='https://placehold.co/80x80/FF7A00/FFFFFF?text=NN'" class="w-full h-full object-cover rounded-lg">
                    </div>

                    <h3 class="heading-font text-lg font-extrabold text-slate-900">
                        Nagar<span class="text-orange-500">Nivaran</span>
                    </h3>
                </div>

                <p class="mt-4 text-xs text-slate-400 leading-6">
                    A proposed digital civic grievance reporting and
                    management platform created for academic and
                    demonstration purposes.
                </p>

            </div>

            <!-- Quick links -->
            <div>
                <h4 class="text-xs font-extrabold uppercase tracking-wider text-slate-400">
                    Platform
                </h4>

                <div class="mt-4 space-y-2">
                    <a href="#about"
                       class="block text-sm text-slate-500 hover:text-orange-500 transition">
                        About
                    </a>

                    <a href="#how-it-works"
                       class="block text-sm text-slate-500 hover:text-orange-500 transition">
                        How It Works
                    </a>

                    <a href="#departments"
                       class="block text-sm text-slate-500 hover:text-orange-500 transition">
                        Departments
                    </a>

                    <a href="#contacts"
                       class="block text-sm text-slate-500 hover:text-orange-500 transition">
                        Contact
                    </a>
                </div>
            </div>

        </div>

        <!-- Footer bottom -->
        <div class="border-t border-slate-400 mt-8 pt-6">

            <div class="flex flex-col md:flex-row justify-between items-center gap-3 text-[10px] sm:text-xs text-center md:text-left">
                <p class="text-slate-400">
                    &copy; 2026 NagarNivaran. All rights reserved.
                </p>

                <p class="text-slate-400">
                    Jamnagar Municipal Corporation Smart Civic Grid.
                </p>
            </div>

            <!-- Corrected Disclaimer: Jamnagar Municipal Corporation -->
            <div id="disclaimer" class="border-t border-slate-300 mt-5 pt-5 text-center">
                <p class="text-[9px] sm:text-[12px] leading-relaxed text-slate-400">
                    <span class="font-semibold text-slate-500">
                        Disclaimer:
                    </span>
                    NagarNivaran is developed solely as an academic/practice
                    project for demonstration purposes and is not affiliated
                    with or officially endorsed by Jamnagar Municipal
                    Corporation (JMC).
                </p>
            </div>

        </div>

    </div>

</footer>


<!-- =========================================================
     FLOATING BACK-TO-TOP BUTTON (Appears near Footer)
========================================================= -->

<button
    id="backToTopBtn"
    onclick="window.scrollTo({ top: 0, behavior: 'smooth' })"
    class="fixed bottom-6 right-6 sm:bottom-8 sm:right-8 z-50 w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-gradient-to-br from-orange-500 to-[#FF6347] text-white shadow-xl shadow-orange-500/30 flex items-center justify-center text-base sm:text-lg opacity-0 pointer-events-none transition-all duration-300 hover:scale-110 active:scale-95 focus:outline-none"
    title="Back to Top"
>
    <i class="fa-solid fa-arrow-up"></i>
</button>

<!-- Navigation Sliding Pill with Flash Animation & Responsive Drawer Logic -->
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const navPillGroup = document.getElementById('nav-pill-group');
        const pillIndicator = document.getElementById('pill-indicator');
        const navItems = document.querySelectorAll('#nav-pill-group .nav-item');

        // Precise pill positioning matching button boundaries
        function movePill(element) {
            if (!element || !pillIndicator || !navPillGroup) return;
            
            const leftOffset = element.offsetLeft;
            const topOffset = element.offsetTop;
            const width = element.offsetWidth;
            const height = element.offsetHeight;

            pillIndicator.style.left = `${leftOffset}px`;
            pillIndicator.style.top = `${topOffset}px`;
            pillIndicator.style.width = `${width}px`;
            pillIndicator.style.height = `${height}px`;

            // Trigger the subtle glass sweep flash effect across pill
            pillIndicator.classList.remove('trigger-flash');
            void pillIndicator.offsetWidth; // force DOM reflow
            pillIndicator.classList.add('trigger-flash');
        }

        // Set initial pill position
        const activeLink = document.querySelector('#nav-pill-group .active-link') || navItems[0];
        if (activeLink) {
            setTimeout(() => movePill(activeLink), 70);
        }

        navItems.forEach(item => {
            item.addEventListener('mouseenter', (e) => {
                movePill(e.currentTarget);
                navItems.forEach(link => {
                    link.classList.remove('text-slate-900');
                    link.classList.add('text-white');
                });
                e.currentTarget.classList.remove('text-white');
                e.currentTarget.classList.add('text-slate-900');
            });
        });

        if (navPillGroup) {
            navPillGroup.addEventListener('mouseleave', () => {
                const currentActive = document.querySelector('#nav-pill-group .active-link') || navItems[0];
                movePill(currentActive);
                navItems.forEach(link => {
                    link.classList.remove('text-slate-900');
                    link.classList.add('text-white');
                });
                if (currentActive) {
                    currentActive.classList.remove('text-white');
                    currentActive.classList.add('text-slate-900');
                }
            });
        }

        window.addEventListener('resize', () => {
            const currentActive = document.querySelector('#nav-pill-group .active-link') || navItems[0];
            if (currentActive) movePill(currentActive);
        });

        // Mobile Menu Dropdown Handler
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mobileMenu = document.getElementById('mobileMenu');
        const menuIcon = document.getElementById('menuIcon');

        if (mobileMenuBtn && mobileMenu) {
            mobileMenuBtn.addEventListener('click', () => {
                const isHidden = mobileMenu.classList.contains('hidden');
                mobileMenu.classList.toggle('hidden');
                menuIcon.className = isHidden ? 'fa-solid fa-xmark' : 'fa-solid fa-bars';
            });

            document.querySelectorAll('.mobile-nav-link').forEach(link => {
                link.addEventListener('click', () => {
                    mobileMenu.classList.add('hidden');
                    menuIcon.className = 'fa-solid fa-bars';
                });
            });
        }
    });

    // Reveal Back-To-Top button near bottom
    const backToTopBtn = document.getElementById('backToTopBtn');

    window.addEventListener('scroll', () => {
        const scrollPosition = window.innerHeight + window.scrollY;
        const triggerThreshold = document.documentElement.scrollHeight - 900;

        if (scrollPosition >= triggerThreshold) {
            backToTopBtn.classList.remove('opacity-0', 'pointer-events-none');
            backToTopBtn.classList.add('opacity-100', 'pointer-events-auto');
        } else {
            backToTopBtn.classList.remove('opacity-100', 'pointer-events-auto');
            backToTopBtn.classList.add('opacity-0', 'pointer-events-none');
        }
    });
</script>

</body>
</html>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms of Service | NagarNivaran</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Premium Fonts: Plus Jakarta Sans, Outfit, Courier Prime, Hind Vadodara, Mukta Vaani -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;700;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Courier+Prime:wght@400;700&family=Hind+Vadodara:wght@500;600;700&family=Mukta+Vaani:wght@400;500;700&display=swap" rel="stylesheet">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'saffron': '#FF9933',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                        'ink': '#0F172A',
                    },
                    fontFamily: {
                        heading: ['"Outfit"', 'sans-serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        mono: ['"Courier Prime"', 'monospace'],
                        'gu-heading': ['"Hind Vadodara"', 'sans-serif'],
                        'gu-body': ['"Mukta Vaani"', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    
    <style>
        body { background-color: #F8FAFC; }
        
        /* Orange Cross Pattern Background */
        .bg-cross-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }

        .policy-section { margin-bottom: 2.5rem; }
        
        /* Custom Bullet List */
        .custom-list { list-style: none; padding-left: 0; }
        .custom-list li { 
            position: relative; 
            padding-left: 1.5rem; 
            margin-bottom: 0.75rem; 
            color: #475569; /* slate-600 */
            line-height: 1.6;
        }
        .custom-list li::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0.6rem;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background-color: #FF7A00; /* orange-glow */
        }

        /* Language Toggle Classes */
        body.lang-gu .en-text { display: none !important; }
        body.lang-gu .gu-text { display: block !important; }
        body.lang-gu .gu-inline { display: inline !important; }
        
        body.lang-en .gu-text { display: none !important; }
        body.lang-en .gu-inline { display: none !important; }
        body.lang-en .en-text { display: block !important; }
        body.lang-en .en-inline { display: inline !important; }

        .gu-inline, .en-inline { display: none; } /* Default hide inline spans */
    </style>
</head>

<body class="lang-gu py-6 sm:py-10 px-4 text-slate-800 font-sans selection:bg-orange-glow selection:text-white relative min-h-screen">

    <!-- Background Pattern -->
    <div class="fixed inset-0 -z-20 bg-cross-pattern pointer-events-none"></div>

    <!-- Toolbar (No Print Option) -->
    <div class="max-w-4xl mx-auto mb-6 flex flex-col sm:flex-row justify-between items-center gap-4 relative z-10">
        
        <a href="../index.php" class="w-full sm:w-auto justify-center text-sm font-bold text-slate-600 hover:text-orange-glow transition-colors flex items-center gap-2 bg-white px-5 py-3 rounded-xl shadow-sm border border-slate-200">
            <i class="fa-solid fa-arrow-left"></i> 
            <span class="en-inline">Back to Portal</span>
            <span class="gu-inline font-gu-body font-bold">પોર્ટલ પર પાછા જાઓ</span>
        </a>
        
        <!-- Language Toggle -->
        <div class="w-full sm:w-auto bg-white border border-slate-200 p-1.5 rounded-xl shadow-sm flex font-bold text-sm">
            <button onclick="setLanguage('en')" id="btn-en" class="flex-1 sm:flex-none px-6 py-2 rounded-lg text-slate-500 hover:text-slate-800 transition-colors">English</button>
            <button onclick="setLanguage('gu')" id="btn-gu" class="flex-1 sm:flex-none px-6 py-2 rounded-lg bg-orange-glow text-white shadow-sm transition-colors">ગુજરાતી</button>
        </div>

    </div>

    <!-- Document Sheet -->
    <div class="max-w-4xl mx-auto bg-white shadow-2xl rounded-2xl overflow-hidden border border-slate-200 relative z-10">
        
        <!-- Header Ribbon -->
        <div class="h-2 w-full bg-gradient-to-r from-orange-glow to-tomato"></div>
        
        <div class="p-6 sm:p-10 md:p-14">
            
            <!-- Branding Header -->
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b-2 border-slate-100 pb-6 mb-10 gap-4">
                <div class="flex items-center gap-4">
                    <img src="../assets/imgs/nn-final.png" onerror="this.src='https://placehold.co/60x60/FF7A00/FFF?text=JMC'" class="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-2 border-orange-glow object-cover shrink-0">
                    <div>
                        <h1 class="font-heading font-black text-2xl sm:text-3xl text-ink tracking-tight flex items-center gap-2">
                            <span>Nagar<span class="text-orange-glow">Nivaran</span></span>
                            <i class="fa-solid fa-shield-halved text-xl sm:text-2xl text-orange-glow pb-1"></i>
                        </h1>
                        <p class="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1 en-text">Terms of Service</p>
                        <p class="text-sm font-bold text-slate-500 mt-1 gu-text font-gu-heading">સેવાની શરતો</p>
                    </div>
                </div>
                <div class="text-left sm:text-right w-full sm:w-auto bg-slate-50 sm:bg-transparent p-3 sm:p-0 rounded-lg sm:rounded-none">
                    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest en-text">Effective Date</p>
                    <p class="text-[11px] font-bold text-slate-400 uppercase tracking-widest gu-text font-gu-heading">અમલીકરણ તારીખ</p>
                    <p class="font-mono text-sm font-bold text-ink sm:bg-slate-50 sm:border sm:border-slate-200 sm:px-2 sm:py-1 rounded mt-1">August 27, 2026</p>
                </div>
            </div>

            <!-- Content Area -->
            <div class="space-y-2">

                <!-- 1. Acceptance of Terms -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">1. Acceptance of Terms</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૧. શરતોની સ્વીકૃતિ</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        By accessing or using NagarNivaran, users agree to follow these Terms of Service. Users who do not agree with these terms should not use the system.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        નગરનિવારણનો ઉપયોગ કરીને, વપરાશકર્તાઓ આ સેવાની શરતોનું પાલન કરવા સંમત થાય છે. જે વપરાશકર્તાઓ આ શરતો સાથે સંમત ન હોય તેમણે સિસ્ટમનો ઉપયોગ કરવો જોઈએ નહીં.
                    </p>
                </div>

                <!-- 2. Purpose of the System -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">2. Purpose of the System</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૨. સિસ્ટમનો હેતુ</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        NagarNivaran is a civic issue reporting platform designed to allow citizens to report local civic problems and help authorized personnel manage and track those complaints.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        નગરનિવારણ એક નાગરિક સમસ્યા રિપોર્ટિંગ પ્લેટફોર્મ છે, જે નાગરિકોને સ્થાનિક સમસ્યાઓ નોંધાવવા અને અધિકૃત કર્મચારીઓને તે ફરિયાદોનું સંચાલન અને ટ્રેક કરવામાં મદદ કરવા માટે રચાયેલ છે.
                    </p>
                </div><br>

                <!-- 3. User Registration -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">3. User Registration</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૩. વપરાશકર્તાની નોંધણી</h2>
                    
                    <ul class="custom-list text-sm sm:text-base en-text">
                        <li>Users must provide accurate information during registration.</li>
                        <li>Users are responsible for maintaining the confidentiality of their login credentials.</li>
                        <li>A user should not create an account using another person's identity or information.</li>
                        <li>Users are responsible for activities performed through their account.</li>
                    </ul>
                    <ul class="custom-list text-sm sm:text-base font-gu-body gu-text">
                        <li>વપરાશકર્તાઓએ નોંધણી દરમિયાન સચોટ માહિતી પ્રદાન કરવી આવશ્યક છે.</li>
                        <li>વપરાશકર્તાઓ તેમના લૉગિન ઓળખપત્રોની ગોપનીયતા જાળવવા માટે જવાબદાર છે.</li>
                        <li>કોઈપણ વ્યક્તિની ઓળખ અથવા માહિતીનો ઉપયોગ કરીને અન્યના નામે એકાઉન્ટ બનાવવું જોઈએ નહીં.</li>
                        <li>એકાઉન્ટ દ્વારા કરવામાં આવતી તમામ પ્રવૃત્તિઓ માટે વપરાશકર્તાઓ જવાબદાર છે.</li>
                    </ul>
                </div><br>

                <!-- 4. Complaint Submission -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">4. Complaint Submission</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૪. ફરિયાદ નોંધાવવા અંગે</h2>
                    
                    <p class="text-slate-600 font-medium text-sm sm:text-base mb-3 en-text">Users should:</p>
                    <p class="text-slate-700 font-gu-body text-sm sm:text-base mb-3 gu-text">વપરાશકર્તાઓએ આ બાબતોનું ધ્યાન રાખવું:</p>

                    <div class="bg-slate-50 p-5 rounded-xl border border-slate-100 mb-4">
                        <ul class="custom-list text-sm en-text">
                            <li>Provide accurate and relevant complaint information.</li>
                            <li>Select the appropriate department and priority.</li>
                            <li>Provide a clear description of the issue.</li>
                            <li>Upload genuine and relevant images, where applicable.</li>
                            <li>Provide accurate location information.</li>
                        </ul>
                        <ul class="custom-list text-sm font-gu-body gu-text">
                            <li>સચોટ અને સંબંધિત ફરિયાદ માહિતી આપવી.</li>
                            <li>યોગ્ય વિભાગ અને પ્રાધાન્યતા પસંદ કરવી.</li>
                            <li>સમસ્યાનું સ્પષ્ટ વર્ણન પ્રદાન કરવું.</li>
                            <li>સાચી અને સંબંધિત છબીઓ (જ્યાં લાગુ હોય) અપલોડ કરવી.</li>
                            <li>સચોટ સ્થાન માહિતી પ્રદાન કરવી.</li>
                        </ul>
                    </div>

                    <p class="text-slate-600 font-medium text-sm sm:text-base en-text">
                        Users should not submit false, misleading, duplicate, abusive, or irrelevant complaints.
                    </p>
                    <p class="text-slate-700 font-gu-body text-sm sm:text-base gu-text">
                        ખોટી, ગેરમાર્ગે દોરતી, ડુપ્લિકેટ, અપમાનજનક અથવા અપ્રસ્તુત ફરિયાદો સબમિટ કરવી જોઈએ નહીં.
                    </p>
                </div><br>

                <!-- 5. Prohibited Activities -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">5. Prohibited Activities</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૫. પ્રતિબંધિત પ્રવૃત્તિઓ</h2>
                    
                    <p class="text-slate-600 font-medium text-sm sm:text-base mb-3 en-text">Users must not:</p>
                    <p class="text-slate-700 font-gu-body text-sm sm:text-base mb-3 gu-text">વપરાશકર્તાઓએ આ ન કરવું જોઈએ:</p>

                    <ul class="custom-list text-sm sm:text-base en-text">
                        <li>Submit fraudulent or intentionally misleading information.</li>
                        <li>Upload inappropriate or unrelated content.</li>
                        <li>Attempt to access another user's account.</li>
                        <li>Attempt to gain unauthorized access to the system or database.</li>
                        <li>Misuse the complaint reporting facility.</li>
                        <li>Interfere with the normal operation of the application.</li>
                    </ul>
                    <ul class="custom-list text-sm sm:text-base font-gu-body gu-text">
                        <li>છેતરપિંડીવાળી અથવા ઇરાદાપૂર્વક ગેરમાર્ગે દોરતી માહિતી સબમિટ કરવી.</li>
                        <li>અયોગ્ય અથવા અસંબંધિત સામગ્રી અપલોડ કરવી.</li>
                        <li>અન્ય વપરાશકર્તાના એકાઉન્ટને ઍક્સેસ કરવાનો પ્રયાસ કરવો.</li>
                        <li>સિસ્ટમ અથવા ડેટાબેઝમાં અનધિકૃત ઍક્સેસ મેળવવાનો પ્રયાસ કરવો.</li>
                        <li>ફરિયાદ નોંધાવવાની સુવિધાનો દુરુપયોગ કરવો.</li>
                        <li>એપ્લિકેશનની સામાન્ય કામગીરીમાં દખલ કરવી.</li>
                    </ul>
                </div><br>

                <!-- 6. Complaint Processing -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">6. Complaint Processing</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૬. ફરિયાદની પ્રક્રિયા</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text mb-3">
                        Submitting a complaint does not guarantee a specific resolution time or outcome. Complaints are processed according to their priority, department, availability of resources, and administrative procedures.
                    </p>
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        Where applicable, the system may display complaint status and updates to help users track their submitted complaints.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text mb-3">
                        ફરિયાદ સબમિટ કરવાથી ચોક્કસ રિઝોલ્યુશન સમય અથવા પરિણામની ખાતરી મળતી નથી. સંસાધનોની ઉપલબ્ધતા, પ્રાથમિકતા, વિભાગ અને વહીવટી પ્રક્રિયાઓ અનુસાર ફરિયાદો પર પ્રક્રિયા કરવામાં આવે છે.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        જ્યાં લાગુ હોય ત્યાં, વપરાશકર્તાઓને તેમની નોંધાયેલી ફરિયાદોને ટ્રેક કરવામાં મદદ કરવા સિસ્ટમ ફરિયાદની સ્થિતિ અને અપડેટ્સ પ્રદર્શિત કરી શકે છે.
                    </p>
                </div><br>

                <!-- 7. User-Submitted Content -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">7. User-Submitted Content</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૭. વપરાશકર્તા દ્વારા સબમિટ કરેલી સામગ્રી</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        Users are responsible for the information, descriptions, images, and other content they submit through the system. Submitted content should be relevant to the reported civic issue.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        વપરાશકર્તાઓ સિસ્ટમ દ્વારા સબમિટ કરેલી માહિતી, વર્ણનો, છબીઓ અને અન્ય સામગ્રી માટે જવાબદાર છે. સબમિટ કરેલી સામગ્રી નોંધાયેલી નાગરિક સમસ્યાને સંબંધિત હોવી જોઈએ.
                    </p>
                </div><br>

                <!-- 8. Account Suspension or Restriction -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">8. Account Suspension or Restriction</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૮. એકાઉન્ટ સસ્પેન્શન અથવા પ્રતિબંધ</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        Access to an account may be restricted or suspended if the account is found to be involved in misuse, fraudulent activity, unauthorized access attempts, or violation of these terms.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        જો એકાઉન્ટ દુરુપયોગ, છેતરપિંડીની પ્રવૃત્તિ, અનધિકૃત ઍક્સેસ પ્રયાસો અથવા આ શરતોના ઉલ્લંઘનમાં સંડોવાયેલું જોવા મળે તો એકાઉન્ટની ઍક્સેસ મર્યાદિત અથવા સ્થગિત થઈ શકે છે.
                    </p>
                </div><br>

                <!-- 9. System Availability -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">9. System Availability</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૯. સિસ્ટમની ઉપલબ્ધતા</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        The system is intended to provide reliable access, but continuous or uninterrupted availability cannot be guaranteed. Temporary unavailability may occur due to maintenance, technical issues, or other circumstances.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        સિસ્ટમનો હેતુ વિશ્વસનીય ઍક્સેસ પ્રદાન કરવાનો છે, પરંતુ સતત અથવા અવિરત ઉપલબ્ધતાની ખાતરી આપી શકાતી નથી. જાળવણી, તકનીકી સમસ્યાઓ અથવા અન્ય સંજોગોને કારણે કામચલાઉ અનુપલબ્ધતા આવી શકે છે.
                    </p>
                </div><br>

                <!-- 10. Privacy -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">10. Privacy</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૧૦. ગોપનીયતા</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        The collection and use of personal information are described in the NagarNivaran Privacy Policy. Users should review the Privacy Policy before using the system.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        વ્યક્તિગત માહિતીનો સંગ્રહ અને ઉપયોગ નગરનિવારણની ગોપનીયતા નીતિમાં વર્ણવેલ છે. વપરાશકર્તાઓએ સિસ્ટમનો ઉપયોગ કરતા પહેલા ગોપનીયતા નીતિની સમીક્ષા કરવી જોઈએ.
                    </p>
                </div><br>

                <!-- 11. Changes to the Terms -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">11. Changes to the Terms</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૧૧. શરતોમાં ફેરફાર</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        These Terms of Service may be updated when system features, functionality, or operational requirements change. Updated terms will apply after they are published on the platform.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        જ્યારે સિસ્ટમની વિશેષતાઓ, કાર્યક્ષમતા અથવા ઓપરેશનલ આવશ્યકતાઓમાં ફેરફાર થાય ત્યારે આ સેવાની શરતો અપડેટ થઈ શકે છે. પ્લેટફોર્મ પર પ્રકાશિત થયા પછી અપડેટ કરેલી શરતો લાગુ થશે.
                    </p>
                </div><br>

                <!-- 12. Contact / Help -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-4 border-l-4 border-orange-glow pl-3 en-text">12. Contact / Help</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-4 border-l-4 border-orange-glow pl-3 gu-text">૧૨. સંપર્ક / સહાય</h2>
                    
                    <div class="bg-gradient-to-r from-slate-900 to-ink p-6 rounded-xl text-white shadow-lg">
                        <p class="text-slate-300 font-medium mb-4 text-sm en-text">
                            For questions, technical problems, or concerns regarding the use of NagarNivaran, users may contact the system administrator through the available support/contact facility.
                        </p>
                        <p class="text-slate-300 font-gu-body mb-4 text-sm gu-text">
                            નગરનિવારણના ઉપયોગ અંગેના પ્રશ્નો, તકનીકી સમસ્યાઓ અથવા ચિંતાઓ માટે, વપરાશકર્તાઓ ઉપલબ્ધ સપોર્ટ/સંપર્ક સુવિધા દ્વારા સિસ્ટમ એડમિનિસ્ટ્રેટરનો સંપર્ક કરી શકે છે.
                        </p>
                        <div class="space-y-3 font-mono text-sm">
                            <p class="flex items-center gap-3"><i class="fa-solid fa-envelope text-orange-glow w-4 text-center"></i> <a href="mailto:support@jamnagarsmartcity.gov" class="hover:text-orange-glow transition-colors">support@jamnagarsmartcity.gov</a></p>
                            <p class="flex items-center gap-3"><i class="fa-solid fa-phone text-orange-glow w-4 text-center"></i> 1800-XXX-XXXX</p>
                            <p class="flex items-start gap-3"><i class="fa-solid fa-location-dot text-orange-glow w-4 text-center mt-1"></i> <span class="en-text">Integrated Command & Control Center (ICCC)<br>Ranjit Nagar, Jamnagar, Gujarat</span><span class="gu-text font-gu-body font-bold">ઇન્ટિગ્રેટેડ કમાન્ડ એન્ડ કંટ્રોલ સેન્ટર (ICCC)<br>રણજીત નગર, જામનગર, ગુજરાત</span></p>
                        </div>
                    </div>
                </div><br>

                <div class="policy-section mb-0">
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        # This Terms of Service describes the proposed terms and conditions governing the use of the NagarNivaran Civic Issue Reporting System.                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        # આ 'સેવાની શરતો' (Terms of Service) 'નગરનિવારણ સિવિક ઇશ્યુ રિપોર્ટિંગ સિસ્ટમ'ના ઉપયોગને લાગુ પડતી પ્રસ્તાવિત નિયમાવલી ​​અને શરતોનું વર્ણન કરે છે.                    </p>
                </div>

            </div>

            <!-- Footer Note -->
            <div class="border-t-2 border-dashed border-slate-200 pt-6 mt-12 flex flex-col sm:flex-row justify-between items-center gap-2 sm:gap-4 text-[10px] sm:text-xs font-mono text-slate-500 text-center sm:text-left">
                <p class="en-text">JMC • Information Technology Cell</p>
                <p class="gu-text font-gu-body text-xs sm:text-sm font-bold">જામનગર મહાનગરપાલિકા • માહિતી પ્રૌદ્યોગિકી સેલ</p>
                <p class="font-bold text-slate-400">© 2026 Jamnagar Municipal Corporation</p>
            </div>
            
        </div>
    </div>

    <!-- JavaScript for Language Toggle -->
    <script>
        function setLanguage(lang) {
            const body = document.body;
            const btnEn = document.getElementById('btn-en');
            const btnGu = document.getElementById('btn-gu');

            if (lang === 'en') {
                body.classList.remove('lang-gu');
                body.classList.add('lang-en');
                
                // Style buttons
                btnEn.classList.add('bg-orange-glow', 'text-white');
                btnEn.classList.remove('text-slate-500');
                
                btnGu.classList.remove('bg-orange-glow', 'text-white');
                btnGu.classList.add('text-slate-500');
            } else {
                body.classList.remove('lang-en');
                body.classList.add('lang-gu');
                
                // Style buttons
                btnGu.classList.add('bg-orange-glow', 'text-white');
                btnGu.classList.remove('text-slate-500');
                
                btnEn.classList.remove('bg-orange-glow', 'text-white');
                btnEn.classList.add('text-slate-500');
            }
        }
    </script>
</body>
</html>
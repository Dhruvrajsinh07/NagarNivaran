<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy | NagarNivaran</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Premium Fonts: Plus Jakarta Sans, Outfit, Courier Prime, Hind Vadodara, Mukta Vaani -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;700;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Courier+Prime:wght@400;700&family=Hind+Vadodara:wght@500;600;700&family=Mukta+Vaani:wght@400;500;700&display=swap" rel="stylesheet">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'saffron': '#FF9933',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                        'ink': '#0F172A',
                    },
                    fontFamily: {
                        heading: ['"Outfit"', 'sans-serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        mono: ['"Courier Prime"', 'monospace'],
                        'gu-heading': ['"Hind Vadodara"', 'sans-serif'],
                        'gu-body': ['"Mukta Vaani"', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    
    <style>
        body { background-color: #F8FAFC; }
        
        /* Orange Cross Pattern Background */
        .bg-cross-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }

        .policy-section { margin-bottom: 2.5rem; }
        
        /* Custom Bullet List */
        .custom-list { list-style: none; padding-left: 0; }
        .custom-list li { 
            position: relative; 
            padding-left: 1.5rem; 
            margin-bottom: 0.75rem; 
            color: #475569; /* slate-600 */
            line-height: 1.6;
        }
        .custom-list li::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0.6rem;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background-color: #FF7A00; /* orange-glow */
        }

        /* Language Toggle Classes */
        body.lang-gu .en-text { display: none !important; }
        body.lang-gu .gu-text { display: block !important; }
        body.lang-gu .gu-inline { display: inline !important; }
        
        body.lang-en .gu-text { display: none !important; }
        body.lang-en .gu-inline { display: none !important; }
        body.lang-en .en-text { display: block !important; }
        body.lang-en .en-inline { display: inline !important; }

        .gu-inline, .en-inline { display: none; } /* Default hide inline spans */
    </style>
</head>

<body class="lang-gu py-6 sm:py-10 px-4 text-slate-800 font-sans selection:bg-orange-glow selection:text-white relative min-h-screen">

    <!-- Background Pattern -->
    <div class="fixed inset-0 -z-20 bg-cross-pattern pointer-events-none"></div>

    <!-- Toolbar -->
    <div class="max-w-4xl mx-auto mb-6 flex flex-col sm:flex-row justify-between items-center gap-4 relative z-10">
        
        <a href="../index.php" class="w-full sm:w-auto justify-center text-sm font-bold text-slate-600 hover:text-orange-glow transition-colors flex items-center gap-2 bg-white px-5 py-3 rounded-xl shadow-sm border border-slate-200">
            <i class="fa-solid fa-arrow-left"></i> 
            <span class="en-inline">Back to Portal</span>
            <span class="gu-inline font-gu-body font-bold">પોર્ટલ પર પાછા જાઓ</span>
        </a>
        
        <!-- Language Toggle -->
        <div class="w-full sm:w-auto bg-white border border-slate-200 p-1.5 rounded-xl shadow-sm flex font-bold text-sm">
            <button onclick="setLanguage('en')" id="btn-en" class="flex-1 sm:flex-none px-6 py-2 rounded-lg text-slate-500 hover:text-slate-800 transition-colors">English</button>
            <button onclick="setLanguage('gu')" id="btn-gu" class="flex-1 sm:flex-none px-6 py-2 rounded-lg bg-orange-glow text-white shadow-sm transition-colors">ગુજરાતી</button>
        </div>

    </div>

    <!-- Document Sheet -->
    <div class="max-w-4xl mx-auto bg-white shadow-2xl rounded-2xl overflow-hidden border border-slate-200 relative z-10">
        
        <!-- Header Ribbon -->
        <div class="h-2 w-full bg-gradient-to-r from-orange-glow to-tomato"></div>
        
        <div class="p-6 sm:p-10 md:p-14">
            
            <!-- Branding Header -->
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b-2 border-slate-100 pb-6 mb-10 gap-4">
                <div class="flex items-center gap-4">
                    <img src="../assets/imgs/nn-final.png" onerror="this.src='https://placehold.co/60x60/FF7A00/FFF?text=JMC'" class="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-2 border-orange-glow object-cover shrink-0">
                    <div>
                        <h1 class="font-heading font-black text-2xl sm:text-3xl text-ink tracking-tight flex items-center gap-2">
                            <span>Nagar<span class="text-orange-glow">Nivaran</span></span>
                            <i class="fa-solid fa-shield-halved text-xl sm:text-2xl text-orange-glow pb-1"></i>
                        </h1>
                        <p class="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1 en-text">Privacy Policy</p>
                        <p class="text-sm font-bold text-slate-500 mt-1 gu-text font-gu-heading">ગોપનીયતા નીતિ</p>
                    </div>
                </div>
                <div class="text-left sm:text-right w-full sm:w-auto bg-slate-50 sm:bg-transparent p-3 sm:p-0 rounded-lg sm:rounded-none">
                    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest en-text">Effective Date</p>
                    <p class="text-[11px] font-bold text-slate-400 uppercase tracking-widest gu-text font-gu-heading">અમલીકરણ તારીખ</p>
                    <p class="font-mono text-sm font-bold text-ink sm:bg-slate-50 sm:border sm:border-slate-200 sm:px-2 sm:py-1 rounded mt-1">August 27, 2026</p>
                </div>
            </div>

            <!-- Content Area -->
            <div class="space-y-2">

                <!-- 1. Introduction -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">1. Introduction</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૧. પ્રસ્તાવના</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        [Add your introduction text here. Explain the purpose of this Privacy Policy and how NagarNivaran respects and protects the data of its citizens.]
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        [તમારો પ્રસ્તાવના ટેક્સ્ટ અહીં ઉમેરો. આ ગોપનીયતા નીતિનો હેતુ શું છે અને નગરનિવારણ તેના નાગરિકોના ડેટાનો આદર અને સુરક્ષા કેવી રીતે કરે છે તે સમજાવો.]
                    </p>
                </div>

                <!-- 2. Information We Collect -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-4 border-l-4 border-orange-glow pl-3 en-text">2. Information We Collect</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-4 border-l-4 border-orange-glow pl-3 gu-text">૨. અમે કઈ માહિતી એકત્રિત કરીએ છીએ</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify mb-4 en-text">
                        To provide effective civic resolution services, NagarNivaran collects the following types of information:
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify mb-4 gu-text">
                        અસરકારક નાગરિક ઉકેલ સેવાઓ પ્રદાન કરવા માટે, નગરનિવારણ નીચેના પ્રકારની માહિતી એકત્રિત કરે છે:
                    </p>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Account Info -->
                        <div class="bg-slate-50 p-5 rounded-xl border border-slate-100">
                            <h3 class="font-bold text-ink mb-3 flex items-center gap-2 en-text">
                                <i class="fa-solid fa-user-check text-orange-glow"></i> Account Information
                            </h3>
                            <h3 class="font-bold font-gu-heading text-lg text-ink mb-3 flex items-center gap-2 gu-text">
                                <i class="fa-solid fa-user-check text-orange-glow"></i> એકાઉન્ટની માહિતી
                            </h3>
                            <ul class="custom-list text-sm en-text">
                                <li>[Add your bullet text here]</li>
                                <li>[Add your bullet text here]</li>
                            </ul>
                            <ul class="custom-list text-sm font-gu-body gu-text">
                                <li>[અહીં તમારી માહિતી ઉમેરો]</li>
                                <li>[અહીં તમારી માહિતી ઉમેરો]</li>
                            </ul>
                        </div>

                        <!-- Complaint Info -->
                        <div class="bg-slate-50 p-5 rounded-xl border border-slate-100">
                            <h3 class="font-bold text-ink mb-3 flex items-center gap-2 en-text">
                                <i class="fa-solid fa-file-signature text-orange-glow"></i> Complaint Information
                            </h3>
                            <h3 class="font-bold font-gu-heading text-lg text-ink mb-3 flex items-center gap-2 gu-text">
                                <i class="fa-solid fa-file-signature text-orange-glow"></i> ફરિયાદની માહિતી
                            </h3>
                            <ul class="custom-list text-sm en-text">
                                <li>[Add your bullet text here]</li>
                                <li>[Add your bullet text here]</li>
                            </ul>
                            <ul class="custom-list text-sm font-gu-body gu-text">
                                <li>[અહીં તમારી માહિતી ઉમેરો]</li>
                                <li>[અહીં તમારી માહિતી ઉમેરો]</li>
                            </ul>
                        </div>

                        <!-- System Info -->
                        <div class="bg-slate-50 p-5 rounded-xl border border-slate-100 md:col-span-2">
                            <h3 class="font-bold text-ink mb-3 flex items-center gap-2 en-text">
                                <i class="fa-solid fa-server text-orange-glow"></i> System Information
                            </h3>
                            <h3 class="font-bold font-gu-heading text-lg text-ink mb-3 flex items-center gap-2 gu-text">
                                <i class="fa-solid fa-server text-orange-glow"></i> સિસ્ટમ માહિતી
                            </h3>
                            <ul class="custom-list text-sm en-text">
                                <li>[Add your bullet text here]</li>
                            </ul>
                            <ul class="custom-list text-sm font-gu-body gu-text">
                                <li>[અહીં તમારી માહિતી ઉમેરો]</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- 3. How We Use Information -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">3. How We Use Information</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૩. અમે માહિતીનો ઉપયોગ કેવી રીતે કરીએ છીએ</h2>
                    
                    <ul class="custom-list text-sm sm:text-base en-text">
                        <li>[Add your bullet text here explaining data usage]</li>
                        <li>[Add your bullet text here explaining data usage]</li>
                    </ul>
                    <ul class="custom-list text-sm sm:text-base font-gu-body gu-text">
                        <li>[માહિતીના ઉપયોગની સમજૂતી અહીં ઉમેરો]</li>
                        <li>[માહિતીના ઉપયોગની સમજૂતી અહીં ઉમેરો]</li>
                    </ul>
                </div>

                <!-- 4. Complaint Images & Location -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">4. Complaint Images & Location</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૪. ફરિયાદની છબીઓ અને સ્થાન</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        [Add your text explaining how GPS coordinates and user-uploaded photographic evidence are securely processed, stored, and utilized solely for field dispatch and resolution auditing.]
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        [જીપીએસ કોઓર્ડિનેટ્સ અને વપરાશકર્તા દ્વારા અપલોડ કરાયેલા ફોટોગ્રાફિક પુરાવાઓને સુરક્ષિત રીતે કેવી રીતે પ્રક્રિયા, સંગ્રહિત અને ફક્ત ઉકેલ માટે ઉપયોગમાં લેવાય છે તે સમજાવો.]
                    </p>
                </div>

                <!-- 5. Information Sharing -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">5. Information Sharing</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૫. માહિતીની વહેંચણી</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        [Add your text here explaining that citizen data is only shared with authorized Jamnagar Municipal Corporation (JMC) officials and necessary third-party civic contractors strictly for issue resolution.]
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        [અહીં ઉમેરો કે નાગરિક ડેટા ફક્ત અધિકૃત જામનગર મહાનગરપાલિકા (JMC) અધિકારીઓ અને જરૂરી તૃતીય-પક્ષ નાગરિક કોન્ટ્રાક્ટરો સાથે સમસ્યાના ઉકેલ માટે જ શેર કરવામાં આવે છે.]
                    </p>
                </div>

                <!-- 6. Data Security -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">6. Data Security</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૬. ડેટા સુરક્ષા</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        [Add your text here detailing the security measures, AES encryption, and server protections employed to keep citizen and complaint data secure.]
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        [નાગરિક અને ફરિયાદ ડેટાને સુરક્ષિત રાખવા માટે સુરક્ષાનાં પગલાં, એન્ક્રિપ્શન અને સર્વર સુરક્ષાની વિગતો આપતો ટેક્સ્ટ ઉમેરો.]
                    </p>
                </div>

                <!-- 7. Data Retention -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">7. Data Retention</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૭. ડેટા જાળવણી</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        [Add your text here specifying how long records are kept in the ledger before archival or deletion in compliance with government policies.]
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        [સરકારી નીતિઓનું પાલન કરીને રેકોર્ડ કેટલા સમય સુધી રાખવામાં આવે છે તે સ્પષ્ટ કરતો ટેક્સ્ટ ઉમેરો.]
                    </p>
                </div>

                <!-- 8. User Rights -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">8. User Rights</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૮. વપરાશકર્તાના અધિકારો</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        [Add your text here explaining a citizen's right to request data updates, account deletion, or access to their historical complaint logs.]
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        [ડેટા અપડેટ્સ, એકાઉન્ટ ડિલીટ કરવાની વિનંતી કરવાના નાગરિકના અધિકાર સમજાવતો ટેક્સ્ટ ઉમેરો.]
                    </p>
                </div>

                <!-- 9. Cookies & Sessions -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">9. Cookies & Sessions</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૯. કૂકીઝ અને સત્રો (Cookies)</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        [Add your text here regarding the use of secure session tokens and functional cookies required to maintain authenticated citizen and officer logins.]
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        [લૉગિન જાળવી રાખવા માટે સુરક્ષિત સત્ર ટોકન્સ અને કાર્યાત્મક કૂકીઝના ઉપયોગ અંગે તમારો ટેક્સ્ટ અહીં ઉમેરો.]
                    </p>
                </div>

                <!-- 10. Third-Party Services -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">10. Third-Party Services</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૧૦. થર્ડ-પાર્ટી સેવાઓ</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        [Add your text here regarding any external APIs (like mapping or SMS gateways) utilized by the platform.]
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        [પ્લેટફોર્મ દ્વારા ઉપયોગમાં લેવાતા કોઈપણ બાહ્ય APIs (જેમ કે મેપિંગ અથવા SMS) અંગેનો ટેક્સ્ટ ઉમેરો.]
                    </p>
                </div>

                <!-- 11. Policy Updates -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-3 border-l-4 border-orange-glow pl-3 en-text">11. Policy Updates</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-3 border-l-4 border-orange-glow pl-3 gu-text">૧૧. નીતિ અપડેટ્સ</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        [Add your text here noting that the Jamnagar Municipal Corporation reserves the right to update this policy, with significant changes communicated to users.]
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        [અહીં નોંધ કરો કે જામનગર મહાનગરપાલિકા આ નીતિને અપડેટ કરવાનો અધિકાર અનામત રાખે છે.]
                    </p>
                </div>

                <!-- 12. Contact / Help -->
                <div class="policy-section">
                    <h2 class="font-heading text-xl sm:text-2xl text-slate-900 font-extrabold mb-4 border-l-4 border-orange-glow pl-3 en-text">12. Contact / Help</h2>
                    <h2 class="font-gu-heading text-xl sm:text-2xl text-slate-900 font-bold mb-4 border-l-4 border-orange-glow pl-3 gu-text">૧૨. સંપર્ક / સહાય</h2>
                    
                    <div class="bg-gradient-to-r from-slate-900 to-ink p-6 rounded-xl text-white shadow-lg">
                        <p class="text-slate-300 font-medium mb-4 text-sm en-text">
                            For any privacy-related inquiries, concerns, or requests to exercise your data rights, please contact the municipal data protection team:
                        </p>
                        <p class="text-slate-300 font-gu-body mb-4 text-sm gu-text">
                            ગોપનીયતા-સંબંધિત કોઈપણ પૂછપરછ અથવા ચિંતાઓ માટે, કૃપા કરીને મ્યુનિસિપલ ડેટા પ્રોટેક્શન ટીમનો સંપર્ક કરો:
                        </p>
                        <div class="space-y-3 font-mono text-sm">
                            <p class="flex items-center gap-3"><i class="fa-solid fa-envelope text-orange-glow w-4 text-center"></i> <a href="mailto:privacy@jamnagarsmartcity.gov" class="hover:text-orange-glow transition-colors">privacy@jamnagarsmartcity.gov</a></p>
                            <p class="flex items-center gap-3"><i class="fa-solid fa-phone text-orange-glow w-4 text-center"></i> 1800-XXX-XXXX</p>
                            <p class="flex items-start gap-3"><i class="fa-solid fa-location-dot text-orange-glow w-4 text-center mt-1"></i> <span class="en-text">Integrated Command & Control Center (ICCC)<br>Ranjit Nagar, Jamnagar, Gujarat</span><span class="gu-text font-gu-body font-bold">ઇન્ટિગ્રેટેડ કમાન્ડ એન્ડ કંટ્રોલ સેન્ટર (ICCC)<br>રણજીત નગર, જામનગર, ગુજરાત</span></p>
                        </div>
                    </div>
                </div><br>

                <div class="policy-section mb-0">
                    <p class="text-slate-600 leading-relaxed font-medium text-sm sm:text-base text-justify en-text">
                        # This Privacy Policy describes the proposed data-handling practices of the NagarNivaran Civic Issue Reporting System.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-sm sm:text-base text-justify gu-text">
                        # આ ગોપનીયતા નીતિ 'નગરનિવારણ સિવિક ઇશ્યુ રિપોર્ટિંગ સિસ્ટમ'ની પ્રસ્તાવિત ડેટા-હેન્ડલિંગ પદ્ધતિઓનું વર્ણન કરે છે.
                    </p>
                </div>
            </div>

            <!-- Footer Note -->
            <div class="border-t-2 border-dashed border-slate-200 pt-6 mt-12 flex flex-col sm:flex-row justify-between items-center gap-2 sm:gap-4 text-[10px] sm:text-xs font-mono text-slate-500 text-center sm:text-left">
                <p class="en-text">JMC • Information Technology Cell</p>
                <p class="gu-text font-gu-body text-xs sm:text-sm font-bold">જામનગર મહાનગરપાલિકા • માહિતી પ્રૌદ્યોગિકી સેલ</p>
                <p class="font-bold text-slate-400">© 2026 Jamnagar Municipal Corporation</p>
            </div>
            
        </div>
    </div>

    <!-- JavaScript for Language Toggle -->
    <script>
        function setLanguage(lang) {
            const body = document.body;
            const btnEn = document.getElementById('btn-en');
            const btnGu = document.getElementById('btn-gu');

            if (lang === 'en') {
                body.classList.remove('lang-gu');
                body.classList.add('lang-en');
                
                // Style buttons
                btnEn.classList.add('bg-orange-glow', 'text-white');
                btnEn.classList.remove('text-slate-500');
                
                btnGu.classList.remove('bg-orange-glow', 'text-white');
                btnGu.classList.add('text-slate-500');
            } else {
                body.classList.remove('lang-en');
                body.classList.add('lang-gu');
                
                // Style buttons
                btnGu.classList.add('bg-orange-glow', 'text-white');
                btnGu.classList.remove('text-slate-500');
                
                btnEn.classList.remove('bg-orange-glow', 'text-white');
                btnEn.classList.add('text-slate-500');
            }
        }
    </script>
</body>
</html>
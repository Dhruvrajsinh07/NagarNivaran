<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="x-apple-disable-message-reformatting">
    <title>NagarNivaran Status Update</title>

    <style>
        @media only screen and (max-width: 600px) {
            .mobile-outer { padding: 12px 8px !important; }
            .mobile-container { width: 100% !important; border-radius: 16px !important; }
            .mobile-header { padding: 18px 14px !important; }
            .mobile-header-title { font-size: 18px !important; }
            .mobile-header-sub { font-size: 10px !important; }
            .mobile-logo { width: 44px !important; height: 44px !important; }
            .mobile-mail-icon { width: 38px !important; height: 38px !important; line-height: 38px !important; }
            .mobile-body { padding: 25px 16px !important; }
            .mobile-status-badge { width: 100% !important; padding: 8px 12px !important; box-sizing: border-box !important; }
            .mobile-status-text { font-size: 14px !important; }
            .mobile-details-box { padding: 14px 12px !important; }
            .mobile-footer { padding: 18px 14px !important; }
        }
    </style>
</head>

<body style="margin:0; padding:0; background-color:#F8FAFC; -webkit-font-smoothing:antialiased; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%;">

<div class="mobile-outer" style="font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif; padding:40px 20px; width:100%; box-sizing:border-box;">

    <div class="mobile-container" style="max-width:600px; width:100%; margin:0 auto; background-color:#ffffff; border-radius:20px; overflow:hidden; box-shadow:0 10px 25px rgba(15,23,42,0.05); border:1px solid #E2E8F0;">

        <!-- HEADER -->
        <div class="mobile-header" style="background-color:#0F172A; padding:24px 30px; border-bottom:4px solid #FF7A00;">

            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tr>

                    <!-- Logo -->
                    <td width="55" valign="middle" align="left">
                        <div class="mobile-logo" style="width:52px; height:52px; background-color:#ffffff; border-radius:50%; padding:2px; box-sizing:border-box; display:inline-block;">
                            <img src="cid:nagarnivaran_logo" alt="NagarNivaran Logo" width="48" height="48" style="display:block; width:100%; height:100%; object-fit:cover; border-radius:50%;">
                        </div>
                    </td>

                    <!-- Portal Name -->
                    <td valign="middle" align="center" style="padding:0 8px;">
                        <h2 class="mobile-header-title" style="color:#ffffff; margin:0; font-size:22px; font-weight:800; letter-spacing:-0.5px; line-height:1.2;">
                            Nagar<span style="color:#FF7A00;">Nivaran</span>
                        </h2>

                        <p class="mobile-header-sub" style="color:#94A3B8; font-size:11px; margin:4px 0 0 0; text-transform:uppercase; letter-spacing:1px; font-weight:600;">
                            Citizen Information Department
                        </p>
                    </td>

                    <!-- Mail Icon -->
                    <td width="55" valign="middle" align="right">
                        <div class="mobile-mail-icon" style="width:44px; height:44px; background-color:#FF7A00; border-radius:50%; text-align:center; line-height:44px; display:inline-block;">
                            <span style="color:#ffffff; font-size:20px; line-height:44px; display:block;">&#9993;</span>
                        </div>
                    </td>

                </tr>
            </table>

        </div>

        <!-- MAIN BODY -->
        <div class="mobile-body" style="padding:35px 30px; background-color:#ffffff;">

            <!-- Status Title -->
            <div style="text-align:center; margin-bottom:24px;">
                <div class="mobile-status-badge" style="display:inline-block; background-color:transparent; border-radius:24px; border:2px solid #FF7A00; padding:10px 24px;">
                    <h3 class="mobile-status-text" style="margin:0; font-size:17px; font-weight:800; letter-spacing:0.5px; text-transform:uppercase; color:#FF7A00; line-height:1.3;">
                        Official Status Update
                    </h3>
                </div>
            </div>

            <!-- Greeting -->
            <p style="color:#334155; margin:0 0 12px 0; font-size:15px; line-height:1.5;">
                Dear <strong>{citizen_name}</strong>,
            </p>

            <p style="color:#475569; line-height:1.6; font-size:14px; margin:0 0 24px 0;">
                There has been an official update regarding the civic grievance you filed. The assigned department has reviewed the case.
            </p>

            <!-- GRIEVANCE DETAILS -->
            <div class="mobile-details-box" style="background-color:#ffffff; border:1.5px dashed #94A3B8; border-radius:12px; padding:20px; margin-bottom:20px;">

                <p style="margin:0 0 16px 0; font-size:11px; color:#475569; text-transform:uppercase; font-weight:800; letter-spacing:1.5px;">
                    Grievance Details
                </p>

                <!-- Case ID -->
                <div style="background-color:#FDF2F8; border:1px solid #FBCFE8; border-radius:12px; padding:12px 14px; margin-bottom:12px;">
                    <span style="font-size:11px; color:#9D174D; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:3px;">
                        Case ID
                    </span>

                    <span style="font-family:'Courier New',Courier,monospace; color:#BE185D; font-size:15px; font-weight:800;">
                        #NN-{case_id}
                    </span>
                </div>

                <!-- Issue -->
                <div style="background-color:#EFF6FF; border:1px solid #BFDBFE; border-radius:12px; padding:12px 14px; margin-bottom:12px;">
                    <span style="font-size:11px; color:#1E40AF; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:3px;">
                        Issue Logged
                    </span>

                    <span style="color:#1E3A8A; font-size:14px; font-weight:700; line-height:1.4; word-break:break-word;">
                        {issue_title}
                    </span>
                </div>

                <!-- Status -->
                <div style="background-color:#FEFCE8; border:1px solid #FEF08A; border-radius:12px; padding:12px 14px;">
                    <span style="font-size:11px; color:#854D0E; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:3px;">
                        Current Status
                    </span>

                    <span style="color:#A16207; font-size:13px; font-weight:800; text-transform:uppercase; letter-spacing:0.5px;">
                        {new_status}
                    </span>
                </div>

            </div>

            <!-- OFFICER -->
            <div style="background-color:#ECFDF5; border:1px solid #A7F3D0; border-radius:12px; padding:14px 18px; margin-bottom:24px;">

                <span style="display:block; margin:0 0 3px 0; color:#047857; font-size:11px; text-transform:uppercase; letter-spacing:1px; font-weight:800;">
                    Authorized &amp; Updated By
                </span>

                <span style="color:#065F46; font-size:15px; font-weight:700; line-height:1.4; word-break:break-word;">
                    {officer_name}
                </span>

            </div>

            <!-- CITIZEN LEDGER NOTICE -->
            <div style="background-color:#FFF7ED; border:1.5px solid #FF7A00; border-radius:12px; padding:16px 20px; text-align:center;">

                <p style="color:#C2410C; line-height:1.6; font-size:13px; font-weight:600; margin:0;">
                    To view the full officer audit remarks,<br>
                    please log in to your
                    <strong style="color:#EA580C; text-decoration:underline;">
                        Citizen Ledger
                    </strong>
                    on the NagarNivaran portal.
                </p>

            </div>

        </div>

        <!-- FOOTER -->
        <div class="mobile-footer" style="background-color:#F8FAFC; padding:22px 30px; text-align:center; border-top:1px solid #E2E8F0;">

            <p style="color:#64748B; font-size:11px; font-weight:600; margin:0 0 4px 0;">
                &copy; 2026 NagarNivaran. All rights reserved.
            </p>

            <p style="color:#94A3B8; font-size:10px; margin:0; line-height:1.5;">
                This is an automated system dispatch. Please do not reply directly to this email.
            </p>

        </div>

    </div>

</div>

</body>
</html>
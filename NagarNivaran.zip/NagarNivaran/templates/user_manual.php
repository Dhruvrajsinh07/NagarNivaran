<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Citizen User Manual | NagarNivaran</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Premium Fonts: Plus Jakarta Sans, Outfit, Hind Vadodara, Mukta Vaani -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700;900&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Hind+Vadodara:wght@500;600;700&family=Mukta+Vaani:wght@400;500;700&display=swap" rel="stylesheet">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'saffron': '#FF9933',
                        'orange-glow': '#FF7A00',
                        'tomato': '#FF6347',
                        'ink': '#0F172A',
                    },
                    fontFamily: {
                        heading: ['"Outfit"', 'sans-serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        'gu-heading': ['"Hind Vadodara"', 'sans-serif'],
                        'gu-body': ['"Mukta Vaani"', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    
    <style>
        body { background-color: #F8FAFC; }
        
        /* Orange Cross Pattern Background */
        .bg-cross-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M25 20v10M20 25h10' stroke='%23FF7A00' stroke-width='1.5' fill='none' fill-rule='evenodd' opacity='0.3'/%3E%3C/svg%3E");
        }

        /* Language Toggle Classes */
        body.lang-gu .en-text { display: none !important; }
        body.lang-gu .gu-text { display: block !important; }
        body.lang-gu .gu-inline { display: inline !important; }
        
        body.lang-en .gu-text { display: none !important; }
        body.lang-en .gu-inline { display: none !important; }
        body.lang-en .en-text { display: block !important; }
        body.lang-en .en-inline { display: inline !important; }

        .gu-inline, .en-inline { display: none; } /* Default hide inline spans */

        /* A4 Print Formatting */
        @media print {
            body { background-color: white; padding: 0 !important; margin: 0 !important; background-image: none !important;}
            .no-print { display: none !important; }
            .a4-sheet { 
                box-shadow: none !important; 
                margin: 0 !important; 
                padding: 10mm !important;
                width: 100% !important;
                max-width: 100% !important;
                border: none !important;
            }
            @page { size: A4 portrait; margin: 15mm; }
        }

        .step-block { margin-bottom: 2rem; page-break-inside: avoid; }
    </style>
</head>

<!-- Defaulting to Gujarati via body class -->
<body class="lang-gu py-10 px-4 text-slate-800 font-sans selection:bg-orange-glow selection:text-white relative min-h-screen">

    <!-- Background Pattern -->
    <div class="fixed inset-0 -z-20 bg-cross-pattern pointer-events-none"></div>

    <!-- Toolbar (Hidden on Print) -->
    <div class="no-print max-w-4xl mx-auto mb-6 flex flex-col sm:flex-row justify-between items-center gap-4">
        <a href="../index.php" class="text-sm font-bold text-slate-600 hover:text-orange-glow transition-colors flex items-center gap-2 bg-white px-4 py-2 rounded-xl shadow-sm border border-slate-200">
            <i class="fa-solid fa-arrow-left"></i> 
            <span class="en-inline">Back to Portal</span>
            <span class="gu-inline font-gu-body font-bold">પોર્ટલ પર પાછા જાઓ</span>
        </a>
        
        <div class="flex items-center gap-3">
            <!-- Language Toggle -->
            <div class="bg-white border border-slate-200 p-1 rounded-xl shadow-sm flex font-bold text-sm">
                <button onclick="setLanguage('en')" id="btn-en" class="px-4 py-1.5 rounded-lg text-slate-500 hover:text-slate-800 transition-colors">English</button>
                <button onclick="setLanguage('gu')" id="btn-gu" class="px-4 py-1.5 rounded-lg bg-orange-glow text-white shadow-sm transition-colors">ગુજરાતી</button>
            </div>

            <button onclick="window.print()" class="bg-ink hover:bg-orange-glow text-white px-6 py-2.5 rounded-xl font-bold text-sm shadow-md transition-all flex items-center gap-2">
                <i class="fa-solid fa-download"></i> 
                <span class="en-inline">Save PDF / Print</span>
                <span class="gu-inline font-gu-body">PDF ડાઉનલોડ કરો / પ્રિન્ટ કરો</span>
            </button>
        </div>
    </div>

    <!-- A4 Document Sheet -->
    <div class="a4-sheet max-w-4xl mx-auto bg-white shadow-2xl rounded-2xl overflow-hidden border border-slate-200 relative z-10">
        
        <!-- Header Ribbon -->
        <div class="h-2 w-full bg-gradient-to-r from-orange-glow to-tomato"></div>
        
        <div class="p-8 sm:p-14">
            
            <!-- Branding Header -->
            <div class="flex items-center justify-between border-b-2 border-slate-100 pb-6 mb-10">
                <div class="flex items-center gap-4">
                    <img src="../assets/imgs/nn-final.png" onerror="this.src='https://placehold.co/60x60/FF7A00/FFF?text=JMC'" class="w-16 h-16 rounded-full border-2 border-orange-glow object-cover">
                    <div>
                        <h1 class="font-heading font-black text-3xl text-ink tracking-tight">Nagar<span class="text-orange-glow">Nivaran</span></h1>
                        <p class="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1 en-text">User Manual</p>
                        <p class="text-sm font-bold text-slate-500 mt-1 gu-text font-gu-heading">વપરાશકર્તા માર્ગદર્શિકા</p>
                    </div>
                </div>
                <div class="text-right hidden sm:block">
                    <p class="text-[10px] font-bold text-slate-400 uppercase">Document Ref</p>
                    <p class="font-mono text-sm font-bold text-ink">JMC-MANUAL-V1</p>
                </div>
            </div>

            <!-- Content Area -->
            <div class="space-y-10">

                <!-- 1. Introduction -->
                <div class="step-block">
                    <h2 class="font-heading text-2xl text-slate-900 font-extrabold mb-3 en-text border-l-4 border-orange-glow pl-3">1. Introduction</h2>
                    <h2 class="font-gu-heading text-2xl text-slate-900 font-bold mb-3 gu-text border-l-4 border-orange-glow pl-3">૧. પ્રસ્તાવના</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium en-text text-sm">
                        NagarNivaran is a centralized civic governance platform engineered to digitize municipal complaint management[cite: 8]. The system eliminates manual, paper-based grievance tracking by providing a responsive, mobile-first web interface[cite: 8].
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-base gu-text">
                        નગરનિવારણ એક કેન્દ્રિય નાગરિક ગવર્નન્સ પ્લેટફોર્મ છે, જે મ્યુનિસિપલ ફરિયાદ વ્યવસ્થાપનને ડિજિટલ બનાવવા માટે રચાયેલ છે. આ સિસ્ટમ મેન્યુઅલ અને કાગળ આધારિત ફરિયાદ ટ્રેકિંગને દૂર કરે છે અને મોબાઇલ-ફર્સ્ટ વેબ ઇન્ટરફેસ પૂરો પાડે છે.
                    </p>
                </div>

                <!-- 2. How to Register -->
                <div class="step-block">
                    <h2 class="font-heading text-2xl text-slate-900 font-extrabold mb-3 en-text border-l-4 border-orange-glow pl-3">2. How to Register</h2>
                    <h2 class="font-gu-heading text-2xl text-slate-900 font-bold mb-3 gu-text border-l-4 border-orange-glow pl-3">૨. નોંધણી કેવી રીતે કરવી</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium en-text text-sm">
                        To register, click on the "Register" button on the portal. You will need to provide your Full Name, Mobile Number, Email, Residential Address, Ward Area, and PIN Code to create a verified citizen account.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-base gu-text">
                        નોંધણી કરવા માટે પોર્ટલ પર "રજીસ્ટર" બટન પર ક્લિક કરો. તમારું સંપૂર્ણ નામ, મોબાઇલ નંબર, ઇમેઇલ, રહેઠાણનું સરનામું, વોર્ડ નંબર અને પિન કોડ આપીને તમારું નાગરિક એકાઉન્ટ બનાવો.
                    </p>
                </div>

                <!-- 3. How to Login -->
                <div class="step-block">
                    <h2 class="font-heading text-2xl text-slate-900 font-extrabold mb-3 en-text border-l-4 border-orange-glow pl-3">3. How to Login</h2>
                    <h2 class="font-gu-heading text-2xl text-slate-900 font-bold mb-3 gu-text border-l-4 border-orange-glow pl-3">૩. લૉગિન કેવી રીતે કરવું</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium en-text text-sm">
                        Navigate to the Login page. Enter your registered mobile number or email address along with your secure password to access your Citizen Dashboard.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-base gu-text">
                        લૉગિન પેજ પર જાઓ. તમારા સિટિઝન ડેશબોર્ડને એક્સેસ કરવા માટે તમારો રજીસ્ટર થયેલ મોબાઇલ નંબર અથવા ઈમેલ અને પાસવર્ડ દાખલ કરો.
                    </p>
                </div>

                <!-- 4. How to Report a Civic Issue -->
                <div class="step-block">
                    <h2 class="font-heading text-2xl text-slate-900 font-extrabold mb-3 en-text border-l-4 border-orange-glow pl-3">4. How to Report a Civic Issue</h2>
                    <h2 class="font-gu-heading text-2xl text-slate-900 font-bold mb-3 gu-text border-l-4 border-orange-glow pl-3">૪. નાગરિક સમસ્યા કેવી રીતે નોંધાવવી</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium en-text text-sm">
                        From your dashboard, click "Report Issue". Citizens can report local infrastructure issues (e.g., road damage, water leakage, sanitation hazards) accompanied by photographic evidence and HTML5 geolocation snapping[cite: 8].
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-base gu-text">
                        તમારા ડેશબોર્ડ પરથી "ફરિયાદ નોંધાવો" પર ક્લિક કરો. નાગરિકો સ્થાનિક ઈન્ફ્રાસ્ટ્રક્ચર સમસ્યાઓ (જેમ કે ખરાબ રસ્તા, પાણી લીકેજ, સફાઈના પ્રશ્નો) ફોટોગ્રાફિક પુરાવા અને HTML5 જીઓ-લોકેશન સાથે નોંધી શકે છે[cite: 8].
                    </p>
                </div>

                <!-- 5. Selecting Department -->
                <div class="step-block">
                    <h2 class="font-heading text-xl text-slate-800 font-extrabold mb-2 en-text">5. Selecting Department</h2>
                    <h2 class="font-gu-heading text-xl text-slate-800 font-bold mb-2 gu-text">૫. વિભાગ પસંદ કરવો</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium en-text text-sm">
                        Choose the specific municipal department related to your grievance from the dropdown menu to ensure rapid routing to the correct nodal officer.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-base gu-text">
                        ડ્રોપડાઉન મેનુમાંથી તમારી ફરિયાદને સંબંધિત ચોક્કસ મ્યુનિસિપલ વિભાગ પસંદ કરો, જેથી ફરિયાદ યોગ્ય અધિકારી સુધી ઝડપથી પહોંચી શકે.
                    </p>
                </div>

                <!-- 6. Selecting Priority -->
                <div class="step-block">
                    <h2 class="font-heading text-xl text-slate-800 font-extrabold mb-3 en-text">6. Selecting Priority</h2>
                    <h2 class="font-gu-heading text-xl text-slate-800 font-bold mb-3 gu-text">૬. પ્રાધાન્યતા પસંદ કરવી</h2>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-5 rounded-xl border border-slate-100">
                        <div class="flex items-start gap-3">
                            <span class="w-3 h-3 rounded-full bg-emerald-500 mt-1 shrink-0"></span>
                            <div>
                                <strong class="text-sm en-text font-heading text-slate-900">Low</strong>
                                <strong class="text-base gu-text font-gu-heading text-slate-900">ઓછું (Low)</strong>
                                <span class="text-xs en-text text-slate-600">Minor inconveniences like overgrown grass.</span>
                                <span class="text-sm gu-text font-gu-body text-slate-600">સામાન્ય અસુવિધાઓ.</span>
                            </div>
                        </div>
                        <div class="flex items-start gap-3">
                            <span class="w-3 h-3 rounded-full bg-orange-glow mt-1 shrink-0"></span>
                            <div>
                                <strong class="text-sm en-text font-heading text-slate-900">Medium</strong>
                                <strong class="text-base gu-text font-gu-heading text-slate-900">મધ્યમ (Medium)</strong>
                                <span class="text-xs en-text text-slate-600">Standard civic issues like garbage overflow.</span>
                                <span class="text-sm gu-text font-gu-body text-slate-600">સામાન્ય નાગરિક સમસ્યાઓ (દા.ત. કચરાનો નિકાલ).</span>
                            </div>
                        </div>
                        <div class="flex items-start gap-3">
                            <span class="w-3 h-3 rounded-full bg-orange-500 mt-1 shrink-0"></span>
                            <div>
                                <strong class="text-sm en-text font-heading text-slate-900">High</strong>
                                <strong class="text-base gu-text font-gu-heading text-slate-900">વધુ (High)</strong>
                                <span class="text-xs en-text text-slate-600">Structural damage or major disruptions.</span>
                                <span class="text-sm gu-text font-gu-body text-slate-600">માળખાગત નુકસાન અથવા મોટી સમસ્યાઓ.</span>
                            </div>
                        </div>
                        <div class="flex items-start gap-3">
                            <span class="w-3 h-3 rounded-full bg-red-600 mt-1 shrink-0"></span>
                            <div>
                                <strong class="text-sm en-text font-heading text-slate-900">Critical</strong>
                                <strong class="text-base gu-text font-gu-heading text-slate-900">ગંભીર (Critical)</strong>
                                <span class="text-xs en-text text-slate-600">Immediate dangers like live wires.</span>
                                <span class="text-sm gu-text font-gu-body text-slate-600">તાત્કાલિક જોખમ (દા.ત. ખુલ્લા વાયર).</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 7. Uploading Complaint Image -->
                <div class="step-block">
                    <h2 class="font-heading text-xl text-slate-800 font-extrabold mb-2 en-text">7. Uploading Complaint Image</h2>
                    <h2 class="font-gu-heading text-xl text-slate-800 font-bold mb-2 gu-text">૭. ફરિયાદનો ફોટો અપલોડ કરવો</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium en-text text-sm">
                        Tap the upload section to attach photographic evidence. Supported formats include JPG, PNG, and WEBP. Maximum file size is 5MB.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-base gu-text">
                        પુરાવા તરીકે ફોટો અપલોડ કરવા માટે અપલોડ વિભાગ પર ક્લિક કરો. (ફક્ત JPG, PNG, WEBP, મહત્તમ સાઈઝ 5MB).
                    </p>
                </div>

                <!-- 8 & 9. Viewing Complaint Status & History -->
                <div class="step-block">
                    <h2 class="font-heading text-xl text-slate-800 font-extrabold mb-2 en-text">8. Viewing Status & History</h2>
                    <h2 class="font-gu-heading text-xl text-slate-800 font-bold mb-2 gu-text">૮. ફરિયાદની સ્થિતિ અને ઇતિહાસ જોવો</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium en-text text-sm">
                        Navigate to the "My Cases Ledger" tab. Here you can track all your submitted complaints and view their live status updates from "Pending" to "In Progress" and finally "Resolved".
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-base gu-text">
                        "મારા કેસનો ઇતિહાસ" ટેબ પર જાઓ. અહીં તમે તમારી બધી નોંધાયેલી ફરિયાદોને ટ્રેક કરી શકો છો અને તેમની સ્થિતિ જાણી શકો છો (જેમ કે પેન્ડિંગ, પ્રગતિમાં, ઉકેલાઈ ગયેલ).
                    </p>
                </div>

                <!-- 10. Logout -->
                <div class="step-block">
                    <h2 class="font-heading text-xl text-slate-800 font-extrabold mb-2 en-text">9. Logout</h2>
                    <h2 class="font-gu-heading text-xl text-slate-800 font-bold mb-2 gu-text">૯. લૉગઆઉટ</h2>
                    
                    <p class="text-slate-600 leading-relaxed font-medium en-text text-sm">
                        For your security, always click the red "Logout" button situated at the top right of your dashboard when you have finished using the portal.
                    </p>
                    <p class="text-slate-700 leading-relaxed font-gu-body text-base gu-text">
                        તમારી સુરક્ષા માટે, પોર્ટલનો ઉપયોગ પૂર્ણ કર્યા પછી ડેશબોર્ડની ઉપર જમણી બાજુએ આપેલા લાલ "લૉગઆઉટ" બટન પર ક્લિક કરવાનું ભૂલશો નહિ.
                    </p>
                </div>

                <!-- 11. FAQ -->
                <div class="step-block border-t border-slate-200 pt-8 mt-8">
                    <h2 class="font-heading text-2xl text-slate-900 font-extrabold mb-5 en-text">Frequently Asked Questions</h2>
                    <h2 class="font-gu-heading text-2xl text-slate-900 font-bold mb-5 gu-text">વારંવાર પૂછાતા પ્રશ્નો (FAQ)</h2>
                    
                    <div class="space-y-4">
                        <div class="bg-slate-50 p-4 rounded-lg">
                            <h4 class="font-bold text-sm text-slate-900 en-text">Q: How long does it take for an issue to be resolved?</h4>
                            <h4 class="font-bold text-base text-slate-900 font-gu-heading gu-text">પ્ર: ફરિયાદનો ઉકેલ આવવામાં કેટલો સમય લાગે છે?</h4>
                            <p class="text-sm mt-1 text-slate-600 en-text">Resolution times vary based on the department and priority. Critical issues are addressed immediately, while low priority issues may take standard SLA times.</p>
                            <p class="text-base mt-1 text-slate-700 font-gu-body gu-text">ઉકેલનો સમય વિભાગ અને પ્રાધાન્યતા પર આધારિત છે. ગંભીર સમસ્યાઓનું તાત્કાલિક નિરાકરણ થાય છે.</p>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Footer Note -->
            <div class="border-t-2 border-dashed border-slate-200 pt-6 mt-10 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-mono text-slate-500">
                <p class="en-text">JMC • Integrated Command & Control Center[cite: 9]</p>
                <p class="gu-text font-gu-body text-sm font-bold">જામનગર મહાનગરપાલિકા • નાગરિક નોંધણી પત્રક[cite: 9]</p>
                <p class="font-bold text-slate-400">© 2026 Jamnagar Smart City</p>
            </div>
            
        </div>
    </div>

    <!-- JavaScript for Language Toggle -->
    <script>
        function setLanguage(lang) {
            const body = document.body;
            const btnEn = document.getElementById('btn-en');
            const btnGu = document.getElementById('btn-gu');

            if (lang === 'en') {
                body.classList.remove('lang-gu');
                body.classList.add('lang-en');
                
                // Style buttons
                btnEn.classList.add('bg-orange-glow', 'text-white');
                btnEn.classList.remove('text-slate-500');
                
                btnGu.classList.remove('bg-orange-glow', 'text-white');
                btnGu.classList.add('text-slate-500');
            } else {
                body.classList.remove('lang-en');
                body.classList.add('lang-gu');
                
                // Style buttons
                btnGu.classList.add('bg-orange-glow', 'text-white');
                btnGu.classList.remove('text-slate-500');
                
                btnEn.classList.remove('bg-orange-glow', 'text-white');
                btnEn.classList.add('text-slate-500');
            }
        }
    </script>
</body>
</html>
<?php

require_once("../../includes/config.php");

// Start session if it is not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Remove officer session variables
unset($_SESSION["officer_id"]);
unset($_SESSION["officer_name"]);
unset($_SESSION["officer_dept"]);
unset($_SESSION["badge_number"]);

// Destroy the complete session
session_destroy();

// Redirect to officer login page
header("Location: ../../pages/officer/login.php");
exit;
<?php

require_once("../../includes/config.php");
require_once("../../includes/mail_config.php");

header("Content-Type: application/json; charset=UTF-8");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| OFFICER AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["officer_id"])) {

    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Unauthorized access."
    ]);

    exit;
}

$officerId = (int) $_SESSION["officer_id"];
$officerName = $_SESSION["officer_name"] ?? "Officer Desk";


/*
|--------------------------------------------------------------------------
| REQUEST METHOD
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| GET FORM DATA
|--------------------------------------------------------------------------
*/

$complaintId = isset($_POST["complaint_id"])
    ? (int) $_POST["complaint_id"]
    : 0;

$newStatus = trim($_POST["status"] ?? "");
$remark = trim($_POST["remark"] ?? "");


/*
|--------------------------------------------------------------------------
| ALLOWED STATUS VALUES
|--------------------------------------------------------------------------
*/

$allowedStatuses = [
    "Pending",
    "In Progress",
    "Resolved",
    "Rejected"
];


/*
|--------------------------------------------------------------------------
| BASIC VALIDATION
|--------------------------------------------------------------------------
*/

if ($complaintId <= 0) {

    echo json_encode([
        "success" => false,
        "message" => "Invalid complaint ID."
    ]);

    exit;
}

if (!in_array($newStatus, $allowedStatuses, true)) {

    echo json_encode([
        "success" => false,
        "message" => "Invalid complaint status."
    ]);

    exit;
}


try {

    /*
    |--------------------------------------------------------------------------
    | GET OFFICER DETAILS
    |--------------------------------------------------------------------------
    */

    $stmt = $conn->prepare("
        SELECT
            id,
            department_id,
            full_name
        FROM officers
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$officerId]);

    $officer = $stmt->fetch(PDO::FETCH_ASSOC);


    if (!$officer) {

        echo json_encode([
            "success" => false,
            "message" => "Officer account not found."
        ]);

        exit;
    }


    $departmentId = (int) $officer["department_id"];
    $officerName = $officer["full_name"];


    /*
    |--------------------------------------------------------------------------
    | GET COMPLAINT + CITIZEN DETAILS
    |--------------------------------------------------------------------------
    |
    | We join complaints with users so that we can obtain:
    |
    | citizen name
    | citizen email
    | complaint title
    | current status
    |
    */

    $stmt = $conn->prepare("
        SELECT
            c.id,
            c.department_id,
            c.user_id,
            c.status,
            c.title,
            u.full_name,
            u.email
        FROM complaints c

        INNER JOIN users u
            ON u.id = c.user_id

        WHERE c.id = ?
          AND c.department_id = ?

        LIMIT 1
    ");

    $stmt->execute([
        $complaintId,
        $departmentId
    ]);

    $complaint = $stmt->fetch(PDO::FETCH_ASSOC);


    /*
    |--------------------------------------------------------------------------
    | CHECK COMPLAINT
    |--------------------------------------------------------------------------
    */

    if (!$complaint) {

        echo json_encode([
            "success" => false,
            "message" => "Complaint not found or not assigned to your department."
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | OLD STATUS
    |--------------------------------------------------------------------------
    */

    $oldStatus = $complaint["status"];

    $citizenName = $complaint["full_name"];
    $citizenEmail = $complaint["email"];
    $issueTitle = $complaint["title"];


    /*
    |--------------------------------------------------------------------------
    | DATABASE TRANSACTION
    |--------------------------------------------------------------------------
    */

    $conn->beginTransaction();


    /*
    |--------------------------------------------------------------------------
    | UPDATE COMPLAINT STATUS
    |--------------------------------------------------------------------------
    */

    $stmt = $conn->prepare("
        UPDATE complaints

        SET
            status = ?,
            updated_at = CURRENT_TIMESTAMP

        WHERE id = ?
          AND department_id = ?
    ");

    $stmt->execute([
        $newStatus,
        $complaintId,
        $departmentId
    ]);


    /*
    |--------------------------------------------------------------------------
    | STATUS LOG
    |--------------------------------------------------------------------------
    */

    if ($oldStatus !== $newStatus) {

        $stmt = $conn->prepare("
            INSERT INTO status_logs
            (
                complaint_id,
                old_status,
                new_status,
                changed_by
            )

            VALUES (?, ?, ?, ?)
        ");

        $stmt->execute([
            $complaintId,
            $oldStatus,
            $newStatus,
            $officerName
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | COMPLAINT REMARK
    |--------------------------------------------------------------------------
    */

    if ($remark !== "") {

        $stmt = $conn->prepare("
            SELECT id
            FROM complaint_remarks
            WHERE complaint_id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $complaintId
        ]);

        $existingRemark = $stmt->fetch(PDO::FETCH_ASSOC);


        if ($existingRemark) {

            /*
            | Update existing remark
            */

            $stmt = $conn->prepare("
                UPDATE complaint_remarks

                SET
                    remark = ?,
                    officer_id = ?

                WHERE complaint_id = ?
            ");

            $stmt->execute([
                $remark,
                $officerId,
                $complaintId
            ]);

        } else {

            /*
            | Create new remark
            */

            $stmt = $conn->prepare("
                INSERT INTO complaint_remarks
                (
                    complaint_id,
                    officer_id,
                    remark
                )

                VALUES (?, ?, ?)
            ");

            $stmt->execute([
                $complaintId,
                $officerId,
                $remark
            ]);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | COMMIT DATABASE CHANGES
    |--------------------------------------------------------------------------
    */

    $conn->commit();


    /*
    |--------------------------------------------------------------------------
    | SEND EMAIL ONLY WHEN STATUS CHANGES
    |--------------------------------------------------------------------------
    */

    $emailSent = false;

    if (
        $oldStatus !== $newStatus &&
        !empty($citizenEmail)
    ) {

        $emailSent = sendComplaintStatusEmail(
            $citizenEmail,
            $citizenName,
            $complaintId,
            $issueTitle,
            $newStatus,
            $officerName
        );
    }


    /*
    |--------------------------------------------------------------------------
    | RESPONSE
    |--------------------------------------------------------------------------
    */

    if ($oldStatus !== $newStatus) {

        if ($emailSent) {

            echo json_encode([
                "success" => true,
                "message" => "Case #{$complaintId} officially updated and citizen notification sent.",
                "complaint_id" => $complaintId,
                "old_status" => $oldStatus,
                "new_status" => $newStatus,
                "email_sent" => true
            ]);

        } else {

            echo json_encode([
                "success" => true,
                "message" => "Case #{$complaintId} officially updated, but email notification could not be sent.",
                "complaint_id" => $complaintId,
                "old_status" => $oldStatus,
                "new_status" => $newStatus,
                "email_sent" => false
            ]);
        }

    } else {

        echo json_encode([
            "success" => true,
            "message" => "Case #{$complaintId} updated successfully. Status was unchanged.",
            "complaint_id" => $complaintId,
            "old_status" => $oldStatus,
            "new_status" => $newStatus,
            "email_sent" => false
        ]);
    }


} catch (PDOException $e) {

    /*
    |--------------------------------------------------------------------------
    | ROLLBACK DATABASE IF SOMETHING FAILS
    |--------------------------------------------------------------------------
    */

    if ($conn->inTransaction()) {
        $conn->rollBack();
    }


    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Unable to update the official record."
    ]);
}

exit;
<?php

require_once("../../includes/config.php");

header("Content-Type: application/json");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);
    exit;
}

$badge_number = trim($_POST["badge_number"] ?? "");
$password     = $_POST["password"] ?? "";

// Validation
if ($badge_number === "" || $password === "") {
    echo json_encode([
        "success" => false,
        "message" => "Please enter Badge Number and Password."
    ]);
    exit;
}

try {

    // Find officer by badge number
    $stmt = $conn->prepare("
        SELECT 
            o.*,
            d.department_name
        FROM officers o
        LEFT JOIN departments d 
            ON o.department_id = d.id
        WHERE o.badge_number = ?
        LIMIT 1
    ");

    $stmt->execute([$badge_number]);

    $officer = $stmt->fetch(PDO::FETCH_ASSOC);

    // Officer not found
    if (!$officer) {
        echo json_encode([
            "success" => false,
            "message" => "Badge Number not recognized in JMC Database."
        ]);
        exit;
    }

    /*
     * Current system uses plain-text passwords,
     * matching your existing citizen login logic.
     *
     * If later you switch to password_hash(),
     * replace this with password_verify().
     */
    if ($officer["password"] !== $password) {
        echo json_encode([
            "success" => false,
            "message" => "Invalid Password. Access Denied."
        ]);
        exit;
    }

    // Create officer session
    $_SESSION["officer_id"]     = $officer["id"];
    $_SESSION["officer_name"]   = $officer["full_name"];
    $_SESSION["officer_dept"]   = $officer["department_id"];
    $_SESSION["badge_number"]   = $officer["badge_number"];
    $_SESSION["officer_email"]  = $officer["email"] ?? "";
    $_SESSION["department_name"] = $officer["department_name"] ?? "";

    echo json_encode([
        "success" => true,
        "message" => "Access Granted. Welcome to the Command Desk.",
        "redirect" => "../../pages/officer/dashboard.php"
    ]);
    exit;

} catch (PDOException $e) {

    // Don't expose database details to the browser
    error_log("Officer Login DB Error: " . $e->getMessage());

    echo json_encode([
        "success" => false,
        "message" => "Database error. Please try again later."
    ]);
    exit;
}
<?php

require_once("../../includes/config.php");

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $login = trim($_POST["login"]);
    $password = trim($_POST["password"]);

    
    // Required Field Validation
    if (empty($login) || empty($password)) {

        echo json_encode([
            "success" => false,
            "message" => "Please enter Login ID and Password."
        ]);

        exit;
    }

    // Check User by Mobile or Email
    $stmt = $conn->prepare("SELECT * FROM users WHERE mobile = ? OR email = ?");
    $stmt->execute([$login, $login]);

    if ($stmt->rowCount() == 0) {

        echo json_encode([
            "success" => false,
            "message" => "Account not found."
        ]);
        exit;
    }

    $user = $stmt->fetch();

    // Check Password
    if ($user["password"] != $password) {

        echo json_encode([
            "success" => false,
            "message" => "Incorrect password."
        ]);
        exit;
    }

    // Create Session
    $_SESSION["user_id"] = $user["id"];
    $_SESSION["full_name"] = $user["full_name"];
    $_SESSION["email"] = $user["email"];
    $_SESSION["mobile"] = $user["mobile"];
    $_SESSION["photo"] = $user["photo"];

    echo json_encode([
        "success" => true,
        "message" => "Login Successful."
    ]);
}
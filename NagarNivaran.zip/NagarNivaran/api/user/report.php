<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once("../../includes/config.php");

header("Content-Type: application/json; charset=UTF-8");


// =====================================================
// 1. CHECK LOGIN SESSION
// =====================================================

if (!isset($_SESSION["user_id"])) {

    echo json_encode([
        "success" => false,
        "message" => "Unauthorized. Please login first."
    ]);

    exit;
}

$user_id = (int) $_SESSION["user_id"];


// =====================================================
// 2. ONLY POST REQUEST ALLOWED
// =====================================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);

    exit;
}


// =====================================================
// 3. GET FORM DATA
// =====================================================

$department_id = isset($_POST["department_id"])
    ? (int) $_POST["department_id"]
    : 0;

$title = isset($_POST["title"])
    ? trim($_POST["title"])
    : "";

$description = isset($_POST["description"])
    ? trim($_POST["description"])
    : "";

$location = isset($_POST["location"])
    ? trim($_POST["location"])
    : "";

$priority = isset($_POST["priority"])
    ? trim($_POST["priority"])
    : "Medium";

$latitude = isset($_POST["latitude"]) && $_POST["latitude"] !== ""
    ? (float) $_POST["latitude"]
    : null;

$longitude = isset($_POST["longitude"]) && $_POST["longitude"] !== ""
    ? (float) $_POST["longitude"]
    : null;


// =====================================================
// 4. GET USER INFORMATION FROM DATABASE
// =====================================================

try {

    $userStmt = $conn->prepare("
        SELECT id, full_name
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $userStmt->execute([$user_id]);

    $user = $userStmt->fetch(PDO::FETCH_ASSOC);


    if (!$user) {

        echo json_encode([
            "success" => false,
            "message" => "User account not found."
        ]);

        exit;
    }


    $reporter_name = $user["full_name"];


} catch (PDOException $e) {

    echo json_encode([
        "success" => false,
        "message" => "Unable to verify citizen account."
    ]);

    exit;
}


// =====================================================
// 5. VALIDATE REQUIRED FIELDS
// =====================================================

if ($department_id <= 0) {

    echo json_encode([
        "success" => false,
        "message" => "Please select a department."
    ]);

    exit;
}


if ($title === "") {

    echo json_encode([
        "success" => false,
        "message" => "Complaint title is required."
    ]);

    exit;
}


if ($description === "") {

    echo json_encode([
        "success" => false,
        "message" => "Problem description is required."
    ]);

    exit;
}


if ($location === "") {

    echo json_encode([
        "success" => false,
        "message" => "Complaint location is required."
    ]);

    exit;
}

// Validate complaint priority

$allowedPriorities = [
    "Low",
    "Medium",
    "High",
    "Critical"
];

if (!in_array($priority, $allowedPriorities, true)) {

    echo json_encode([
        "success" => false,
        "message" => "Invalid complaint priority."
    ]);

    exit;
}


// =====================================================
// 6. CHECK DEPARTMENT EXISTS
// =====================================================

try {

    $deptStmt = $conn->prepare("
        SELECT id, department_name
        FROM departments
        WHERE id = ?
        LIMIT 1
    ");

    $deptStmt->execute([$department_id]);

    $department = $deptStmt->fetch(PDO::FETCH_ASSOC);


    if (!$department) {

        echo json_encode([
            "success" => false,
            "message" => "Selected department does not exist."
        ]);

        exit;
    }


} catch (PDOException $e) {

    echo json_encode([
        "success" => false,
        "message" => "Unable to verify department."
    ]);

    exit;
}


// =====================================================
// 7. IMAGE UPLOAD
// =====================================================

$imageName = null;


if (
    isset($_FILES["image"]) &&
    $_FILES["image"]["error"] !== UPLOAD_ERR_NO_FILE
) {

    // Check upload error

    if ($_FILES["image"]["error"] !== UPLOAD_ERR_OK) {

        echo json_encode([
            "success" => false,
            "message" => "There was an error uploading the image."
        ]);

        exit;
    }


    // Maximum size = 5 MB

    $maxFileSize = 5 * 1024 * 1024;

    if ($_FILES["image"]["size"] > $maxFileSize) {

        echo json_encode([
            "success" => false,
            "message" => "Image size must be less than 5 MB."
        ]);

        exit;
    }


    // Get temporary file

    $tmpFile = $_FILES["image"]["tmp_name"];


    // Check MIME type

    $finfo = finfo_open(FILEINFO_MIME_TYPE);

    $mimeType = finfo_file($finfo, $tmpFile);

    finfo_close($finfo);


    $allowedTypes = [
        "image/jpeg" => "jpg",
        "image/png"  => "png",
        "image/webp" => "webp"
    ];


    if (!array_key_exists($mimeType, $allowedTypes)) {

        echo json_encode([
            "success" => false,
            "message" => "Only JPG, PNG and WEBP images are allowed."
        ]);

        exit;
    }


    // Generate unique filename

    $extension = $allowedTypes[$mimeType];

    $imageName = "complaint_" .
                 $user_id . "_" .
                 time() . "_" .
                 bin2hex(random_bytes(5)) .
                 "." .
                 $extension;


    // Upload directory

    $uploadDir = pathof("assets/uploads/complaints/");


    // Create directory if it doesn't exist

    if (!is_dir($uploadDir)) {

        if (!mkdir($uploadDir, 0755, true)) {

            echo json_encode([
                "success" => false,
                "message" => "Unable to create upload directory."
            ]);

            exit;
        }
    }


    // Full path

    $uploadPath = $uploadDir . $imageName;


    // Move uploaded image

    if (!move_uploaded_file($tmpFile, $uploadPath)) {

        echo json_encode([
            "success" => false,
            "message" => "Failed to save complaint image."
        ]);

        exit;
    }
}


// =====================================================
// 8. INSERT COMPLAINT
// =====================================================

try {

    // Start transaction

    $conn->beginTransaction();


    $stmt = $conn->prepare("
        INSERT INTO complaints (
            user_id,
            department_id,
            reporter_name,
            title,
            description,
            location,
            latitude,
            longitude,
            image,
            status,
            priority
        )
        VALUES (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            'Pending',
            ?
        )
    ");


    $stmt->execute([
        $user_id,
        $department_id,
        $reporter_name,
        $title,
        $description,
        $location,
        $latitude,
        $longitude,
        $imageName,
        $priority
    ]);


    // Get newly created complaint ID

    $complaint_id = $conn->lastInsertId();


    // =================================================
    // 9. INSERT INITIAL STATUS LOG
    // =================================================

    $logStmt = $conn->prepare("
        INSERT INTO status_logs (
            complaint_id,
            old_status,
            new_status,
            changed_by
        )
        VALUES (
            ?,
            ?,
            ?,
            ?
        )
    ");


    $logStmt->execute([
        $complaint_id,
        null,
        "Pending",
        "Citizen #" . $user_id
    ]);


    // =================================================
    // 10. COMMIT
    // =================================================

    $conn->commit();


    // =================================================
    // 11. SUCCESS RESPONSE
    // =================================================

    echo json_encode([
        "success" => true,
        "message" => "Complaint successfully submitted.",
        "complaint_id" => $complaint_id
    ]);

    exit;


} catch (PDOException $e) {

    // Rollback database changes

    if ($conn->inTransaction()) {
        $conn->rollBack();
    }


    // Delete uploaded image if DB insertion failed

    if ($imageName !== null && isset($uploadPath) && file_exists($uploadPath)) {
        unlink($uploadPath);
    }


    echo json_encode([
        "success" => false,
        "message" => "Unable to submit complaint.",
        "error" => $e->getMessage()
    ]);

    exit;
}
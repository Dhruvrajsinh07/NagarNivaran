<?php

require_once("../../includes/config.php");

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $full_name = trim($_POST['full_name']);
    $mobile = trim($_POST['mobile']);
    $email = trim($_POST['email']);
    $house_no = trim($_POST['house_no']);
    $area = trim($_POST['area']);
    $ward = trim($_POST['ward']);
    $pincode = trim($_POST['pincode']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Required Field Validation
    if (
        empty($full_name) ||
        empty($mobile) ||
        empty($email) ||
        empty($area) ||
        empty($ward) ||
        empty($pincode) ||
        empty($password) ||
        empty($confirm_password)
    ) {

        echo json_encode([
            "success" => false,
            "message" => "Please fill all required fields."
        ]);
        exit;
    }

    // Password Match
    if ($password != $confirm_password) {

        echo json_encode([
            "success" => false,
            "message" => "Passwords do not match."
        ]);
        exit;
    }

    // Check Email Exists
    $check = $conn->prepare("SELECT id FROM users WHERE email=?");
    $check->execute([$email]);

    if ($check->rowCount() > 0) {

        echo json_encode([
            "success" => false,
            "message" => "Email already registered."
        ]);
        exit;
    }

    // Photo Upload
    $photo = "";

    if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {

        $photo = time() . "_" . $_FILES["photo"]["name"];

        move_uploaded_file(
            $_FILES["photo"]["tmp_name"],
            "../../assets/uploads/user/" . $photo
        );
    }

    // Insert Data
    $stmt = $conn->prepare("INSERT INTO users
    (
        full_name,
        mobile,
        email,
        house_no,
        area,
        ward,
        pincode,
        photo,
        password
    )

    VALUES

    (?,?,?,?,?,?,?,?,?)");

    $result = $stmt->execute([
        $full_name,
        $mobile,
        $email,
        $house_no,
        $area,
        $ward,
        $pincode,
        $photo,
        $password
    ]);

    if ($result) {

        echo json_encode([
            "success" => true,
            "message" => "Registration Successful."
        ]);

    } else {

        echo json_encode([
            "success" => false,
            "message" => "Registration Failed."
        ]);

    }

}
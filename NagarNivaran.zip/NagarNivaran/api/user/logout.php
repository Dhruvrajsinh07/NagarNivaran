<?php

require_once("../../includes/config.php");

// Destroy all session data
$_SESSION = [];

session_destroy();

header("Location: " . urlof("pages/user/login.php"));
exit;
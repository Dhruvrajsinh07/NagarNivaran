<?php

require_once("../../includes/config.php");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: " . urlof("pages/admin/login.php"));
    exit;
}

$username = trim($_POST["username"] ?? "");
$password = $_POST["password"] ?? "";

if ($username === "" || $password === "") {

    $_SESSION["admin_error"] = "Invalid Admin Credentials.";

    header("Location: " . urlof("pages/admin/login.php"));
    exit;
}

try {

    $stmt = $conn->prepare("
        SELECT *
        FROM admins
        WHERE username = :username
           OR email = :email
        LIMIT 1
    ");

    $stmt->execute([
        ":username" => $username,
        ":email" => $username
    ]);

    $admin = $stmt->fetch();

    /*
     * Flask code was doing direct password comparison:
     *
     * admin["password"] == password
     *
     * So for now we are keeping the EXACT same behavior.
     */

    if ($admin && $admin["password"] === $password) {

        $_SESSION["admin_id"] = $admin["id"];
        $_SESSION["admin_name"] = $admin["username"];
        $_SESSION["admin_role"] = $admin["role"];

        header("Location: " . urlof("pages/admin/dashboard.php"));
        exit;
    }

    $_SESSION["admin_error"] = "Invalid Admin Credentials.";

    header("Location: " . urlof("pages/admin/login.php"));
    exit;

} catch (PDOException $e) {

    $_SESSION["admin_error"] = "Unable to process administrator login.";

    header("Location: " . urlof("pages/admin/login.php"));
    exit;
}
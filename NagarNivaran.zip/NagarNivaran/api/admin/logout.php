<?php
// Start the session so we can access it
session_start();

// Unset all of the specific admin session variables
unset($_SESSION["admin_id"]);
unset($_SESSION["admin_name"]);
unset($_SESSION["admin_role"]);

// Destroy the entire session completely
session_destroy();

// Redirect back to the login page (or home page)
header("Location: ../../pages/admin/login.php"); 
exit;
?>
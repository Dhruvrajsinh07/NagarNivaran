<?php
// Include your existing PDO configuration
require_once '../../includes/config.php'; 

// Authentication Check (Kick out if not logged in as Admin)
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../../pages/admin/login.php");
    exit;
}

$alert_message = "";

// ==========================================
// HANDLE FORM SUBMISSIONS (POST REQUESTS)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'add_officer') {
            $stmt = $conn->prepare("INSERT INTO officers (badge_number, full_name, department_id, email, password) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$_POST['badge_number'], $_POST['full_name'], $_POST['department_id'], $_POST['email'], $_POST['password']]);
            $alert_message = "Officer added successfully.";
            
        } elseif ($action === 'update_officer') {
            $stmt = $conn->prepare("UPDATE officers SET badge_number=?, full_name=?, department_id=?, email=? WHERE id=?");
            $stmt->execute([$_POST['badge_number'], $_POST['full_name'], $_POST['department_id'], $_POST['email'], $_POST['officer_id']]);
            $alert_message = "Officer profile updated.";
            
        } elseif ($action === 'delete_officer') {
            $stmt = $conn->prepare("DELETE FROM officers WHERE id = ?");
            $stmt->execute([$_POST['officer_id']]);
            $alert_message = "Officer revoked.";
            
        } elseif ($action === 'add_department') {
            $stmt = $conn->prepare("INSERT INTO departments (department_name, description) VALUES (?, ?)");
            $stmt->execute([$_POST['dept_name'], $_POST['description']]);
            $alert_message = "Department created.";
            
        } elseif ($action === 'update_department') {
            $stmt = $conn->prepare("UPDATE departments SET department_name=?, description=? WHERE id=?");
            $stmt->execute([$_POST['dept_name'], $_POST['description'], $_POST['dept_id']]);
            $alert_message = "Department updated.";
            
        } elseif ($action === 'delete_department') {
            $stmt = $conn->prepare("DELETE FROM departments WHERE id = ?");
            $stmt->execute([$_POST['dept_id']]);
            $alert_message = "Department removed.";
            
        } elseif ($action === 'delete_user') {
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$_POST['user_id']]);
            $alert_message = "User account deleted.";
            
        } elseif ($action === 'assign_dispatch') {
            $stmt = $conn->prepare("INSERT INTO complaint_assignments (complaint_id, officer_id) VALUES (?, ?)");
            $stmt->execute([$_POST['complaint_id'], $_POST['officer_id']]);
            
            $stmt2 = $conn->prepare("UPDATE complaints SET status = 'In Progress' WHERE id = ?");
            $stmt2->execute([$_POST['complaint_id']]);
            $alert_message = "Complaint dispatched to officer.";
        }
    } catch (PDOException $e) {
        $alert_message = "Error: " . $e->getMessage();
    }
}

// ==========================================
// FETCH DATA FOR DASHBOARD (GET REQUESTS)
// ==========================================

// 1. High-Level KPIs
$total_users = $conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_complaints = $conn->query("SELECT COUNT(*) FROM complaints")->fetchColumn();
$resolved_complaints = $conn->query("SELECT COUNT(*) FROM complaints WHERE status = 'Resolved'")->fetchColumn();
$total_officers = $conn->query("SELECT COUNT(*) FROM officers")->fetchColumn();

$resolution_rate = ($total_complaints > 0) ? round(($resolved_complaints / $total_complaints) * 100, 1) : 0;

// 2. Chart.js Data
$dept_stmt = $conn->query("
    SELECT d.department_name, COUNT(c.id) as issue_count 
    FROM departments d
    LEFT JOIN complaints c ON d.id = c.department_id
    GROUP BY d.id
");
$dept_data = $dept_stmt->fetchAll();
$chart_labels = [];
$chart_values = [];
foreach ($dept_data as $row) {
    $chart_labels[] = $row['department_name'];
    $chart_values[] = $row['issue_count'];
}

// 3. Fetch Data for Data Tables (CRUD)
$users = $conn->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();

$officers = $conn->query("
    SELECT o.*, d.department_name 
    FROM officers o 
    LEFT JOIN departments d ON o.department_id = d.id 
    ORDER BY o.id DESC
")->fetchAll();

$departments = $conn->query("SELECT * FROM departments ORDER BY id DESC")->fetchAll();

$pending_dispatch = $conn->query("
    SELECT c.id, c.title, c.location, c.created_at, d.department_name 
    FROM complaints c
    JOIN departments d ON c.department_id = d.id
    WHERE c.status = 'Pending' OR c.status = 'Under Review'
")->fetchAll();

?>